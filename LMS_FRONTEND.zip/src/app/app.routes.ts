import { Routes } from '@angular/router';
import { adminGuard } from './guards/admin.guard';
import { authGuard } from './guards/auth.guard';
export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },

  
  {
    path: 'home',
    loadComponent: () => import('./components/home/home.component').then(m => m.HomeComponent)

  },
  {
    path: 'login',
    loadComponent: () =>
      import('./components/auth/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'register',
    loadComponent: () =>
      import('./components/auth/register/register.component').then(m => m.RegisterComponent)
  },
  {
    path: 'admin/login',
    loadComponent: () =>
      import('./components/auth/admin-login/admin-login.component').then(m => m.AdminLoginComponent)
  },
  {
    path: 'admin/register',
    loadComponent: () =>
      import('./components/auth/admin-register/admin-register.component').then(m => m.AdminRegisterComponent)
  },

  
  {
    path: 'user',
    canActivate: [authGuard],
    children: [
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./components/user/user-dashboard/user-dashboard.component').then(m => m.UserDashboardComponent)
      },
      {
        path: 'profile',
        loadComponent: () =>
          import('./components/user/user-profile/user-profile.component').then(m => m.UserProfileComponent)
      },
      {
        path: 'loans',
        loadComponent: () =>
          import('./components/user/loans/loans.component').then(m => m.LoansComponent)
      },
      {
        path: 'apply-loan',
        loadComponent: () =>
          import('./components/user/apply-loan/apply-loan.component').then(m => m.ApplyLoanComponent)
      },
      {
        path: 'edit-loan/:id',
        loadComponent: () =>
          import('./components/user/edit-loan/edit-loan.component').then(m => m.EditLoanComponent)
      },
      {
        path: 'payments',
        loadComponent: () =>
          import('./components/user/payment/payment.component').then(m => m.PaymentComponent)
      },
      {
        path: 'emi-tracking',
        loadComponent: () =>
          import('./components/user/emi-tracking/emi-tracking.component').then(m => m.EmiTrackingComponent)
      },
      {
        path: 'payment-tracking',
        loadComponent: () =>
          import('./components/user/payment-tracking/payment-tracking.component').then(m => m.PaymentTrackingComponent)
      },
      {
        path: 'penalty-tracking',
        loadComponent: () =>
          import('./components/user/penalty-tracking/penalty-tracking.component').then(m => m.PenaltyTrackingComponent)
      },
      {
        path: 'emi-dashboard',
        loadComponent: () =>
          import('./components/user/emi-dashboard/emi-dashboard.component').then(m => m.EmiDashboardComponent)
      }
    ]
  },

  
  {
    path: 'admin',
    canActivate: [authGuard, adminGuard],
    children: [
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./components/admin/admin-dashboard/admin-dashboard.component').then(m => m.AdminDashboardComponent)
      },
      {
        path: 'loans',
        loadComponent: () =>
          import('./components/admin/manage-loans/manage-loans.component').then(m => m.ManageLoansComponent)
      },
      {
        path: 'users',
        loadComponent: () =>
          import('./components/admin/manage-users/manage-users.component').then(m => m.ManageUsersComponent)
      },
      {
        path: 'payments',
        loadComponent: () =>
          import('./components/admin/manage-payments/manage-payments.component').then(m => m.ManagePaymentsComponent)
      },
      {
        path: 'disbursements',
        loadComponent: () =>
          import('./components/admin/disbursements/disbursement-list.component').then(m => m.DisbursementListComponent)
      },
      {
        path: 'disbursements/new',
        loadComponent: () =>
          import('./components/admin/disbursements/disbursement-form.component').then(m => m.DisbursementFormComponent)
      },
      {
        path: 'disbursements/:id/edit',
        loadComponent: () =>
          import('./components/admin/disbursements/disbursement-form.component').then(m => m.DisbursementFormComponent)
      }
    ]
  },


  { path: '**', redirectTo: '/home' }
];
