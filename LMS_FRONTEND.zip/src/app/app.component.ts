import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <nav class="navbar navbar-expand-lg navbar-light">
      <div class="container">
        <a class="navbar-brand" routerLink="/home">
          <i class="fas fa-university me-2"></i>
          Loan Management System
        </a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav me-auto">
            <li class="nav-item">
              <a class="nav-link" routerLink="/home" routerLinkActive="active">
                <i class="fas fa-home me-1"></i>Home
              </a>
            </li>
            
            <ng-container *ngIf="authService.isAuthenticated()">
              <li class="nav-item" *ngIf="!authService.isAdmin()">
                <a class="nav-link" routerLink="/user/dashboard" routerLinkActive="active">
                  <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                </a>
              </li>
              
              <li class="nav-item" *ngIf="!authService.isAdmin()">
                <a class="nav-link" routerLink="/user/loans" routerLinkActive="active">
                  <i class="fas fa-file-invoice-dollar me-1"></i>My Loans
                </a>
              </li>
              
              <li class="nav-item" *ngIf="!authService.isAdmin()">
                <a class="nav-link" routerLink="/user/apply-loan" routerLinkActive="active">
                  <i class="fas fa-plus-circle me-1"></i>Apply Loan
                </a>
              </li>
              
              <li class="nav-item" *ngIf="!authService.isAdmin()">
                <a class="nav-link" routerLink="/user/emi-dashboard" routerLinkActive="active">
                  <i class="fas fa-chart-line me-1"></i>EMI & Payments
                </a>
              </li>
              
              <li class="nav-item dropdown" *ngIf="!authService.isAdmin()">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                  <i class="fas fa-credit-card me-1"></i>Quick Actions
                </a>
                <ul class="dropdown-menu">
                  <li>
                    <a class="dropdown-item" routerLink="/user/payments">
                      <i class="fas fa-credit-card me-2"></i>Make Payment
                    </a>
                  </li>
                  <li>
                    <a class="dropdown-item" routerLink="/user/payment-tracking">
                      <i class="fas fa-search-dollar me-2"></i>Payment Tracking
                    </a>
                  </li>
                  <li>
                    <a class="dropdown-item" routerLink="/user/emi-tracking">
                      <i class="fas fa-calendar-check me-2"></i>EMI Schedule
                    </a>
                  </li>
                  <li>
                    <a class="dropdown-item" routerLink="/user/penalty-tracking">
                      <i class="fas fa-exclamation-triangle me-2"></i>Penalty Tracking
                    </a>
                  </li>
                </ul>
              </li>
              
              <li class="nav-item" *ngIf="authService.isAdmin()">
                <a class="nav-link" routerLink="/admin/dashboard" routerLinkActive="active">
                  <i class="fas fa-tachometer-alt me-1"></i>Admin Dashboard
                </a>
              </li>
              
              <li class="nav-item" *ngIf="authService.isAdmin()">
                <a class="nav-link" routerLink="/admin/users" routerLinkActive="active">
                  <i class="fas fa-users me-1"></i>Manage Users
                </a>
              </li>
              
              <li class="nav-item" *ngIf="authService.isAdmin()">
                <a class="nav-link" routerLink="/admin/loans" routerLinkActive="active">
                  <i class="fas fa-file-invoice-dollar me-1"></i>Manage Loans
                </a>
              </li>
              
              <li class="nav-item" *ngIf="authService.isAdmin()">
                <a class="nav-link" routerLink="/admin/disbursements" routerLinkActive="active">
                  <i class="fas fa-money-check-alt me-1"></i>Disbursements
                </a>
              </li>
            </ng-container>
          </ul>
          
          <ul class="navbar-nav">
            <ng-container *ngIf="!authService.isAuthenticated()">
              <li class="nav-item">
                <a class="nav-link" routerLink="/login">
                  <i class="fas fa-sign-in-alt me-1"></i>Login
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" routerLink="/register">
                  <i class="fas fa-user-plus me-1"></i>Register
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" routerLink="/admin/login">
                  <i class="fas fa-user-shield me-1"></i>Admin
                </a>
              </li>
            </ng-container>
            
            <ng-container *ngIf="authService.isAuthenticated()">
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                  <i class="fas fa-user-circle me-1"></i>
                  {{ authService.getCurrentUser()?.username || 'User' }}
                </a>
                <ul class="dropdown-menu">
                  <li *ngIf="!authService.isAdmin()">
                    <a class="dropdown-item" routerLink="/user/profile">
                      <i class="fas fa-user me-2"></i>Profile
                    </a>
                  </li>
                  <li><hr class="dropdown-divider"></li>
                  <li>
                    <a class="dropdown-item" href="#" (click)="logout()">
                      <i class="fas fa-sign-out-alt me-2"></i>Logout
                    </a>
                  </li>
                </ul>
              </li>
            </ng-container>
          </ul>
        </div>
      </div>
    </nav>

    <main class="container mt-4">
      <router-outlet></router-outlet>
    </main>

    <footer class="bg-dark text-light text-center py-4 mt-5">
      <div class="container">
        <p>&copy; 2024 Loan Management System. All rights reserved.</p>
      </div>
    </footer>
  `,
  styles: [`
    .navbar-nav .nav-link.active {
      color: #667eea !important;
      font-weight: 600;
    }
    
    .dropdown-menu {
      border-radius: 10px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
      border: none;
    }
    
    .dropdown-item:hover {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
    }
  `]
})
export class AppComponent {
  constructor(public authService: AuthService) {}

  logout(): void {
    this.authService.logout();
  }
}
