import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="hero-section text-center text-white py-5 mb-5">
      <div class="container">
        <h1 class="display-4 fw-bold mb-4">
          <i class="fas fa-university me-3"></i>
          Welcome to Loan Management System
        </h1>
        <p class="lead mb-4">
          Your trusted partner for personal and business loans with competitive rates and flexible terms
        </p>
        <div class="hero-buttons">
          <a routerLink="/register" class="btn btn-light btn-lg me-3">
            <i class="fas fa-user-plus me-2"></i>Get Started
          </a>
          <a routerLink="/login" class="btn btn-outline-light btn-lg">
            <i class="fas fa-sign-in-alt me-2"></i>Login
          </a>
        </div>
      </div>
    </div>

    <div class="container">
      <!-- Features Section -->
      <div class="row mb-5">
        <div class="col-md-4 mb-4">
          <div class="card h-100 text-center">
            <div class="card-body">
              <i class="fas fa-shield-alt fa-3x text-primary mb-3"></i>
              <h5 class="card-title">Secure & Safe</h5>
              <p class="card-text">Your data is protected with bank-level security and encryption.</p>
            </div>
          </div>
        </div>
        <div class="col-md-4 mb-4">
          <div class="card h-100 text-center">
            <div class="card-body">
              <i class="fas fa-clock fa-3x text-success mb-3"></i>
              <h5 class="card-title">Quick Processing</h5>
              <p class="card-text">Fast loan approval and disbursement within 24-48 hours.</p>
            </div>
          </div>
        </div>
        <div class="col-md-4 mb-4">
          <div class="card h-100 text-center">
            <div class="card-body">
              <i class="fas fa-percentage fa-3x text-warning mb-3"></i>
              <h5 class="card-title">Low Interest Rates</h5>
              <p class="card-text">Competitive interest rates starting from 8.5% per annum.</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Loan Types Section -->
      <div class="row mb-5">
        <div class="col-12">
          <h2 class="text-center mb-4">Our Loan Products</h2>
        </div>
        <div class="col-md-6 mb-4">
          <div class="card">
            <div class="card-header">
              <h5 class="mb-0">
                <i class="fas fa-home me-2"></i>Personal Loan
              </h5>
            </div>
            <div class="card-body">
              <p class="card-text">Get personal loans for any purpose with flexible repayment options.</p>
              <ul class="list-unstyled">
                <li><i class="fas fa-check text-success me-2"></i>Amount: ₹10,000 - ₹25,00,000</li>
                <li><i class="fas fa-check text-success me-2"></i>Interest: 8.5% - 15% p.a.</li>
                <li><i class="fas fa-check text-success me-2"></i>Tenure: 12 - 60 months</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md-6 mb-4">
          <div class="card">
            <div class="card-header">
              <h5 class="mb-0">
                <i class="fas fa-briefcase me-2"></i>Business Loan
              </h5>
            </div>
            <div class="card-body">
              <p class="card-text">Expand your business with our business loan solutions.</p>
              <ul class="list-unstyled">
                <li><i class="fas fa-check text-success me-2"></i>Amount: ₹50,000 - ₹50,00,000</li>
                <li><i class="fas fa-check text-success me-2"></i>Interest: 10% - 18% p.a.</li>
                <li><i class="fas fa-check text-success me-2"></i>Tenure: 12 - 84 months</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <!-- How It Works Section -->
      <div class="row mb-5">
        <div class="col-12">
          <h2 class="text-center mb-4">How It Works</h2>
        </div>
        <div class="col-md-3 text-center mb-4">
          <div class="step-circle mb-3">
            <span class="step-number">1</span>
          </div>
          <h5>Apply Online</h5>
          <p>Fill out the simple online application form</p>
        </div>
        <div class="col-md-3 text-center mb-4">
          <div class="step-circle mb-3">
            <span class="step-number">2</span>
          </div>
          <h5>Document Verification</h5>
          <p>Upload required documents for verification</p>
        </div>
        <div class="col-md-3 text-center mb-4">
          <div class="step-circle mb-3">
            <span class="step-number">3</span>
          </div>
          <h5>Quick Approval</h5>
          <p>Get approval within 24-48 hours</p>
        </div>
        <div class="col-md-3 text-center mb-4">
          <div class="step-circle mb-3">
            <span class="step-number">4</span>
          </div>
          <h5>Money Disbursed</h5>
          <p>Receive money directly in your bank account</p>
        </div>
      </div>

      <!-- CTA Section -->
      <div class="text-center mb-5">
        <div class="card">
          <div class="card-body py-5">
            <h3 class="mb-3">Ready to Get Started?</h3>
            <p class="lead mb-4">Join thousands of satisfied customers who have already benefited from our services.</p>
            <a routerLink="/register" class="btn btn-primary btn-lg me-3">
              <i class="fas fa-rocket me-2"></i>Apply Now
            </a>
            <a routerLink="/login" class="btn btn-outline-primary btn-lg">
              <i class="fas fa-sign-in-alt me-2"></i>Login
            </a>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .hero-section {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border-radius: 0 0 50px 50px;
      margin-bottom: 2rem;
    }
    
    .hero-buttons .btn {
      padding: 12px 30px;
      font-weight: 600;
      border-radius: 25px;
    }
    
    .step-circle {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto;
    }
    
    .step-number {
      color: white;
      font-size: 2rem;
      font-weight: bold;
    }
    
    .card {
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
    }
    
    .text-primary {
      color: #667eea !important;
    }
    
    .text-success {
      color: #56ab2f !important;
    }
    
    .text-warning {
      color: #ffc107 !important;
    }
  `]
})
export class HomeComponent {}
