import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, AbstractControl, ValidationErrors } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-admin-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
          <div class="card">
            <div class="card-header text-center">
              <h4 class="mb-0">
                <i class="fas fa-user-shield me-2"></i>Admin Registration
              </h4>
            </div>
            <div class="card-body">
              <form [formGroup]="registerForm" (ngSubmit)="onSubmit()">
                
                <!-- Username -->
                <div class="mb-3">
                  <label for="username" class="form-label">Username *</label>
                  <input
                    type="text"
                    class="form-control"
                    id="username"
                    formControlName="username"
                    placeholder="Enter admin username"
                    [class.is-invalid]="isFieldInvalid('username')"
                  />
                  <div class="invalid-feedback" *ngIf="isFieldInvalid('username')">
                    Username is required and must be at least 3 characters
                  </div>
                </div>

                <!-- Email -->
                <div class="mb-3">
                  <label for="email" class="form-label">Email *</label>
                  <input
                    type="email"
                    class="form-control"
                    id="email"
                    formControlName="email"
                    placeholder="Enter admin email"
                    [class.is-invalid]="isFieldInvalid('email')"
                  />
                  <div class="invalid-feedback" *ngIf="isFieldInvalid('email')">
                    Please enter a valid email address
                  </div>
                </div>

                <!-- Role -->
                <div class="mb-3">
                  <label for="role" class="form-label">Role *</label>
                  <select
                    class="form-select"
                    id="role"
                    formControlName="role"
                    [class.is-invalid]="isFieldInvalid('role')"
                  >
                    <option value="">Select role</option>
                    <option value="ADMIN">Admin</option>
                    <option value="SUPER_ADMIN">Super Admin</option>
                  </select>
                  <div class="invalid-feedback" *ngIf="isFieldInvalid('role')">
                    Please select a role
                  </div>
                </div>

                <!-- Mobile Number -->
                <div class="mb-3">
                  <label for="mobileNumber" class="form-label">Mobile Number *</label>
                  <input
                    type="text"
                    class="form-control"
                    id="mobileNumber"
                    formControlName="mobileNumber"
                    placeholder="Enter mobile number"
                    [class.is-invalid]="isFieldInvalid('mobileNumber')"
                  />
                  <div class="invalid-feedback" *ngIf="isFieldInvalid('mobileNumber')">
                    Please enter a valid 10-digit mobile number
                  </div>
                </div>

                <!-- Address -->
                <div class="mb-3">
                  <label for="address" class="form-label">Address *</label>
                  <input
                    type="text"
                    class="form-control"
                    id="address"
                    formControlName="address"
                    placeholder="Enter address"
                    [class.is-invalid]="isFieldInvalid('address')"
                  />
                  <div class="invalid-feedback" *ngIf="isFieldInvalid('address')">
                    Address is required
                  </div>
                </div>

                <!-- Password -->
                <div class="mb-3">
                  <label for="password" class="form-label">Password *</label>
                  <div class="input-group">
                    <input
                      [type]="showPassword ? 'text' : 'password'"
                      class="form-control"
                      id="password"
                      formControlName="password"
                      placeholder="Enter password"
                      [class.is-invalid]="isFieldInvalid('password')"
                    />
                    <button
                      type="button"
                      class="btn btn-outline-secondary"
                      (click)="togglePassword()"
                    >
                      <i [class]="showPassword ? 'fas fa-eye-slash' : 'fas fa-eye'"></i>
                    </button>
                  </div>
                  <div class="invalid-feedback" *ngIf="isFieldInvalid('password')">
                    Password must be at least 8 characters long
                  </div>
                </div>

                <!-- Confirm Password -->
                <div class="mb-3">
                  <label for="confirmPassword" class="form-label">Confirm Password *</label>
                  <input
                    type="password"
                    class="form-control"
                    id="confirmPassword"
                    formControlName="confirmPassword"
                    placeholder="Confirm your password"
                    [class.is-invalid]="isFieldInvalid('confirmPassword')"
                  />
                  <div class="invalid-feedback" *ngIf="isFieldInvalid('confirmPassword')">
                    Passwords do not match
                  </div>
                </div>

                <!-- Submit -->
                <div class="d-grid gap-2">
                  <button
                    type="submit"
                    class="btn btn-primary btn-lg"
                    [disabled]="registerForm.invalid || isLoading"
                  >
                    <span *ngIf="isLoading" class="spinner-border spinner-border-sm me-2"></span>
                    <i *ngIf="!isLoading" class="fas fa-user-shield me-2"></i>
                    {{ isLoading ? 'Creating Admin Account...' : 'Create Admin Account' }}
                  </button>
                </div>

                <!-- Links -->
                <div class="text-center mt-3">
                  <p class="mb-0">
                    Already have an admin account?
                    <a routerLink="/admin/login" class="text-decoration-none">Login here</a>
                  </p>
                  <p class="mt-2">
                    <a routerLink="/login" class="text-decoration-none">
                      <i class="fas fa-arrow-left me-1"></i>Back to User Login
                    </a>
                  </p>
                </div>
              </form>
            </div>
          </div>

          <!-- Alert Messages -->
          <div *ngIf="alertMessage" class="alert mt-3" [class]="alertClass">
            <i [class]="alertIcon"></i>
            {{ alertMessage }}
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .card {
      margin-top: 2rem;
    }
    .text-primary {
      color: #667eea !important;
    }
    .btn-primary {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border: none;
      padding: 15px;
      font-weight: 600;
    }
    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    }
    .btn-primary:disabled {
      opacity: 0.7;
      transform: none;
      box-shadow: none;
    }
    .alert {
      border-radius: 10px;
      border: none;
    }
    .alert-success {
      background: linear-gradient(135deg, #56ab2f 0%, #a8e6cf 100%);
      color: white;
    }
    .alert-danger {
      background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);
      color: white;
    }
    .form-control:focus,
    .form-select:focus {
      border-color: #667eea;
      box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
    }
  `]
})
export class AdminRegisterComponent {
  registerForm: FormGroup;
  isLoading = false;
  showPassword = false;
  alertMessage = '';
  alertClass = '';
  alertIcon = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.registerForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      role: ['', [Validators.required]],
      mobileNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      address: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', [Validators.required]]
    }, { validators: this.passwordMatchValidator });
  }

  passwordMatchValidator(control: AbstractControl): ValidationErrors | null {
    const password = control.get('password');
    const confirmPassword = control.get('confirmPassword');
    if (password && confirmPassword && password.value !== confirmPassword.value) {
      return { passwordMismatch: true };
    }
    return null;
  }

  onSubmit(): void {
    if (this.registerForm.valid) {
      this.isLoading = true;
      this.clearAlert();
      const adminData = this.registerForm.value;
      this.authService.registerAdmin(adminData).subscribe({
        next: () => {
          this.showAlert('Admin registration successful! Redirecting to login...', 'alert-success', 'fas fa-check-circle');
          setTimeout(() => this.router.navigate(['/admin/login']), 2000);
        },
        error: (error) => {
          console.error('Admin registration error:', error);
          let message = 'Admin registration failed. Please try again.';
          if (error.error?.message) {
            message = error.error.message;
          } else if (error.status === 400) {
            message = 'Please check your input data and try again.';
          }
          this.showAlert(message, 'alert-danger', 'fas fa-exclamation-triangle');
        },
        complete: () => this.isLoading = false
      });
    } else {
      this.markFormGroupTouched();
    }
  }

  togglePassword(): void {
    this.showPassword = !this.showPassword;
  }

  isFieldInvalid(fieldName: string): boolean {
    const field = this.registerForm.get(fieldName);
    return field ? field.invalid && (field.dirty || field.touched) : false;
  }

  markFormGroupTouched(): void {
    Object.keys(this.registerForm.controls).forEach(key => {
      const control = this.registerForm.get(key);
      control?.markAsTouched();
    });
  }

  showAlert(message: string, alertClass: string, icon: string): void {
    this.alertMessage = message;
    this.alertClass = alertClass;
    this.alertIcon = icon;
  }

  clearAlert(): void {
    this.alertMessage = '';
    this.alertClass = '';
    this.alertIcon = '';
  }
}
