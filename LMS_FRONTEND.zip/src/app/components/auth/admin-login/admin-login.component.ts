import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-admin-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
          <div class="card">
            <div class="card-header text-center">
              <h4 class="mb-0">
                <i class="fas fa-user-shield me-2"></i>Admin Login
              </h4>
            </div>
            <div class="card-body">
              <form [formGroup]="loginForm" (ngSubmit)="onSubmit()">
                <div class="mb-3">
                  <label for="username" class="form-label">Username</label>
                  <div class="input-group">
                    <span class="input-group-text">
                      <i class="fas fa-user-shield"></i>
                    </span>
                    <input
                      type="text"
                      class="form-control"
                      id="username"
                      formControlName="username"
                      placeholder="Enter admin username"
                      [class.is-invalid]="isFieldInvalid('username')"
                    />
                  </div>
                  <div class="invalid-feedback" *ngIf="isFieldInvalid('username')">
                    Username is required
                  </div>
                </div>

                <div class="mb-3">
                  <label for="password" class="form-label">Password</label>
                  <div class="input-group">
                    <span class="input-group-text">
                      <i class="fas fa-lock"></i>
                    </span>
                    <input
                      [type]="showPassword ? 'text' : 'password'"
                      class="form-control"
                      id="password"
                      formControlName="password"
                      placeholder="Enter admin password"
                      [class.is-invalid]="isFieldInvalid('password')"
                    />
                    <button
                      type="button"
                      class="btn btn-outline-secondary"
                      (click)="togglePassword()"
                    >
                      <i [class]="showPassword ? 'fas fa-eye-slash' : 'fas fa-eye'"></i>
                    </button>
                  </div>
                  <div class="invalid-feedback" *ngIf="isFieldInvalid('password')">
                    Password is required
                  </div>
                </div>

                <div class="d-grid gap-2">
                  <button
                    type="submit"
                    class="btn btn-primary"
                    [disabled]="loginForm.invalid || isLoading"
                  >
                    <span *ngIf="isLoading" class="spinner-border spinner-border-sm me-2"></span>
                    <i *ngIf="!isLoading" class="fas fa-sign-in-alt me-2"></i>
                    {{ isLoading ? 'Logging in...' : 'Admin Login' }}
                  </button>
                </div>

                <div class="text-center mt-3">
                  <p class="mb-0">
                    <a routerLink="/login" class="text-decoration-none">
                      <i class="fas fa-arrow-left me-1"></i>Back to User Login
                    </a>
                  </p>
                  <p class="mt-2">
                    <a routerLink="/admin/register" class="text-decoration-none">
                      <i class="fas fa-user-plus me-1"></i>Admin Registration
                    </a>
                  </p>
                </div>
              </form>
            </div>
          </div>

          <!-- Alert Messages -->
          <div *ngIf="alertMessage" class="alert mt-3" [class]="alertClass">
            <i [class]="alertIcon"></i>
            {{ alertMessage }}
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .card {
      margin-top: 2rem;
    }
    
    .input-group-text {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border: none;
    }
    
    .btn-primary {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border: none;
      padding: 12px;
      font-weight: 600;
    }
    
    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    }
    
    .btn-primary:disabled {
      opacity: 0.7;
      transform: none;
      box-shadow: none;
    }
    
    .alert {
      border-radius: 10px;
      border: none;
    }
    
    .alert-success {
      background: linear-gradient(135deg, #56ab2f 0%, #a8e6cf 100%);
      color: white;
    }
    
    .alert-danger {
      background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);
      color: white;
    }
  `]
})
export class AdminLoginComponent {
  loginForm: FormGroup;
  isLoading = false;
  showPassword = false;
  alertMessage = '';
  alertClass = '';
  alertIcon = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]]
    });
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
      this.isLoading = true;
      this.clearAlert();

      const credentials = this.loginForm.value;
      
      this.authService.loginAdmin(credentials).subscribe({
        next: (response) => {
          this.showAlert('Admin login successful! Redirecting...', 'alert-success', 'fas fa-check-circle');
          setTimeout(() => {
            this.router.navigate(['/admin/dashboard']);
          }, 1500);
        },
        error: (error) => {
          console.error('Admin login error:', error);
          let message = 'Admin login failed. Please try again.';
          
          if (error.error?.message) {
            message = error.error.message;
          } else if (error.status === 401) {
            message = 'Invalid admin credentials.';
          }
          
          this.showAlert(message, 'alert-danger', 'fas fa-exclamation-triangle');
        },
        complete: () => {
          this.isLoading = false;
        }
      });
    } else {
      this.markFormGroupTouched();
    }
  }

  togglePassword(): void {
    this.showPassword = !this.showPassword;
  }

  isFieldInvalid(fieldName: string): boolean {
    const field = this.loginForm.get(fieldName);
    return field ? field.invalid && (field.dirty || field.touched) : false;
  }

  markFormGroupTouched(): void {
    Object.keys(this.loginForm.controls).forEach(key => {
      const control = this.loginForm.get(key);
      control?.markAsTouched();
    });
  }

  showAlert(message: string, alertClass: string, icon: string): void {
    this.alertMessage = message;
    this.alertClass = alertClass;
    this.alertIcon = icon;
  }

  clearAlert(): void {
    this.alertMessage = '';
    this.alertClass = '';
    this.alertIcon = '';
  }
}
