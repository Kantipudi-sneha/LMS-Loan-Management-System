import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, AbstractControl, ValidationErrors } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-10">
          <div class="card">
            <div class="card-header text-center">
              <h4 class="mb-0">
                <i class="fas fa-user-plus me-2"></i>User Registration
              </h4>
            </div>
            <div class="card-body">
              <form [formGroup]="registerForm" (ngSubmit)="onSubmit()">
                <div class="row">
                  <!-- Personal Information -->
                  <div class="col-md-6">
                    <h5 class="mb-3 text-primary">
                      <i class="fas fa-user me-2"></i>Personal Information
                    </h5>
                    
                    <div class="mb-3">
                      <label for="username" class="form-label">Username *</label>
                      <input
                        type="text"
                        class="form-control"
                        id="username"
                        formControlName="username"
                        placeholder="Enter username"
                        [class.is-invalid]="isFieldInvalid('username')"
                      />
                      <div class="invalid-feedback" *ngIf="isFieldInvalid('username')">
                        Username is required and must be at least 3 characters
                      </div>
                    </div>

                    <div class="mb-3">
                      <label for="email" class="form-label">Email *</label>
                      <input
                        type="email"
                        class="form-control"
                        id="email"
                        formControlName="email"
                        placeholder="Enter email"
                        [class.is-invalid]="isFieldInvalid('email')"
                      />
                      <div class="invalid-feedback" *ngIf="isFieldInvalid('email')">
                        Please enter a valid email address
                      </div>
                    </div>

                    <div class="mb-3">
                      <label for="mobileNumber" class="form-label">Mobile Number *</label>
                      <input
                        type="tel"
                        class="form-control"
                        id="mobileNumber"
                        formControlName="mobileNumber"
                        placeholder="Enter mobile number"
                        [class.is-invalid]="isFieldInvalid('mobileNumber')"
                      />
                      <div class="invalid-feedback" *ngIf="isFieldInvalid('mobileNumber')">
                        Please enter a valid 10-digit mobile number
                      </div>
                    </div>

                    <div class="mb-3">
                      <label for="dateOfBirth" class="form-label">Date of Birth *</label>
                      <input
                        type="date"
                        class="form-control"
                        id="dateOfBirth"
                        formControlName="dateOfBirth"
                        [class.is-invalid]="isFieldInvalid('dateOfBirth')"
                      />
                      <div class="invalid-feedback" *ngIf="isFieldInvalid('dateOfBirth')">
                        Date of birth is required
                      </div>
                    </div>

                    <div class="mb-3">
                      <label for="aadharNumber" class="form-label">Aadhar Number *</label>
                      <input
                        type="text"
                        class="form-control"
                        id="aadharNumber"
                        formControlName="aadharNumber"
                        placeholder="Enter 12-digit Aadhar number"
                        maxlength="12"
                        [class.is-invalid]="isFieldInvalid('aadharNumber')"
                      />
                      <div class="invalid-feedback" *ngIf="isFieldInvalid('aadharNumber')">
                        Please enter a valid 12-digit Aadhar number
                      </div>
                    </div>

                    <div class="mb-3">
                      <label for="panNumber" class="form-label">PAN Number *</label>
                      <input
                        type="text"
                        class="form-control"
                        id="panNumber"
                        formControlName="panNumber"
                        placeholder="Enter 10-character PAN number"
                        maxlength="10"
                        [class.is-invalid]="isFieldInvalid('panNumber')"
                      />
                      <div class="invalid-feedback" *ngIf="isFieldInvalid('panNumber')">
                        Please enter a valid 10-character PAN number
                      </div>
                    </div>
                  </div>

                  <!-- Additional Information -->
                  <div class="col-md-6">
                    <h5 class="mb-3 text-primary">
                      <i class="fas fa-info-circle me-2"></i>Additional Information
                    </h5>

                    <div class="mb-3">
                      <label for="address" class="form-label">Address *</label>
                      <textarea
                        class="form-control"
                        id="address"
                        formControlName="address"
                        rows="3"
                        placeholder="Enter your complete address"
                        [class.is-invalid]="isFieldInvalid('address')"
                      ></textarea>
                      <div class="invalid-feedback" *ngIf="isFieldInvalid('address')">
                        Address is required
                      </div>
                    </div>

                    <div class="mb-3">
                      <label for="occupation" class="form-label">Occupation *</label>
                      <input
                        type="text"
                        class="form-control"
                        id="occupation"
                        formControlName="occupation"
                        placeholder="Enter your occupation"
                        [class.is-invalid]="isFieldInvalid('occupation')"
                      />
                      <div class="invalid-feedback" *ngIf="isFieldInvalid('occupation')">
                        Occupation is required
                      </div>
                    </div>

                    <div class="mb-3">
                      <label for="employerName" class="form-label">Employer Name *</label>
                      <input
                        type="text"
                        class="form-control"
                        id="employerName"
                        formControlName="employerName"
                        placeholder="Enter employer name"
                        [class.is-invalid]="isFieldInvalid('employerName')"
                      />
                      <div class="invalid-feedback" *ngIf="isFieldInvalid('employerName')">
                        Employer name is required
                      </div>
                    </div>

                    <div class="mb-3">
                      <label for="monthlyIncome" class="form-label">Monthly Income (₹) *</label>
                      <input
                        type="number"
                        class="form-control"
                        id="monthlyIncome"
                        formControlName="monthlyIncome"
                        placeholder="Enter monthly income"
                        min="0"
                        [class.is-invalid]="isFieldInvalid('monthlyIncome')"
                      />
                      <div class="invalid-feedback" *ngIf="isFieldInvalid('monthlyIncome')">
                        Monthly income is required and must be positive
                      </div>
                    </div>

                    <h5 class="mb-3 text-primary">
                      <i class="fas fa-university me-2"></i>Bank Details
                    </h5>

                    <div class="mb-3">
                      <label for="bankName" class="form-label">Bank Name *</label>
                      <input
                        type="text"
                        class="form-control"
                        id="bankName"
                        formControlName="bankName"
                        placeholder="Enter bank name"
                        [class.is-invalid]="isFieldInvalid('bankName')"
                      />
                      <div class="invalid-feedback" *ngIf="isFieldInvalid('bankName')">
                        Bank name is required
                      </div>
                    </div>

                    <div class="mb-3">
                      <label for="accountNumber" class="form-label">Account Number *</label>
                      <input
                        type="text"
                        class="form-control"
                        id="accountNumber"
                        formControlName="accountNumber"
                        placeholder="Enter account number"
                        [class.is-invalid]="isFieldInvalid('accountNumber')"
                      />
                      <div class="invalid-feedback" *ngIf="isFieldInvalid('accountNumber')">
                        Account number is required
                      </div>
                    </div>

                    <div class="mb-3">
                      <label for="ifscCode" class="form-label">IFSC Code *</label>
                      <input
                        type="text"
                        class="form-control"
                        id="ifscCode"
                        formControlName="ifscCode"
                        placeholder="Enter IFSC code"
                        maxlength="11"
                        [class.is-invalid]="isFieldInvalid('ifscCode')"
                      />
                      <div class="invalid-feedback" *ngIf="isFieldInvalid('ifscCode')">
                        Please enter a valid 11-character IFSC code
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Password Section -->
                <div class="row mt-4">
                  <div class="col-md-6">
                    <h5 class="mb-3 text-primary">
                      <i class="fas fa-lock me-2"></i>Security
                    </h5>

                    <div class="mb-3">
                      <label for="password" class="form-label">Password *</label>
                      <div class="input-group">
                        <input
                          [type]="showPassword ? 'text' : 'password'"
                          class="form-control"
                          id="password"
                          formControlName="password"
                          placeholder="Enter password"
                          [class.is-invalid]="isFieldInvalid('password')"
                        />
                        <button
                          type="button"
                          class="btn btn-outline-secondary"
                          (click)="togglePassword()"
                        >
                          <i [class]="showPassword ? 'fas fa-eye-slash' : 'fas fa-eye'"></i>
                        </button>
                      </div>
                      <div class="invalid-feedback" *ngIf="isFieldInvalid('password')">
                        Password must be at least 8 characters long
                      </div>
                    </div>

                    <div class="mb-3">
                      <label for="confirmPassword" class="form-label">Confirm Password *</label>
                      <input
                        type="password"
                        class="form-control"
                        id="confirmPassword"
                        formControlName="confirmPassword"
                        placeholder="Confirm your password"
                        [class.is-invalid]="isFieldInvalid('confirmPassword')"
                      />
                      <div class="invalid-feedback" *ngIf="isFieldInvalid('confirmPassword')">
                        Passwords do not match
                      </div>
                    </div>
                  </div>
                </div>

                <div class="d-grid gap-2 mt-4">
                  <button
                    type="submit"
                    class="btn btn-primary btn-lg"
                    [disabled]="registerForm.invalid || isLoading"
                  >
                    <span *ngIf="isLoading" class="spinner-border spinner-border-sm me-2"></span>
                    <i *ngIf="!isLoading" class="fas fa-user-plus me-2"></i>
                    {{ isLoading ? 'Creating Account...' : 'Create Account' }}
                  </button>
                </div>

                <div class="text-center mt-3">
                  <p class="mb-0">
                    Already have an account?
                    <a routerLink="/login" class="text-decoration-none">Login here</a>
                  </p>
                </div>
              </form>
            </div>
          </div>

          <!-- Alert Messages -->
          <div *ngIf="alertMessage" class="alert mt-3" [class]="alertClass">
            <i [class]="alertIcon"></i>
            {{ alertMessage }}
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .card {
      margin-top: 2rem;
    }
    
    .text-primary {
      color: #667eea !important;
    }
    
    .btn-primary {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border: none;
      padding: 15px;
      font-weight: 600;
    }
    
    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    }
    
    .btn-primary:disabled {
      opacity: 0.7;
      transform: none;
      box-shadow: none;
    }
    
    .alert {
      border-radius: 10px;
      border: none;
    }
    
    .alert-success {
      background: linear-gradient(135deg, #56ab2f 0%, #a8e6cf 100%);
      color: white;
    }
    
    .alert-danger {
      background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);
      color: white;
    }
    
    .form-control:focus {
      border-color: #667eea;
      box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
    }
  `]
})
export class RegisterComponent {
  registerForm: FormGroup;
  isLoading = false;
  showPassword = false;
  alertMessage = '';
  alertClass = '';
  alertIcon = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.registerForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', [Validators.required]],
      mobileNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      dateOfBirth: ['', [Validators.required]],
      aadharNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{12}$/)]],
      panNumber: ['', [Validators.required, Validators.pattern(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/)]],
      address: ['', [Validators.required]],
      occupation: ['', [Validators.required]],
      employerName: ['', [Validators.required]],
      monthlyIncome: ['', [Validators.required, Validators.min(0)]],
      bankName: ['', [Validators.required]],
      accountNumber: ['', [Validators.required]],
      ifscCode: ['', [Validators.required, Validators.pattern(/^[A-Z]{4}0[A-Z0-9]{6}$/)]]
    }, { validators: this.passwordMatchValidator });
  }

  passwordMatchValidator(control: AbstractControl): ValidationErrors | null {
    const password = control.get('password');
    const confirmPassword = control.get('confirmPassword');
    
    if (password && confirmPassword && password.value !== confirmPassword.value) {
      return { passwordMismatch: true };
    }
    
    return null;
  }

  onSubmit(): void {
    if (this.registerForm.valid) {
      this.isLoading = true;
      this.clearAlert();

      const userData = this.registerForm.value;
      
      this.authService.registerUser(userData).subscribe({
        next: (response) => {
          this.showAlert('Registration successful! Redirecting to login...', 'alert-success', 'fas fa-check-circle');
          setTimeout(() => {
            this.router.navigate(['/login']);
          }, 2000);
        },
        error: (error) => {
          console.error('Registration error:', error);
          let message = 'Registration failed. Please try again.';
          
          if (error.error?.message) {
            message = error.error.message;
          } else if (error.status === 400) {
            message = 'Please check your input data and try again.';
          }
          
          this.showAlert(message, 'alert-danger', 'fas fa-exclamation-triangle');
        },
        complete: () => {
          this.isLoading = false;
        }
      });
    } else {
      this.markFormGroupTouched();
    }
  }

  togglePassword(): void {
    this.showPassword = !this.showPassword;
  }

  isFieldInvalid(fieldName: string): boolean {
    const field = this.registerForm.get(fieldName);
    return field ? field.invalid && (field.dirty || field.touched) : false;
  }

  markFormGroupTouched(): void {
    Object.keys(this.registerForm.controls).forEach(key => {
      const control = this.registerForm.get(key);
      control?.markAsTouched();
    });
  }

  showAlert(message: string, alertClass: string, icon: string): void {
    this.alertMessage = message;
    this.alertClass = alertClass;
    this.alertIcon = icon;
  }

  clearAlert(): void {
    this.alertMessage = '';
    this.alertClass = '';
    this.alertIcon = '';
  }
}
