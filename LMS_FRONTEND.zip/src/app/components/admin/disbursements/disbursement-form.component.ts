import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { DisbursementService } from '../../../services/disbursement.service';
import { LoanDisbursement } from '../../../models/loan.model';

@Component({
  selector: 'app-disbursement-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './disbursement-form.component.html',
  styleUrl: './disbursement-form.component.css'
})
export class DisbursementFormComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly disbursementService = inject(DisbursementService);

  loading = false;
  error: string | null = null;
  disbursementId: number | null = null;
  submitting = false;
  successMessage: string | null = null;

  form = this.fb.nonNullable.group({
    loanId: [undefined as number | undefined, [Validators.required]],
    customerAccountNumber: ['', [Validators.required, Validators.pattern(/^\d{10,18}$/)]],
    referenceId: ['', [Validators.required, Validators.maxLength(64)]],
    disbursedAmount: [0, [Validators.required, Validators.min(1)]],
    disbursementMethod: ['BANK_TRANSFER', [Validators.required]],
    utrNumber: ['', [Validators.maxLength(50)]],
    status: ['PENDING', [Validators.required]]
  });

  get isEdit(): boolean {
    return this.disbursementId !== null;
  }

  get isEditMode(): boolean {
    return this.disbursementId !== null;
  }

  get disbursementForm() {
    return this.form;
  }

  ngOnInit(): void {
    const idParam = this.route.snapshot.paramMap.get('id');
    if (idParam) {
      this.disbursementId = Number(idParam);
      this.fetchAndPatch(this.disbursementId);
    }
    
    // Pre-fill form from query parameters (when coming from approved loans)
    this.route.queryParams.subscribe(params => {
      if (params['loanId']) {
        this.form.patchValue({
          loanId: Number(params['loanId']),
          disbursedAmount: Number(params['amount']) || 0
        });
      }
    });
  }

  fetchAndPatch(id: number): void {
    this.loading = true;
    this.disbursementService.getById(id).subscribe({
      next: (d) => {
        this.form.patchValue({
          loanId: d.loanId ?? undefined,
          customerAccountNumber: d.customerAccountNumber ?? '',
          referenceId: d.referenceId ?? '',
          utrNumber: d.utrNumber ?? '',
          disbursedAmount: d.amount ?? d.disbursedAmount ?? 0,
          disbursementMethod: d.disbursementMethod ?? 'BANK_TRANSFER',
          status: d.status ?? 'PENDING',
        });
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load disbursement. Please check if the disbursement exists.';
        this.loading = false;
        console.error('Error loading disbursement:', err);
      },
    });
  }

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const formData = this.form.getRawValue();
    
    // Check if disbursement already exists for this loan ID (only for new disbursements)
    if (!this.isEditMode) {
      this.disbursementService.getByLoanId(formData.loanId!).subscribe({
        next: (existingDisbursements) => {
          if (existingDisbursements && existingDisbursements.length > 0) {
            this.error = `Disbursement already exists for Loan ID ${formData.loanId}. Cannot create duplicate disbursement.`;
            return;
          }
          this.createDisbursement(formData);
        },
        error: (err) => {
          // If error means no disbursement exists, proceed with creation
          console.log('No existing disbursement found, proceeding with creation');
          this.createDisbursement(formData);
        }
      });
    } else {
      this.updateDisbursement(formData);
    }
  }

  onSubmit(): void {
    this.submit();
  }

  isFieldInvalid(fieldName: string): boolean {
    const field = this.form.get(fieldName);
    return field ? field.invalid && (field.dirty || field.touched) : false;
  }

  getFieldError(fieldName: string): string {
    const field = this.form.get(fieldName);
    if (field && field.errors && (field.dirty || field.touched)) {
      if (field.errors['required']) return `${fieldName} is required`;
      if (field.errors['maxlength']) return `${fieldName} is too long`;
      if (field.errors['min']) return `${fieldName} must be greater than 0`;
    }
    return '';
  }

  private createDisbursement(formData: any): void {
    const payload: Omit<LoanDisbursement, 'id'> = {
      loanId: formData.loanId,
      customerAccountNumber: formData.customerAccountNumber,
      referenceId: formData.referenceId,
      utrNumber: formData.utrNumber,
      amount: formData.disbursedAmount,
      disbursementMethod: formData.disbursementMethod,
      status: formData.status as 'PENDING' | 'APPROVED' | 'DISBURSED' | 'FAILED'
    };

    this.disbursementService.create(payload).subscribe({
      next: () => {
        this.router.navigate(['/admin/disbursements']);
      },
      error: (err) => {
        this.error = 'Failed to create disbursement. Please try again.';
        console.error(err);
      }
    });
  }

  private updateDisbursement(formData: any): void {
    const payload: Omit<LoanDisbursement, 'id'> = {
      loanId: formData.loanId,
      customerAccountNumber: formData.customerAccountNumber,
      referenceId: formData.referenceId,
      utrNumber: formData.utrNumber,
      amount: formData.disbursedAmount,
      disbursementMethod: formData.disbursementMethod,
      status: formData.status as 'PENDING' | 'APPROVED' | 'DISBURSED' | 'FAILED'
    };

    this.disbursementService.update(this.disbursementId!, payload).subscribe({
      next: () => {
        this.router.navigate(['/admin/disbursements']);
      },
      error: (err) => {
        this.error = 'Failed to update disbursement. Please try again.';
        console.error(err);
      }
    });
  }
}
