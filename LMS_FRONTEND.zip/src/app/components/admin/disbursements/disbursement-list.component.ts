import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink, Router } from '@angular/router';
import { DisbursementService } from '../../../services/disbursement.service';
import { LoanService } from '../../../services/loan.service';
import { LoanDisbursement, LoanApplication } from '../../../models/loan.model';

@Component({
  selector: 'app-disbursement-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './disbursement-list.component.html',
  styleUrls: ['./disbursement-list.component.css']
})
export class DisbursementListComponent implements OnInit {
  disbursements: LoanDisbursement[] = [];
  filteredDisbursements: LoanDisbursement[] = [];
  approvedLoans: LoanApplication[] = [];
  searchTerm: string = '';
  loading = false;
  error: string | null = null;

  constructor(
    private disbursementService: DisbursementService,
    private loanService: LoanService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadDisbursements();
    this.loadApprovedLoans();
  }

  refreshData(): void {
    this.loadDisbursements();
    this.loadApprovedLoans();
  }

  loadDisbursements(): void {
    this.loading = true;
    this.error = null;
    
    this.disbursementService.getAll().subscribe({
      next: (data) => {
        console.log('Raw disbursement data from backend:', data);
        
        // Direct assignment - no duplicate removal
        this.disbursements = data || [];
        this.filteredDisbursements = data || [];
        this.loading = false;
        
        console.log('Disbursements loaded successfully:', this.disbursements.length, 'records');
        
        if (this.disbursements.length === 0) {
          this.error = 'No disbursements found in database.';
        }
      },
      error: (err) => {
        this.error = 'Failed to load disbursements. Please try again.';
        this.loading = false;
        console.error('Error loading disbursements:', err);
        console.error('Full error details:', err.error);
      }
    });
  }

  editDisbursement(id: number): void {
    this.router.navigate(['/admin/disbursements', id, 'edit']);
  }

  deleteDisbursement(id: number): void {
    if (confirm('Are you sure you want to cancel this disbursement?')) {
      this.disbursementService.cancelDisbursement(id).subscribe({
        next: () => {
          this.loadDisbursements();
        },
        error: (err) => {
          console.error('Error canceling disbursement:', err);
        }
      });
    }
  }

  approveDisbursement(id: number): void {
    if (confirm('Are you sure you want to approve this disbursement?')) {
      this.disbursementService.approve(id).subscribe({
        next: () => {
          this.loadDisbursements();
        },
        error: (err) => {
          console.error('Error approving disbursement:', err);
        }
      });
    }
  }

  rejectDisbursement(id: number): void {
    const reason = prompt('Please enter rejection reason:');
    if (reason) {
      this.disbursementService.reject(id, reason).subscribe({
        next: () => {
          this.loadDisbursements();
        },
        error: (err) => {
          console.error('Error rejecting disbursement:', err);
        }
      });
    }
  }

  disburseFunds(id: number): void {
    const utrNumber = prompt('Enter UTR Number for disbursement:');
    if (utrNumber && utrNumber.trim()) {
      this.disbursementService.updateUTR(id, utrNumber.trim()).subscribe({
        next: () => {
          this.loadDisbursements();
        },
        error: (err) => {
          console.error('Error disbursing funds:', err);
        }
      });
    }
  }

  markAsFailed(id: number): void {
    const reason = prompt('Please enter failure reason:');
    if (reason) {
      this.disbursementService.markFailed(id, reason).subscribe({
        next: () => {
          this.loadDisbursements();
        },
        error: (err) => {
          console.error('Error marking as failed:', err);
        }
      });
    }
  }

  getStatusCount(status: string): number {
    if (status === 'COMPLETED') {
      return this.disbursements.filter(d => d.status === 'DISBURSED').length;
    }
    if (status === 'FAILED') {
      return this.disbursements.filter(d => d.status === 'FAILED' || d.status === 'REJECTED').length;
    }
    return this.disbursements.filter(d => d.status === status).length;
  }

  getStatusClass(status: string): string {
    switch (status) {
      case 'PENDING': return 'status-pending';
      case 'APPROVED': return 'status-approved';
      case 'DISBURSED': return 'status-disbursed';
      case 'FAILED': return 'status-failed';
      case 'REJECTED': return 'status-rejected';
      default: return 'status-pending';
    }
  }

  onSearch(): void {
    if (!this.searchTerm.trim()) {
      this.filteredDisbursements = this.disbursements;
      return;
    }

    const searchLower = this.searchTerm.toLowerCase().trim();
    this.filteredDisbursements = this.disbursements.filter(disbursement => {
      return (
        disbursement.id?.toString().includes(searchLower) ||
        disbursement.loanId?.toString().includes(searchLower) ||
        disbursement.referenceId?.toLowerCase().includes(searchLower) ||
        disbursement.utrNumber?.toLowerCase().includes(searchLower) ||
        disbursement.status?.toLowerCase().includes(searchLower)
      );
    });
  }

  clearSearch(): void {
    this.searchTerm = '';
    this.filteredDisbursements = this.disbursements;
  }

  loadApprovedLoans(): void {
    console.log('Loading approved loans...');
    // Get both approved loans and existing disbursements to filter out already disbursed loans
    this.loanService.getApprovedLoans().subscribe({
      next: (loans) => {
        console.log('Approved loans loaded:', loans);
        
        // Get existing disbursements to filter out loans that already have disbursements
        this.disbursementService.getAll().subscribe({
          next: (disbursements) => {
            const disbursedLoanIds = disbursements.map(d => d.loanId);
            console.log('Disbursed loan IDs:', disbursedLoanIds);
            
            // Filter out loans that already have disbursements
            this.approvedLoans = loans.filter(loan => !disbursedLoanIds.includes(loan.id));
            console.log('Filtered approved loans (excluding disbursed):', this.approvedLoans);
          },
          error: (err) => {
            console.error('Error loading disbursements for filtering:', err);
            // If disbursements can't be loaded, show all approved loans
            this.approvedLoans = loans;
          }
        });
      },
      error: (err) => {
        console.error('Error loading approved loans:', err);
      }
    });
  }

  createDisbursementFromLoan(loan: LoanApplication): void {
    this.router.navigate(['/admin/disbursements/new'], {
      queryParams: {
        loanId: loan.id,
        amount: loan.amount || loan.loanAmount,
        applicantName: loan.applicantName
      }
    }).then(() => {
      // Refresh the approved loans list after navigation to remove the disbursed loan
      setTimeout(() => {
        this.loadApprovedLoans();
      }, 1000);
    });
  }
}
