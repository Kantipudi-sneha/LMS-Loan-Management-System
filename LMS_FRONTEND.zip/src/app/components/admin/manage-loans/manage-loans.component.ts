import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminService } from '../../../services/admin.service';
import { AuthService } from '../../../services/auth.service';
import { LoanApplication } from '../../../models/loan.model';
import { AdminApprovalDTO } from '../../../models/admin.model';

@Component({
  selector: 'app-manage-loans',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container">
      <div class="row mb-4">
        <div class="col-12">
          <h2>
            <i class="fas fa-file-invoice-dollar me-2"></i>Manage Loan Applications
          </h2>
          <p class="text-muted">Review and process loan applications from users</p>
        </div>
      </div>

      <!-- Filters -->
      <div class="row mb-4">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <div class="row">
                <div class="col-md-4 mb-3">
                  <label for="statusFilter" class="form-label">Filter by Status</label>
                  <select id="statusFilter" class="form-select" [(ngModel)]="statusFilter" (change)="applyFilters()">
                    <option value="ALL">All Applications</option>
                    <option value="PENDING">Pending</option>
                    <option value="APPROVED">Approved</option>
                    <option value="REJECTED">Rejected</option>
                  </select>
                </div>
                <div class="col-md-4 mb-3">
                  <label for="typeFilter" class="form-label">Filter by Loan Type</label>
                  <select id="typeFilter" class="form-select" [(ngModel)]="typeFilter" (change)="applyFilters()">
                    <option value="ALL">All Types</option>
                    <option value="Personal Loan">Personal Loan</option>
                    <option value="Business Loan">Business Loan</option>
                    <option value="Home Loan">Home Loan</option>
                    <option value="Education Loan">Education Loan</option>
                    <option value="Vehicle Loan">Vehicle Loan</option>
                  </select>
                </div>
                <div class="col-md-4 mb-3">
                  <label for="searchFilter" class="form-label">Search</label>
                  <input type="text" id="searchFilter" class="form-control" placeholder="Search by ID or name" 
                    [(ngModel)]="searchQuery" (input)="applyFilters()">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Loading State -->
      <div *ngIf="isLoading" class="row mb-4">
        <div class="col-12 text-center py-5">
          <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
          <p class="mt-3">Loading loan applications...</p>
        </div>
      </div>

      <!-- Error State -->
      <div *ngIf="errorMessage && !isLoading" class="row mb-4">
        <div class="col-12">
          <div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle me-2"></i>
            {{ errorMessage }}
            <button class="btn btn-sm btn-outline-danger ms-3" (click)="loadLoanApplications()">
              <i class="fas fa-sync-alt me-1"></i>Retry
            </button>
          </div>
        </div>
      </div>

      <!-- Empty State -->
      <div *ngIf="!isLoading && !errorMessage && filteredLoans.length === 0" class="row mb-4">
        <div class="col-12 text-center py-5">
          <i class="fas fa-search fa-3x text-muted mb-3"></i>
          <h3>No Loan Applications Found</h3>
          <p class="text-muted">There are no loan applications matching your current filters.</p>
          <button class="btn btn-outline-primary" (click)="resetFilters()">
            <i class="fas fa-undo me-1"></i>Reset Filters
          </button>
        </div>
      </div>

      <!-- Loans Table -->
      <div *ngIf="!isLoading && !errorMessage && filteredLoans.length > 0" class="row mb-4">
        <div class="col-12">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>User</th>
                  <th>Loan Type</th>
                  <th>Amount</th>
                  <th>Tenure</th>
                  <th>Status</th>
                  <th>Applied Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let loan of filteredLoans">
                  <td>{{ loan.id }}</td>
                  <td>{{ getUserName(loan) }}</td>
                  <td>{{ getLoanType(loan) }}</td>
                  <td>₹{{ loan.amount || loan.loanAmount | number:'1.0-0' }}</td>
                  <td>{{ getTenure(loan) }} months</td>
                  <td>
                    <span class="badge" [ngClass]="{
                      'bg-warning': loan.status === 'PENDING',
                      'bg-success': loan.status === 'APPROVED',
                      'bg-danger': loan.status === 'REJECTED'
                    }">
                      {{ loan.status }}
                    </span>
                  </td>
                  <td>{{ loan.applicationDate | date:'mediumDate' }}</td>
                  <td>
                    <div class="btn-group">
                      <button class="btn btn-sm btn-outline-primary" (click)="viewLoanDetails(loan)">
                        <i class="fas fa-eye me-1"></i>View
                      </button>
                      <button *ngIf="loan.status === 'PENDING'" class="btn btn-sm btn-success" (click)="approveLoan(loan)">
                        <i class="fas fa-check me-1"></i>Approve
                      </button>
                      <button *ngIf="loan.status === 'PENDING'" class="btn btn-sm btn-danger" (click)="rejectLoan(loan)">
                        <i class="fas fa-times me-1"></i>Reject
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Loan Details Modal -->
      <div *ngIf="selectedLoan" class="modal fade show" tabindex="-1" style="display: block;">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">
                <i class="fas fa-file-invoice-dollar me-2"></i>
                Loan Application Details
              </h5>
              <button type="button" class="btn-close" (click)="closeModal()"></button>
            </div>
            <div class="modal-body">
              <div class="row mb-3">
                <div class="col-md-6">
                  <h6>Application ID</h6>
                  <p>{{ selectedLoan.id }}</p>
                </div>
                <div class="col-md-6">
                  <h6>Status</h6>
                  <span class="badge" [ngClass]="{
                    'bg-warning': selectedLoan.status === 'PENDING',
                    'bg-success': selectedLoan.status === 'APPROVED',
                    'bg-danger': selectedLoan.status === 'REJECTED'
                  }">
                    {{ selectedLoan.status }}
                  </span>
                </div>
              </div>
              
              <div class="row mb-3">
                <div class="col-md-6">
                  <h6>User ID</h6>
                  <p>{{ selectedLoan.userId }}</p>
                </div>
                <div class="col-md-6">
                  <h6>Application Date</h6>
                  <p>{{ selectedLoan.applicationDate | date:'medium' }}</p>
                </div>
              </div>
              
              <div class="row mb-3">
                <div class="col-md-6">
                  <h6>Loan Type</h6>
                  <p>{{ selectedLoan.loanType }}</p>
                </div>
                <div class="col-md-6">
                  <h6>Loan Amount</h6>
                  <p>₹{{ selectedLoan.loanAmount | number:'1.0-0' }}</p>
                </div>
              </div>
              
              <div class="row mb-3">
                <div class="col-md-6">
                  <h6>Interest Rate</h6>
                  <p>N/A</p>
                </div>
                <div class="col-md-6">
                  <h6>Tenure</h6>
                  <p>{{ selectedLoan.tenure }} months</p>
                </div>
              </div>
              
              <div class="row mb-3">
                <div class="col-12">
                  <h6>Purpose</h6>
                  <p>{{ selectedLoan.purpose }}</p>
                </div>
              </div>
              
              <div *ngIf="selectedLoan.status === 'REJECTED'" class="row mb-3">
                <div class="col-12">
                  <h6>Rejection Reason</h6>
                  <p class="text-danger">{{ selectedLoan.rejectionReason || 'No reason provided' }}</p>
                </div>
              </div>
              
              <div *ngIf="selectedLoan.status === 'PENDING'" class="row mb-3">
                <div class="col-12">
                  <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    This application is pending review. Use the buttons below to approve or reject.
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" (click)="closeModal()">
                <i class="fas fa-times me-1"></i>Close
              </button>
              <button *ngIf="selectedLoan.status === 'PENDING'" type="button" class="btn btn-success" (click)="approveLoan(selectedLoan)">
                <i class="fas fa-check me-1"></i>Approve Loan
              </button>
              <button *ngIf="selectedLoan.status === 'PENDING'" type="button" class="btn btn-danger" (click)="rejectLoan(selectedLoan)">
                <i class="fas fa-times me-1"></i>Reject Loan
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Modal Backdrop -->
      <div *ngIf="selectedLoan" class="modal-backdrop fade show"></div>

      <!-- Approval Modal -->
      <div *ngIf="showApprovalModal" class="modal fade show" tabindex="-1" style="display: block;">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">
          <i class="fas fa-check-circle me-2"></i>
          Approve Loan Application
        </h5>
        <button type="button" class="btn-close" (click)="closeApprovalModal()"></button>
      </div>
      <div class="modal-body">
        <p>You are about to approve loan application #{{ loanToApprove?.id }}.</p>
        
        <div class="alert alert-info">
          <i class="fas fa-info-circle me-2"></i>
          This will approve the loan application and change its status to APPROVED.
        </div>

        <!-- Admin ID -->
        <div class="mb-3">
          <label class="form-label">Admin ID</label>
          <input type="number" class="form-control" [(ngModel)]="approvalData.adminId" placeholder="Enter your admin ID" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" (click)="closeApprovalModal()" [disabled]="isSubmitting">
          <i class="fas fa-times me-1"></i>Cancel
        </button>
        <button type="button" class="btn btn-success" (click)="confirmApproval()" [disabled]="isSubmitting">
          <i class="fas fa-check me-1"></i>
          <span *ngIf="!isSubmitting">Confirm Approval</span>
          <span *ngIf="isSubmitting">Processing...</span>
        </button>
      </div>
    </div>
  </div>
</div>

      
      <!-- Rejection Modal -->
      <div *ngIf="showRejectionModal" class="modal fade show" tabindex="-1" style="display: block;">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">
                <i class="fas fa-times-circle me-2"></i>
                Reject Loan Application
              </h5>
              <button type="button" class="btn-close" (click)="closeRejectionModal()"></button>
            </div>
            <div class="modal-body">
              <p>You are about to reject loan application #{{ loanToReject?.id }}.</p>
              
              <div class="mb-3">
                <label for="rejectionReason" class="form-label">Rejection Reason</label>
                <textarea id="rejectionReason" class="form-control" rows="3" [(ngModel)]="rejectionReason" placeholder="Please provide a reason for rejection"></textarea>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" (click)="closeRejectionModal()">
                <i class="fas fa-times me-1"></i>Cancel
              </button>
              <button type="button" class="btn btn-danger" (click)="confirmRejection()" [disabled]="isSubmitting || !rejectionReason">
                <i class="fas fa-times me-1"></i>
                <span *ngIf="!isSubmitting">Confirm Rejection</span>
                <span *ngIf="isSubmitting">Processing...</span>
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Rejection Modal Backdrop -->
      <div *ngIf="showRejectionModal || showApprovalModal" class="modal-backdrop fade show"></div>
    </div>
  `,
  styles: [`
    .modal {
      background-color: rgba(0, 0, 0, 0.5);
    }
    
    .badge {
      padding: 0.5em 0.8em;
    }
    
    .btn-group .btn {
      margin-right: 0.25rem;
    }
    
    .btn-group .btn:last-child {
      margin-right: 0;
    }
    /* Add this to your component's styles or global styles */
.modal-footer .btn-success {
  /* Basic styling */
  background-color: #28a745; /* Bootstrap success green */
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: 0.25rem;
  font-weight: 500;
  
  /* Ensure clickability */
  position: relative;
  z-index: 1050; /* Higher than modal backdrop */
  cursor: pointer;
  pointer-events: auto;
  
  /* Hover/focus states */
  transition: all 0.2s ease;
}

.modal-footer .btn-success:hover {
  background-color: #218838; /* Darker green on hover */
  transform: translateY(-1px);
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.modal-footer .btn-success:focus {
  outline: none;
  box-shadow: 0 0 0 0.2rem rgba(40, 167, 69, 0.5);
}

.modal-footer .btn-success:active {
  transform: translateY(0);
}

/* Disabled state styling */
.modal-footer .btn-success[disabled] {
  background-color: #6c757d; /* Bootstrap secondary gray */
  cursor: not-allowed;
  opacity: 0.65;
  transform: none;
  box-shadow: none;
}

/* Ensure modal backdrop isn't blocking clicks */
.modal-backdrop {
  z-index: 1040 !important; /* Should be lower than modal content */
}

.modal-content {
  z-index: 1050 !important; /* Higher than backdrop */
}
  `]
})
export class ManageLoansComponent implements OnInit {
  approvalComments: string = '';
  loans: LoanApplication[] = [];
  filteredLoans: LoanApplication[] = [];
  isLoading = false;
  errorMessage = '';
  
  // Filters
  statusFilter = 'ALL';
  typeFilter = 'ALL';
  searchQuery = '';
  
  // Modal state
  selectedLoan: LoanApplication | null = null;
  showApprovalModal = false;
  showRejectionModal = false;
  loanToApprove: LoanApplication | null = null;
  loanToReject: LoanApplication | null = null;
  rejectionReason = '';
  isSubmitting = false;
  
  // Approval data
approvalData: any = {
  adminId: 0,
  approve: false
};


  constructor(private adminService: AdminService, private authService: AuthService) {}

  ngOnInit(): void {
    this.loadLoanApplications();
  }

  getUserName(loan: any): string {
    // Try different possible username fields
    if (loan.applicantName) {
      return loan.applicantName;
    }
    if (loan.username) {
      return loan.username;
    }
    if (loan.userName) {
      return loan.userName;
    }
    // Fallback to User ID if no name is available
    return `User ${loan.userId || loan.id || 'Unknown'}`;
  }

  getLoanType(loan: any): string {
    console.log('Getting loan type for loan:', loan);
    // Try different possible loan type fields
    if (loan.loanType) {
      return loan.loanType;
    }
    if (loan.type) {
      return loan.type;
    }
    if (loan.loan_type) {
      return loan.loan_type;
    }
    if (loan.purpose) {
      return loan.purpose;
    }
    // Based on your data, it seems loan type might not be in the response
    // Let's return a default based on amount ranges or other logic
    const amount = loan.amount || loan.loanAmount || 0;
    if (amount >= 300000) {
      return 'Home Loan';
    } else if (amount >= 100000) {
      return 'Personal Loan';
    } else {
      return 'Personal Loan';
    }
  }

  getTenure(loan: any): string {
    console.log('Getting tenure for loan:', loan);
    console.log('Available properties:', Object.keys(loan));
    
    // Try different possible tenure fields
    if (loan.tenure && loan.tenure !== 'months') {
      console.log('Found tenure:', loan.tenure);
      return loan.tenure;
    }
    if (loan.tenureInMonths) {
      console.log('Found tenureInMonths:', loan.tenureInMonths);
      return loan.tenureInMonths;
    }
    if (loan['tenureInMonths']) {
      console.log('Found tenureInMonths via bracket notation:', loan['tenureInMonths']);
      return loan['tenureInMonths'];
    }
    if (loan.tenure_months) {
      console.log('Found tenure_months:', loan.tenure_months);
      return loan.tenure_months;
    }
    if (loan.loanTenure) {
      console.log('Found loanTenure:', loan.loanTenure);
      return loan.loanTenure;
    }
    
    console.log('No tenure found, returning N/A');
    return 'N/A';
  }

  loadLoanApplications(): void {
    this.isLoading = true;
    this.errorMessage = '';
    
    this.adminService.getAllLoanApplications().subscribe({
      next: (loans) => {
        console.log('Raw loan applications data from backend:', loans);
        this.loans = loans;
        this.filteredLoans = [...loans];
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading loan applications:', error);
        this.errorMessage = 'Failed to load loan applications. Please try again.';
        this.isLoading = false;
      }
    });
  }

  applyFilters(): void {
    console.log('Applying filters:', { statusFilter: this.statusFilter, typeFilter: this.typeFilter, searchQuery: this.searchQuery });
    console.log('Total loans before filtering:', this.loans.length);
    
    this.filteredLoans = this.loans.filter(loan => {
      console.log('Filtering loan:', { id: loan.id, status: loan.status, loanType: this.getLoanType(loan) });
      
      // Status filter
      if (this.statusFilter !== 'ALL' && loan.status !== this.statusFilter) {
        console.log('Filtered out by status:', loan.status, 'vs', this.statusFilter);
        return false;
      }
      
      // Type filter - use helper method to get loan type
      const loanType = this.getLoanType(loan);
      if (this.typeFilter !== 'ALL' && loanType !== this.typeFilter) {
        console.log('Filtered out by type:', loanType, 'vs', this.typeFilter);
        return false;
      }
      
      // Search query
      if (this.searchQuery) {
        const query = this.searchQuery.toLowerCase();
        const userName = this.getUserName(loan);
        const matchesSearch = (
          loan.id?.toString().includes(query) ||
          loan.userId?.toString().includes(query) ||
          loanType.toLowerCase().includes(query) ||
          loan.purpose?.toLowerCase().includes(query) ||
          userName.toLowerCase().includes(query)
        );
        if (!matchesSearch) {
          console.log('Filtered out by search query');
          return false;
        }
      }
      
      console.log('Loan passed all filters');
      return true;
    });
    
    console.log('Filtered loans count:', this.filteredLoans.length);
  }

  resetFilters(): void {
    this.statusFilter = 'ALL';
    this.typeFilter = 'ALL';
    this.searchQuery = '';
    this.filteredLoans = [...this.loans];
  }

  viewLoanDetails(loan: LoanApplication): void {
    this.selectedLoan = loan;
  }

  closeModal(): void {
    this.selectedLoan = null;
  }

approveLoan(loan: LoanApplication): void {
  this.loanToApprove = loan;
  this.approvalData = {
    adminId: 4, // Pre-fill with 4 as requested
    approve: true
  };
  this.isSubmitting = false;
  this.showApprovalModal = true;
  this.selectedLoan = null;
}

closeApprovalModal(): void {
  this.showApprovalModal = false;
  this.loanToApprove = null;
  this.isSubmitting = false;
  this.approvalData = {
    adminId: 0,
    approve: false
  };
}


confirmApproval(): void {
  if (!this.loanToApprove || !this.approvalData.adminId) {
    console.error('Missing required approval data:', {
      loanToApprove: this.loanToApprove,
      adminId: this.approvalData.adminId
    });
    this.errorMessage = 'Missing required approval information.';
    return;
  }

  this.isSubmitting = true;
  this.errorMessage = '';

  console.log('Sending approval data:', this.approvalData);

  this.adminService.approveLoanApplication(this.loanToApprove.id!, this.approvalData).subscribe({
    next: (response) => {
      console.log('Approval successful:', response);
      
      const index = this.loans.findIndex(l => l.id === this.loanToApprove!.id);
      if (index !== -1) {
        this.loans[index].status = 'APPROVED';
      }

      this.applyFilters();
      this.closeApprovalModal();
    },
    error: (error) => {
      console.error('Detailed error approving loan:', {
        error: error,
        status: error.status,
        message: error.message,
        body: error.error
      });
      this.isSubmitting = false;
      
      if (error.status === 401) {
        this.errorMessage = 'Authentication failed. Please login again.';
      } else if (error.status === 403) {
        this.errorMessage = 'You do not have permission to approve loans.';
      } else if (error.status === 404) {
        this.errorMessage = 'Loan application not found.';
      } else if (error.status === 400) {
        this.errorMessage = 'Invalid approval data. Please check all fields.';
      } else {
        this.errorMessage = `Failed to approve loan: ${error.error?.message || error.message || 'Unknown error'}`;
      }
    }
  });
}



  rejectLoan(loan: LoanApplication): void {
    this.loanToReject = loan;
    this.showRejectionModal = true;
    
    // Close the details modal if open
    this.selectedLoan = null;
  }

  closeRejectionModal(): void {
    this.showRejectionModal = false;
    this.loanToReject = null;
    this.rejectionReason = '';
  }

  confirmRejection(): void {
    if (!this.loanToReject || !this.rejectionReason) return;
    
    this.isSubmitting = true;
    
    this.adminService.rejectLoanApplication(this.loanToReject.id!, this.rejectionReason).subscribe({
      next: (response) => {
        // Update the loan in the list
        const index = this.loans.findIndex(l => l.id === this.loanToReject!.id);
        if (index !== -1) {
          this.loans[index].status = 'REJECTED';
          this.loans[index].rejectionReason = this.rejectionReason;
        }
        
        // Apply filters again
        this.applyFilters();
        
        // Close modal
        this.showRejectionModal = false;
        this.loanToReject = null;
        this.rejectionReason = '';
        this.isSubmitting = false;
      },
      error: (error) => {
        console.error('Error rejecting loan:', error);
        this.isSubmitting = false;
        // You might want to show an error message here
      }
    });
  }
}