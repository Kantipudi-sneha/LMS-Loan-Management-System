import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PaymentResponseDTO, Penalty } from 'src/app/models/payment.model';
import { PaymentService } from 'src/app/services/payment.service';
import { LoanService } from 'src/app/services/loan.service';
import { Loan } from 'src/app/models/loan.model';

@Component({
  selector: 'app-manage-payments',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './manage-payments.component.html',
  styleUrls: ['./manage-payments.component.css']
})
export class ManagePaymentsComponent implements OnInit {
  payments: PaymentResponseDTO[] = [];
  penalties: Penalty[] = [];
  loans: Loan[] = [];
  selectedLoanId: string = '';
  statusMessage: string = '';
  isLoading: boolean = false;
  
  // For penalty creation
  newPenalty = {
    loanId: '',
    emiNumber: 1,
    penaltyAmount: 0,
    reason: ''
  };

  constructor(
    private paymentService: PaymentService,
    private loanService: LoanService
  ) {}

  ngOnInit(): void {
    this.loadLoans();
    this.loadAllPayments();
  }

  loadLoans(): void {
    this.isLoading = true;
    this.loanService.getAllLoans().subscribe({
      next: (data) => {
        this.loans = data;
        this.isLoading = false;
      },
      error: (err) => {
        this.statusMessage = 'Failed to load loans.';
        this.isLoading = false;
        console.error(err);
      }
    });
  }

  loadAllPayments(): void {
    this.isLoading = true;
    this.paymentService.getAllPayments().subscribe({
      next: (data) => {
        this.payments = data;
        this.isLoading = false;
      },
      error: (err) => {
        this.statusMessage = 'Failed to load payments.';
        this.isLoading = false;
        console.error(err);
      }
    });
  }

  loadPaymentsByLoanId(): void {
    if (!this.selectedLoanId) {
      this.loadAllPayments();
      return;
    }

    this.isLoading = true;
    this.paymentService.getPaymentsByLoanId(this.selectedLoanId).subscribe({
      next: (data) => {
        this.payments = data;
        this.loadPenaltiesByLoanId();
        this.isLoading = false;
      },
      error: (err) => {
        this.statusMessage = 'Failed to load payments for the selected loan.';
        this.isLoading = false;
        console.error(err);
      }
    });
  }

  loadPenaltiesByLoanId(): void {
    if (!this.selectedLoanId) {
      this.penalties = [];
      return;
    }

    this.paymentService.getPenaltiesByLoanId(this.selectedLoanId).subscribe({
      next: (data) => {
        this.penalties = data;
      },
      error: (err) => {
        console.error('Failed to load penalties:', err);
      }
    });
  }

  createPenalty(): void {
    if (!this.newPenalty.loanId || this.newPenalty.penaltyAmount <= 0 || !this.newPenalty.reason) {
      this.statusMessage = 'Please enter valid penalty details.';
      return;
    }

    this.isLoading = true;
    this.paymentService.createPenalty(this.newPenalty).subscribe({
      next: (res) => {
        this.statusMessage = 'Penalty created successfully!';
        this.newPenalty = {
          loanId: this.selectedLoanId,
          emiNumber: 1,
          penaltyAmount: 0,
          reason: ''
        };
        this.loadPenaltiesByLoanId();
        this.isLoading = false;
      },
      error: (err) => {
        this.statusMessage = 'Failed to create penalty. Please try again.';
        this.isLoading = false;
        console.error(err);
      }
    });
  }

  updatePenaltyStatus(penaltyId: number, status: string): void {
    this.isLoading = true;
    this.paymentService.updatePenaltyStatus(penaltyId, status).subscribe({
      next: (res) => {
        this.statusMessage = `Penalty status updated to ${status}!`;
        this.loadPenaltiesByLoanId();
        this.isLoading = false;
      },
      error: (err) => {
        this.statusMessage = 'Failed to update penalty status.';
        this.isLoading = false;
        console.error(err);
      }
    });
  }

  getPaymentStatusClass(status: string): string {
    switch (status.toLowerCase()) {
      case 'paid':
        return 'status-paid';
      case 'pending':
        return 'status-pending';
      case 'failed':
        return 'status-failed';
      default:
        return '';
    }
  }

  getPenaltyStatusClass(status: string): string {
    switch (status.toLowerCase()) {
      case 'paid':
        return 'status-paid';
      case 'pending':
        return 'status-pending';
      case 'waived':
        return 'status-waived';
      default:
        return '';
    }
  }
}