import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationEnd, Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { AdminService } from '../../../services/admin.service';
import { LoanApplication } from 'src/app/models/loan.model';
import { filter, Subscription } from 'rxjs';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="container">
      <div class="row">
        <div class="col-12">
          <h2 class="mb-4">
            <i class="fas fa-tachometer-alt me-2"></i>Admin Dashboard
          </h2>
        </div>
      </div>

      <!-- Quick Stats -->
      <div class="row mb-4">
        <div class="col-md-3 mb-3">
          <div class="card text-center">
            <div class="card-body">
              <i class="fas fa-users fa-2x text-primary mb-2"></i>
              <h5 class="card-title">{{ stats.totalUsers }}</h5>
              <p class="card-text">Total Users</p>
            </div>
          </div>
        </div>
        <div class="col-md-3 mb-3">
          <div class="card text-center">
            <div class="card-body">
              <i class="fas fa-file-invoice-dollar fa-2x text-warning mb-2"></i>
              <h5 class="card-title">{{ stats.pendingLoans }}</h5>
              <p class="card-text">Pending Loans</p>
            </div>
          </div>
        </div>
        <div class="col-md-3 mb-3">
          <div class="card text-center">
            <div class="card-body">
              <i class="fas fa-check-circle fa-2x text-success mb-2"></i>
              <h5 class="card-title">{{ stats.approvedLoans }}</h5>
              <p class="card-text">Approved Loans</p>
            </div>
          </div>
        </div>
        <div class="col-md-3 mb-3">
          <div class="card text-center">
            <div class="card-body">
              <i class="fas fa-credit-card fa-2x text-info mb-2"></i>
              <h5 class="card-title">{{ stats.totalPayments }}</h5>
              <p class="card-text">Total Payments</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Quick Actions -->
      <div class="row mb-4">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h5 class="mb-0">
                <i class="fas fa-bolt me-2"></i>Quick Actions
              </h5>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-4 mb-3">
                  <a routerLink="/admin/users" class="btn btn-primary btn-lg w-100">
                    <i class="fas fa-users me-2"></i>Manage Users
                  </a>
                </div>
                <div class="col-md-4 mb-3">
                  <a routerLink="/admin/loans" class="btn btn-outline-primary btn-lg w-100">
                    <i class="fas fa-file-invoice-dollar me-2"></i>Manage Loans
                  </a>
                </div>
                <div class="col-md-4 mb-3">
                  <a routerLink="/admin/payments" class="btn btn-outline-success btn-lg w-100">
                    <i class="fas fa-credit-card me-2"></i>View Payments
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Recent Activities -->
      <div class="row mb-4">
        <div class="col-md-6 mb-4">
          <div class="card">
            <div class="card-header">
              <h5 class="mb-0">
                <i class="fas fa-clock me-2"></i>Pending Loan Applications
              </h5>
            </div>
            <div class="card-body">
              <div *ngIf="pendingLoans.length === 0" class="text-center py-4">
                <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                <p class="text-success">No pending loan applications!</p>
              </div>
              
              <div *ngIf="pendingLoans.length > 0" class="list-group">
                <div *ngFor="let loan of pendingLoans.slice(0, 5)" class="list-group-item d-flex justify-content-between align-items-center">
                  <div>
                    <strong>{{ loan.loanType }}</strong>
                    <br>
                    <small class="text-muted">₹{{ loan.loanAmount | number:'1.0-0' }} - {{ loan.purpose }}</small>
                  </div>
                  <a routerLink="/admin/loans" class="btn btn-sm btn-primary">
                    <i class="fas fa-eye me-1"></i>Review
                  </a>
                </div>
              </div>
              
              <div *ngIf="pendingLoans.length > 5" class="text-center mt-3">
                <a routerLink="/admin/loans" class="btn btn-outline-primary">
                  View All Pending Applications
                </a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-6 mb-4">
          <div class="card">
            <div class="card-header">
              <h5 class="mb-0">
                <i class="fas fa-user-plus me-2"></i>Recent User Registrations
              </h5>
            </div>
            <div class="card-body">
              <div *ngIf="recentUsers.length === 0" class="text-center py-4">
                <i class="fas fa-users fa-3x text-muted mb-3"></i>
                <p class="text-muted">No recent user registrations</p>
              </div>
              
              <div *ngIf="recentUsers.length > 0" class="list-group">
                <div *ngFor="let user of recentUsers.slice(0, 5)" class="list-group-item d-flex justify-content-between align-items-center">
                  <div>
                    <strong>{{ user.username }}</strong>
                    <br>
                    <small class="text-muted">{{ user.email }}</small>
                  </div>
                  <span class="badge" [ngClass]="{
                    'bg-success': user.isActive,
                    'bg-danger': !user.isActive
                  }">
                    {{ user.isActive ? 'Active' : 'Inactive' }}
                  </span>
                </div>
              </div>
              
              <div *ngIf="recentUsers.length > 5" class="text-center mt-3">
                <a routerLink="/admin/users" class="btn btn-outline-primary">
                  View All Users
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- System Status -->
      <div class="row mb-4">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h5 class="mb-0">
                <i class="fas fa-server me-2"></i>System Status
              </h5>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <h6>Backend Status</h6>
                  <div class="d-flex align-items-center">
                    <div class="status-indicator online me-2"></div>
                    <span class="text-success">Online</span>
                  </div>
                  <small class="text-muted">Connected to Spring Boot backend</small>
                </div>
                <div class="col-md-6">
                  <h6>Database Status</h6>
                  <div class="d-flex align-items-center">
                    <div class="status-indicator online me-2"></div>
                    <span class="text-success">Connected</span>
                  </div>
                  <small class="text-muted">MySQL database operational</small>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .card {
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .card:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    }
    
    .text-primary {
      color: #667eea !important;
    }
    
    .text-success {
      color: #56ab2f !important;
    }
    
    .text-warning {
      color: #ffc107 !important;
    }
    
    .text-info {
      color: #17a2b8 !important;
    }
    
    .badge {
      padding: 8px 12px;
      border-radius: 20px;
      font-size: 0.8rem;
    }
    
    .badge-success {
      background: linear-gradient(135deg, #56ab2f 0%, #a8e6cf 100%);
      color: white;
    }
    
    .badge-danger {
      background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);
      color: white;
    }
    
    .btn {
      border-radius: 10px;
      font-weight: 600;
    }
    
    .btn-lg {
      padding: 15px 25px;
    }
    
    .list-group-item {
      border: none;
      border-radius: 10px;
      margin-bottom: 10px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
    
    .status-indicator {
      width: 12px;
      height: 12px;
      border-radius: 50%;
    }
    
    .status-indicator.online {
      background: #56ab2f;
    }
    
    .status-indicator.offline {
      background: #ff416c;
    }
  `]
})
export class AdminDashboardComponent implements OnInit, OnDestroy {
  stats = {
    totalUsers: 0,
    pendingLoans: 0,
    approvedLoans: 0,
    totalPayments: 0
  };
  pendingLoans: LoanApplication[] = [];
  recentUsers: any[] = [];
  
  private routerSubscription?: Subscription;

  constructor(
    private authService: AuthService,
    private adminService: AdminService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadDashboardData();
    
    // Subscribe to router events to refresh data when navigating back to dashboard
    this.routerSubscription = this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event) => {
      const navigationEnd = event as NavigationEnd;
      if (navigationEnd.url.includes('/admin/dashboard') || navigationEnd.url === '/admin') {
        this.loadDashboardData();
      }
    });
  }

  ngOnDestroy(): void {
    if (this.routerSubscription) {
      this.routerSubscription.unsubscribe();
    }
  }

  loadDashboardData(): void {
    console.log('🔄 Loading dashboard data...');
    
    // Load users
    this.adminService.getAllUsers().subscribe({
      next: (users) => {
        console.log('👥 Users loaded:', users.length);
        console.log('👥 Users data:', users);
        this.recentUsers = users;
        this.stats.totalUsers = users.length;
      },
      error: (error) => {
        console.error('❌ Error loading users:', error);
        console.error('Full error object:', JSON.stringify(error, null, 2));
      }
    });

    // Load loan applications with detailed debugging
    console.log('🔍 About to call getAllLoanApplications API...');
    this.adminService.getAllLoanApplications().subscribe({
      next: (loans: LoanApplication[]) => {
        console.log('=== 📊 DETAILED LOAN ANALYSIS ===');
        console.log('✅ API call successful');
        console.log('📈 Total loans received:', loans?.length || 0);
        console.log('🗂️ Raw data type:', typeof loans);
        console.log('🗂️ Is array?', Array.isArray(loans));
        console.log('🗂️ Full raw data:', JSON.stringify(loans, null, 2));
        
        if (!loans || !Array.isArray(loans)) {
          console.error('❌ Invalid data format received');
          return;
        }

        // Detailed analysis of each loan
        console.log('\n📋 Individual loan analysis:');
        loans.forEach((loan, index) => {
          console.log(`\n--- Loan #${index + 1} ---`);
          console.log('ID:', loan.id);
          console.log('Status (raw):', loan.status);
          console.log('Status type:', typeof loan.status);
          console.log('Status length:', loan.status?.length);
          console.log('Status uppercase:', loan.status?.toUpperCase());
          console.log('Status === "APPROVED":', loan.status === 'APPROVED');
          console.log('Status.toUpperCase() === "APPROVED":', loan.status?.toUpperCase() === 'APPROVED');
          console.log('Full loan object:', JSON.stringify(loan, null, 2));
        });

        // Status distribution
        const statusCounts = loans.reduce((acc, loan) => {
          const status = loan.status || 'NULL';
          acc[status] = (acc[status] || 0) + 1;
          return acc;
        }, {} as Record<string, number>);
        
        console.log('\n📊 Status distribution:', statusCounts);
        
        // Get all unique statuses (including case variations)
        const uniqueStatuses = [...new Set(loans.map(l => l.status))];
        console.log('🏷️ All unique status values:', uniqueStatuses);

        // Filter operations with logging
        console.log('\n🔍 Filtering operations:');
        
        const pendingLoans = loans.filter(l => {
          const isPending = l.status?.toUpperCase() === 'PENDING';
          if (isPending) console.log('✅ Found pending loan:', l.id, l.status);
          return isPending;
        });
        
        const approvedLoans = loans.filter(l => {
          const isApproved = l.status?.toUpperCase() === 'APPROVED';
          if (isApproved) console.log('✅ Found approved loan:', l.id, l.status);
          return isApproved;
        });

        // Update stats
        this.pendingLoans = pendingLoans;
        this.stats.pendingLoans = pendingLoans.length;
        this.stats.approvedLoans = approvedLoans.length;

        console.log('\n📊 Final results:');
        console.log('- Pending loans:', this.stats.pendingLoans);
        console.log('- Approved loans:', this.stats.approvedLoans);
        console.log('- Pending loans data:', pendingLoans);
        console.log('- Approved loans data:', approvedLoans);
        
        // Check for common issues
        if (this.stats.approvedLoans === 0 && loans.length > 0) {
          console.log('\n🚨 POTENTIAL ISSUES:');
          console.log('1. Check if status field name is correct');
          console.log('2. Check if status values match exactly');
          console.log('3. Check if approved loans exist in database');
          console.log('4. Check backend API endpoint and query');
          
          // Try alternative status checks
          const alternativeChecks = {
            'approved': loans.filter(l => l.status?.toLowerCase() === 'approved').length,
            'Approved': loans.filter(l => l.status === 'Approved').length,
            'APPROVED': loans.filter(l => l.status === 'APPROVED').length,
            'approve': loans.filter(l => l.status?.toLowerCase() === 'approve').length,
            'accepted': loans.filter(l => l.status?.toLowerCase() === 'accepted').length,
          };
          
          console.log('🔍 Alternative status checks:', alternativeChecks);
        }
        
        console.log('=== END ANALYSIS ===\n');
      },
      error: (error) => {
        console.error('❌ Error loading loan applications:', error);
        console.error('Error details:', {
          message: error.message,
          status: error.status,
          statusText: error.statusText,
          url: error.url,
          error: error.error
        });
      }
    });
  }
}