import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminService } from '../../../services/admin.service';

@Component({
  selector: 'app-manage-users',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container">
      <div class="row mb-4">
        <div class="col-12">
          <h2>
            <i class="fas fa-users me-2"></i>Manage Users
          </h2>
          <p class="text-muted">View and manage user accounts</p>
        </div>
      </div>

      <!-- Filters -->
      <div class="row mb-4">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <div class="row">
                <div class="col-md-4 mb-3">
                  <label for="statusFilter" class="form-label">Filter by Status</label>
                  <select id="statusFilter" class="form-select" [(ngModel)]="statusFilter" (change)="applyFilters()">
                    <option value="ALL">All Users</option>
                    <option value="ACTIVE">Active</option>
                    <option value="INACTIVE">Inactive</option>
                  </select>
                </div>
                <div class="col-md-4 mb-3">
                  <label for="roleFilter" class="form-label">Filter by Role</label>
                  <select id="roleFilter" class="form-select" [(ngModel)]="roleFilter" (change)="applyFilters()">
                    <option value="ALL">All Roles</option>
                    <option value="USER">User</option>
                    <option value="ADMIN">Admin</option>
                  </select>
                </div>
                <div class="col-md-4 mb-3">
                  <label for="searchFilter" class="form-label">Search</label>
                  <input type="text" id="searchFilter" class="form-control" placeholder="Search by name or email" 
                    [(ngModel)]="searchQuery" (input)="applyFilters()">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Loading State -->
      <div *ngIf="isLoading" class="row mb-4">
        <div class="col-12 text-center py-5">
          <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
          <p class="mt-3">Loading users...</p>
        </div>
      </div>

      <!-- Error State -->
      <div *ngIf="errorMessage && !isLoading" class="row mb-4">
        <div class="col-12">
          <div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle me-2"></i>
            {{ errorMessage }}
            <button class="btn btn-sm btn-outline-danger ms-3" (click)="loadUsers()">
              <i class="fas fa-sync-alt me-1"></i>Retry
            </button>
          </div>
        </div>
      </div>

      <!-- Empty State -->
      <div *ngIf="!isLoading && !errorMessage && filteredUsers.length === 0" class="row mb-4">
        <div class="col-12 text-center py-5">
          <i class="fas fa-search fa-3x text-muted mb-3"></i>
          <h3>No Users Found</h3>
          <p class="text-muted">There are no users matching your current filters.</p>
          <button class="btn btn-outline-primary" (click)="resetFilters()">
            <i class="fas fa-undo me-1"></i>Reset Filters
          </button>
        </div>
      </div>

      <!-- Users Table -->
      <div *ngIf="!isLoading && !errorMessage && filteredUsers.length > 0" class="row mb-4">
        <div class="col-12">
          <div class="table-responsive">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let user of filteredUsers">
                  <td>{{ user.id }}</td>
                  <td>{{ user.username }}</td>
                  <td>{{ user.email }}</td>
                  <td>
                    <span class="badge" [ngClass]="{
                      'bg-primary': getUserRole(user) === 'USER',
                      'bg-info': getUserRole(user) === 'ADMIN'
                    }">
                      {{ getUserRole(user) }}
                    </span>
                  </td>
                  <td>
                    <span class="badge" [ngClass]="{
                      'bg-success': user.isActive,
                      'bg-danger': !user.isActive
                    }">
                      {{ user.isActive ? 'ACTIVE' : 'INACTIVE' }}
                    </span>
                  </td>
                  <td>
                    <div class="btn-group">
                      <button class="btn btn-sm btn-outline-primary" (click)="viewUserDetails(user)">
                        <i class="fas fa-eye me-1"></i>View
                      </button>
                      <button *ngIf="!user.isActive" class="btn btn-sm btn-success" (click)="activateUser(user)">
                        <i class="fas fa-check me-1"></i>Activate
                      </button>
                      <button *ngIf="user.isActive" class="btn btn-sm btn-warning" (click)="deactivateUser(user)">
                        <i class="fas fa-ban me-1"></i>Deactivate
                      </button>
                      <button class="btn btn-sm btn-danger" (click)="deleteUser(user)">
                        <i class="fas fa-trash me-1"></i>Delete
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- User Details Modal -->
      <div *ngIf="selectedUser" class="modal fade show" tabindex="-1" style="display: block;">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">
                <i class="fas fa-user me-2"></i>
                User Details
              </h5>
              <button type="button" class="btn-close" (click)="closeModal()"></button>
            </div>
            <div class="modal-body">
              <div class="row mb-3">
                <div class="col-md-6">
                  <h6>User ID</h6>
                  <p>{{ selectedUser.id }}</p>
                </div>
                <div class="col-md-6">
                  <h6>Status</h6>
                  <span class="badge" [ngClass]="{
                    'bg-success': selectedUser.isActive,
                    'bg-danger': !selectedUser.isActive
                  }">
                    {{ selectedUser.isActive ? 'ACTIVE' : 'INACTIVE' }}
                  </span>
                </div>
              </div>
              
              <div class="row mb-3">
                <div class="col-md-6">
                  <h6>Username</h6>
                  <p>{{ selectedUser.username }}</p>
                </div>
                <div class="col-md-6">
                  <h6>Email</h6>
                  <p>{{ selectedUser.email }}</p>
                </div>
              </div>
              
              <div class="row mb-3">
                <div class="col-md-6">
                  <h6>Role</h6>
                  <span class="badge" [ngClass]="{
                    'bg-primary': getUserRole(selectedUser) === 'USER',
                    'bg-info': getUserRole(selectedUser) === 'ADMIN'
                  }">
                    {{ getUserRole(selectedUser) }}
                  </span>
                </div>
                <div class="col-md-6">
                  <h6>Created Date</h6>
                  <p>{{ getFormattedDate(selectedUser) }}</p>
                </div>
              </div>
              
              <div class="row mb-3">
                <div class="col-md-6">
                  <h6>First Name</h6>
                  <p>{{ selectedUser.firstName || 'Not provided' }}</p>
                </div>
                <div class="col-md-6">
                  <h6>Last Name</h6>
                  <p>{{ selectedUser.lastName || 'Not provided' }}</p>
                </div>
              </div>
              
              <div class="row mb-3">
                <div class="col-md-6">
                  <h6>Phone Number</h6>
                  <p>{{ selectedUser.phoneNumber || 'Not provided' }}</p>
                </div>
                <div class="col-md-6">
                  <h6>Address</h6>
                  <p>{{ selectedUser.address || 'Not provided' }}</p>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" (click)="closeModal()">
                <i class="fas fa-times me-1"></i>Close
              </button>
              <button *ngIf="!selectedUser.isActive" type="button" class="btn btn-success" (click)="activateUser(selectedUser)">
                <i class="fas fa-check me-1"></i>Activate User
              </button>
              <button *ngIf="selectedUser.isActive" type="button" class="btn btn-warning" (click)="deactivateUser(selectedUser)">
                <i class="fas fa-ban me-1"></i>Deactivate User
              </button>
              <button type="button" class="btn btn-danger" (click)="deleteUser(selectedUser)">
                <i class="fas fa-trash me-1"></i>Delete User
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Modal Backdrop -->
      <div *ngIf="selectedUser" class="modal-backdrop fade show"></div>

      <!-- Confirmation Modal -->
      <div *ngIf="showConfirmationModal" class="modal fade show" tabindex="-1" style="display: block;">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">
                <i class="fas fa-exclamation-triangle me-2"></i>
                {{ confirmationTitle }}
              </h5>
              <button type="button" class="btn-close" (click)="closeConfirmationModal()"></button>
            </div>
            <div class="modal-body">
              <p>{{ confirmationMessage }}</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" (click)="closeConfirmationModal()">
                <i class="fas fa-times me-1"></i>Cancel
              </button>
              <button type="button" [class]="'btn ' + confirmationButtonClass" (click)="confirmAction()" [disabled]="isSubmitting">
                <i [class]="confirmationIconClass + ' me-1'"></i>
                <span *ngIf="!isSubmitting">{{ confirmationButtonText }}</span>
                <span *ngIf="isSubmitting">Processing...</span>
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Confirmation Modal Backdrop -->
      <div *ngIf="showConfirmationModal" class="modal-backdrop fade show"></div>
    </div>
  `,
  styles: [`
    .modal {
      background-color: rgba(0, 0, 0, 0.5);
    }
    
    .badge {
      padding: 0.5em 0.8em;
    }
    
    .btn-group .btn {
      margin-right: 0.25rem;
    }
    
    .btn-group .btn:last-child {
      margin-right: 0;
    }
  `]
})
export class ManageUsersComponent implements OnInit {
  users: any[] = [];
  filteredUsers: any[] = [];
  isLoading = false;
  errorMessage = '';
  
  // Filters
  statusFilter = 'ALL';
  roleFilter = 'ALL';
  searchQuery = '';
  
  // Modal state
  selectedUser: any = null;
  showConfirmationModal = false;
  isSubmitting = false;
  
  // Confirmation modal properties
  confirmationTitle = '';
  confirmationMessage = '';
  confirmationButtonText = '';
  confirmationButtonClass = '';
  confirmationIconClass = '';
  confirmationAction: () => void = () => {};
  userToAction: any = null;

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.loadUsers();
  }

  getUserRole(user: any): string {
    if (user.role) {
      return user.role;
    }
    if (user.roles && user.roles.length > 0) {
      return user.roles[0].replace('ROLE_', '');
    }
    // Default to USER for regular users, ADMIN if they have admin privileges
    return 'USER';
  }

  getFormattedDate(user: any): string {
    console.log('Getting formatted date for user:', user);
    console.log('Available user properties:', Object.keys(user));
    
    // Try different possible date field names from the user object
    const possibleDateFields = [
      'createdAt', 'created_at', 'createdDate', 'registrationDate', 
      'dateCreated', 'createDate', 'joinDate', 'signupDate'
    ];
    
    for (const field of possibleDateFields) {
      if (user[field]) {
        console.log(`Found date field '${field}':`, user[field]);
        try {
          const date = new Date(user[field]);
          if (!isNaN(date.getTime())) {
            return date.toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
            });
          }
        } catch (error) {
          console.log(`Error parsing date from field '${field}':`, error);
        }
      }
    }
    
    console.log('No valid date field found for user:', user.id);
    return 'N/A';
  }

  loadUsers(): void {
    this.isLoading = true;
    this.errorMessage = '';
    
    this.adminService.getAllUsers().subscribe({
      next: (users) => {
        console.log('Raw users data from backend:', users);
        // Log each user's available date fields
        users.forEach((user: any, index: number) => {
          console.log(`User ${index + 1} (${user.username}) date fields:`, {
            createdAt: user.createdAt,
            created_at: user.created_at,
            createdDate: user.createdDate,
            registrationDate: user.registrationDate,
            allFields: Object.keys(user)
          });
        });
        this.users = users;
        this.filteredUsers = [...users];
        this.isLoading = false;
      },
      error: (error: any) => {
        console.error('Error loading users:', error);
        this.errorMessage = 'Failed to load users. Please try again.';
        this.isLoading = false;
      }
    });
  }

  applyFilters(): void {
    console.log('Applying filters:', { statusFilter: this.statusFilter, roleFilter: this.roleFilter, searchQuery: this.searchQuery });
    
    this.filteredUsers = this.users.filter(user => {
      console.log('Filtering user:', user, 'Role:', this.getUserRole(user), 'Active:', user.isActive);
      
      // Status filter
      if (this.statusFilter === 'ACTIVE' && !user.isActive) {
        console.log('Filtered out by status (not active):', user.username);
        return false;
      }
      if (this.statusFilter === 'INACTIVE' && user.isActive) {
        console.log('Filtered out by status (is active):', user.username);
        return false;
      }
      
      // Role filter
      const userRole = this.getUserRole(user);
      if (this.roleFilter !== 'ALL' && userRole !== this.roleFilter) {
        console.log('Filtered out by role:', user.username, 'Expected:', this.roleFilter, 'Got:', userRole);
        return false;
      }
      
      // Search query
      if (this.searchQuery) {
        const query = this.searchQuery.toLowerCase();
        const matches = (
          user.username?.toLowerCase().includes(query) ||
          user.email?.toLowerCase().includes(query) ||
          user.firstName?.toLowerCase().includes(query) ||
          user.lastName?.toLowerCase().includes(query)
        );
        if (!matches) {
          console.log('Filtered out by search:', user.username);
          return false;
        }
      }
      
      console.log('User passed filters:', user.username);
      return true;
    });
    
    console.log('Filtered users count:', this.filteredUsers.length);
  }

  resetFilters(): void {
    this.statusFilter = 'ALL';
    this.roleFilter = 'ALL';
    this.searchQuery = '';
    this.filteredUsers = [...this.users];
  }

  viewUserDetails(user: any): void {
    this.selectedUser = user;
  }

  closeModal(): void {
    this.selectedUser = null;
  }

  activateUser(user: any): void {
    this.userToAction = user;
    this.confirmationTitle = 'Activate User';
    this.confirmationMessage = `Are you sure you want to activate user ${user.username}?`;
    this.confirmationButtonText = 'Activate';
    this.confirmationButtonClass = 'btn-success';
    this.confirmationIconClass = 'fas fa-check';
    this.confirmationAction = this.confirmActivation;
    this.showConfirmationModal = true;
    
    // Close the details modal if open
    this.selectedUser = null;
  }

  deactivateUser(user: any): void {
    this.userToAction = user;
    this.confirmationTitle = 'Deactivate User';
    this.confirmationMessage = `Are you sure you want to deactivate user ${user.username}?`;
    this.confirmationButtonText = 'Deactivate';
    this.confirmationButtonClass = 'btn-warning';
    this.confirmationIconClass = 'fas fa-ban';
    this.confirmationAction = this.confirmDeactivation;
    this.showConfirmationModal = true;
    
    // Close the details modal if open
    this.selectedUser = null;
  }

  deleteUser(user: any): void {
    this.userToAction = user;
    this.confirmationTitle = 'Delete User';
    this.confirmationMessage = `Are you sure you want to delete user ${user.username}? This action cannot be undone.`;
    this.confirmationButtonText = 'Delete';
    this.confirmationButtonClass = 'btn-danger';
    this.confirmationIconClass = 'fas fa-trash';
    this.confirmationAction = this.confirmDeletion;
    this.showConfirmationModal = true;
    
    // Close the details modal if open
    this.selectedUser = null;
  }

  closeConfirmationModal(): void {
    this.showConfirmationModal = false;
    this.userToAction = null;
  }

  confirmAction(): void {
    this.confirmationAction();
  }

  confirmActivation = (): void => {
    if (!this.userToAction) return;
    
    this.isSubmitting = true;
    
    this.adminService.activateUser(this.userToAction.id).subscribe({
      next: () => {
        // Update the user in the list
        const index = this.users.findIndex(u => u.id === this.userToAction.id);
        if (index !== -1) {
          this.users[index].isActive = true;
        }
        
        // Apply filters again
        this.applyFilters();
        
        // Close modal
        this.showConfirmationModal = false;
        this.userToAction = null;
        this.isSubmitting = false;
      },
      error: (error: any) => {
        console.error('Error activating user:', error);
        this.isSubmitting = false;
        // You might want to show an error message here
      }
    });
  }

  confirmDeactivation = (): void => {
    if (!this.userToAction) return;
    
    this.isSubmitting = true;
    
    this.adminService.deactivateUser(this.userToAction.id).subscribe({
      next: () => {
        // Update the user in the list
        const index = this.users.findIndex(u => u.id === this.userToAction.id);
        if (index !== -1) {
          this.users[index].isActive = false;
        }
        
        // Apply filters again
        this.applyFilters();
        
        // Close modal
        this.showConfirmationModal = false;
        this.userToAction = null;
        this.isSubmitting = false;
      },
      error: (error: any) => {
        console.error('Error deactivating user:', error);
        this.isSubmitting = false;
        // You might want to show an error message here
      }
    });
  }

  confirmDeletion = (): void => {
    if (!this.userToAction) return;
    
    this.isSubmitting = true;
    
    this.adminService.deleteInactiveUser(this.userToAction.id).subscribe({
      next: () => {
        // Remove the user from the list
        this.users = this.users.filter(u => u.id !== this.userToAction.id);
        
        // Apply filters again
        this.applyFilters();
        
        // Close modal
        this.showConfirmationModal = false;
        this.userToAction = null;
        this.isSubmitting = false;
      },
      error: (error: any) => {
        console.error('Error deleting user:', error);
        this.isSubmitting = false;
        // You might want to show an error message here
      }
    });
  }
}