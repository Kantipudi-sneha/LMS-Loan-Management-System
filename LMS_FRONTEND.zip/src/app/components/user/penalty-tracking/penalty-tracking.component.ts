import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { PenaltyTrackingService, Penalty, PenaltyRequest, EmiSchedule } from '../../../services/penalty.service';

@Component({
  selector: 'app-penalty-tracking',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule],
  templateUrl: './penalty-tracking.component.html',
  styleUrls: ['./penalty-tracking.component.css']
})
export class PenaltyTrackingComponent implements OnInit {

  penalties: Penalty[] = [];
  penaltyRequest: PenaltyRequest = {
    loanId: '',
    emiNumber: 0,
    reason: ''
  };
  dueDate: string = '';
  penaltyAmountDisplay: string = '';
  isOverdue = false;
  message = '';
  isError = false;
  searchCriteria: any;
  filteredPenalties: any;

  constructor(private penaltyService: PenaltyTrackingService) {}

  ngOnInit(): void {
    this.searchCriteria = { loanId: '', emiNumber: null };
    this.filteredPenalties = [];
    this.loadPenalties();
  }

  loadPenalties(): void {
    this.penaltyService.getAllPenalties().subscribe({
      next: (data: Penalty[]) => {
        this.penalties = data;
        this.filteredPenalties = [...this.penalties];
        console.log('Loaded penalties from backend:', this.penalties);
      },
      error: (error) => {
        console.error('Error loading penalties:', error);
        this.message = 'Error loading penalties: ' + (error.error?.message || 'Backend API not responding');
        this.isError = true;
        this.penalties = [];
        this.filteredPenalties = [];
      }
    });
  }

  onLoanOrEmiChange(): void {
    const { loanId, emiNumber } = this.penaltyRequest;
    if (loanId && emiNumber > 0) {
      this.penaltyService.getEmiSchedule(loanId, emiNumber).subscribe({
        next: (emiSchedules: EmiSchedule[]) => {
          if (emiSchedules && emiSchedules.length > 0) {
            const emiSchedule = emiSchedules[0];
            this.dueDate = emiSchedule.dueDate;
            this.isOverdue = this.checkOverdue(this.dueDate);
            this.message = '';
            this.isError = false;
            
            // Calculate penalty amount if overdue
            if (this.isOverdue) {
              const today = new Date();
              const dueDate = new Date(this.dueDate);
              const daysOverdue = Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));
              const penaltyAmount = daysOverdue * 50; // ₹50 per day
              this.penaltyAmountDisplay = penaltyAmount.toString();
            } else {
              this.penaltyAmountDisplay = '0';
            }
          } else {
            this.dueDate = '';
            this.isOverdue = false;
            this.message = 'EMI schedule not found for this loan and EMI number.';
            this.isError = true;
            this.penaltyAmountDisplay = '';
          }
        },
        error: (error) => {
          console.error('Error fetching EMI schedule:', error);
          this.dueDate = '';
          this.isOverdue = false;
          this.message = 'Error fetching EMI schedule: ' + (error.error?.message || 'Backend API not responding');
          this.isError = true;
          this.penaltyAmountDisplay = '';
        }
      });
    } else {
      this.dueDate = '';
      this.isOverdue = false;
      this.penaltyAmountDisplay = '';
      this.message = '';
      this.isError = false;
    }
  }

  checkOverdue(dueDateStr: string): boolean {
    const today = new Date();
    const dueDate = new Date(dueDateStr);
    return dueDate < today;
  }

  addPenalty(): void {
    if (!this.penaltyRequest.loanId || this.penaltyRequest.emiNumber <= 0) {
      this.message = 'Please enter valid Loan ID and EMI Number.';
      this.isError = true;
      return;
    }
    if (!this.penaltyRequest.reason.trim()) {
      this.message = 'Reason is required for penalties.';
      this.isError = true;
      return;
    }

    this.penaltyService.calculateAndAddPenalty(this.penaltyRequest).subscribe({
      next: (newPenalty: Penalty) => {
        this.penalties.push(newPenalty);
        this.filteredPenalties = [...this.penalties];
        
        this.message = `Penalty added successfully! Amount: ₹${newPenalty.penaltyAmount}`;
        this.penaltyAmountDisplay = newPenalty.penaltyAmount.toString();
        this.isError = false;
        
        // Reset form
        this.penaltyRequest.reason = '';
        this.penaltyRequest.loanId = '';
        this.penaltyRequest.emiNumber = 0;
        this.dueDate = '';
        this.isOverdue = false;
        
        console.log('Added penalty:', newPenalty);
      },
      error: (error) => {
        console.error('Error adding penalty:', error);
        this.message = 'Error adding penalty: ' + (error.error?.message || 'Backend API not responding');
        this.isError = true;
      }
    });
  }

  getPenaltyAndEmiDetails(loanId: string, emiNumber: number) {
    this.penaltyService.getEmiSchedule(loanId, emiNumber).subscribe({
      next: (emiList: EmiSchedule[]) => {
        if (emiList && emiList.length > 0) {
          this.dueDate = emiList[0].dueDate;
          this.isOverdue = this.checkOverdue(this.dueDate);
        } else {
          this.dueDate = '';
          this.isOverdue = false;
        }

        this.penaltyService.getPenaltiesByLoanAndEmiNumber(loanId, emiNumber).subscribe({
          next: (penalties: Penalty[]) => {
            this.penalties = penalties;
          },
          error: (err) => {
            console.error('Error fetching penalties', err);
          }
        });
      },
      error: (err) => {
        console.error('Error fetching EMI schedule', err);
        this.dueDate = '';
        this.isOverdue = false;
      }
    });
  }

  resetForm() {
    this.penaltyRequest = {
      loanId: "",
      emiNumber: 0,
      reason: "",
    }
    this.dueDate = ""
    this.penaltyAmountDisplay = ""
    this.message = ""
    this.isError = false
  }

  searchPenalties() {
    if (!this.penalties) return;
    this.filteredPenalties = this.penalties.filter((penalty) => {
      const loanIdMatch =
        !this.searchCriteria.loanId ||
        (penalty.loanId && penalty.loanId.toLowerCase().includes(this.searchCriteria.loanId.toLowerCase()));
      const emiNumberMatch =
        !this.searchCriteria.emiNumber || penalty.emiNumber === this.searchCriteria.emiNumber;
      return loanIdMatch && emiNumberMatch;
    });
  }

  resetSearch() {
    this.searchCriteria = {
      loanId: "",
      emiNumber: null,
    }
    this.filteredPenalties = this.penalties
  }
}
