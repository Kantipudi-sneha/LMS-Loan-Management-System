import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { EmiScheduleService } from '../../../services/emi-schedule.service';
import { LoanService } from '../../../services/loan.service';
import { PaymentService } from '../../../services/payment.service';
import { Loan } from '../../../models/loan.model';

@Component({
  selector: 'app-emi-tracking',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule],
  templateUrl: './emi-tracking.component.html',
  styleUrls: ['./emi-tracking.component.css']
})
export class EmiTrackingComponent implements OnInit {
  searchLoanId: string = ''; // for search field only
  userLoans: Loan[] = [];
  selectedLoan: Loan | null = null;

  loanId = '';
  principalAmount!: number;
  interestRate!: number;
  tenure!: number;
  startDate!: string;
  emiList: any[] = [];
  loading = false;
  errorMessage = '';
  successMessage = '';
  currentLoanId: any;

  // Track paid EMIs locally
  paidEmis: Set<string> = new Set();

  constructor(
    private emiService: EmiScheduleService,
    private loanService: LoanService,
    private paymentService: PaymentService
  ) { }

  ngOnInit(): void {
    // Listen for payment updates
    this.emiService.emiUpdated$.subscribe(() => {
      if (this.currentLoanId) {
        console.log('EMI update notification received, reloading data for loan:', this.currentLoanId);
        this.loadEmiData(this.currentLoanId);
        this.loadPaidEmis(this.currentLoanId);
      }
    });
  }

  // Load paid EMIs from payment records
  loadPaidEmis(loanId: string): void {
    this.paymentService.getPaymentsByLoanId(loanId).subscribe({
      next: (payments) => {
        this.paidEmis.clear();
        payments.forEach(payment => {
          const key = `${payment.loanId}-${payment.emiNumber}`;
          this.paidEmis.add(key);
        });
        console.log('Loaded paid EMIs:', Array.from(this.paidEmis));
      },
      error: (error) => {
        console.error('Error loading paid EMIs:', error);
      }
    });
  }

  onLoanIdChange(): void {
    if (!this.loanId || this.loanId.trim() === '') {
      return;
    }

    console.log('Auto-fill triggered for loan ID:', this.loanId);
    this.loading = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.loanService.getCurrentUserLoans().subscribe({
      next: (loans: any[]) => {
        console.log('Current user loans:', loans);

        const loan = loans.find(l => {
          const loanIdStr = this.loanId.toString();
          console.log('Checking loan:', l, 'against ID:', loanIdStr);
          return l.id?.toString() === loanIdStr ||
            l.loanId?.toString() === loanIdStr ||
            l.applicationId?.toString() === loanIdStr;
        });

        if (loan) {
          console.log('Found loan for auto-fill:', loan);

          this.principalAmount = loan.loanAmount || loan.amount || 0;
          this.interestRate = loan.interestRate || 12;
          this.tenure = loan.loanTenure || loan.term || loan.tenure || 24;
          this.startDate = loan.disbursementDate?.split('T')[0] || loan.applicationDate?.split('T')[0] || '2025-08-19';

          this.successMessage = 'Loan details auto-filled!';
          setTimeout(() => this.successMessage = '', 2000);
        } else {
          console.log('Available loan IDs:', loans.map(l => l.id || l.loanId));
          this.errorMessage = `Loan ${this.loanId} not found. Try: ${loans.map(l => l.id || l.loanId).filter(id => id).slice(0, 3).join(', ')}`;
        }
        this.loading = false;
      },
      error: (error) => {
        console.error('Auto-fill error:', error);
        this.loadAndFilterAllLoans();
      }
    });
  }

  // Fallback method to filter all loans for current user
  loadAndFilterAllLoans(): void {
    this.loanService.getAllLoans().subscribe({
      next: (loans: any[]) => {
        console.log('All available loans:', loans);

        // Filter loans for current user only
        const userLoans = loans.filter(loan => this.isCurrentUserLoan(loan));

        const loan = userLoans.find(l => {
          const loanIdStr = this.loanId.toString();
          console.log('Checking loan:', l, 'against ID:', loanIdStr);
          return l.id?.toString() === loanIdStr ||
            l.loanId?.toString() === loanIdStr ||
            l.applicationId?.toString() === loanIdStr;
        });

        if (loan) {
          console.log('Found loan for auto-fill:', loan);

          this.principalAmount = loan.loanAmount || loan.amount || 0;
          this.interestRate = loan.interestRate || 12;
          this.tenure = loan.loanTenure || loan.term || loan.tenure || 24;
          this.startDate = loan.disbursementDate?.split('T')[0] || loan.applicationDate?.split('T')[0] || '2025-08-19';

          this.successMessage = 'Loan details auto-filled!';
          setTimeout(() => this.successMessage = '', 2000);
        } else {
          console.log('Available user loan IDs:', userLoans.map(l => l.id || l.loanId));
          this.errorMessage = `Loan ${this.loanId} not found. Try: ${userLoans.map(l => l.id || l.loanId).filter(id => id).slice(0, 3).join(', ')}`;
        }
        this.loading = false;
      },
      error: (error) => {
        console.error('Auto-fill error:', error);
        this.loading = false;
      }
    });
  }

  // Helper method to check if loan belongs to current user
  private isCurrentUserLoan(loan: any): boolean {
    // Add logic to match loan to current user
    // This could be based on userId, applicantId, email, or other user identifier
    return true; // Implement proper user matching logic
  }

  resetForm(event?: Event) {
    if (event) event.preventDefault();

    this.loanId = '';
    this.principalAmount = 0;
    this.interestRate = 0;
    this.tenure = 0;
    this.startDate = '';

    this.errorMessage = '';
    this.emiList = [];
    this.loading = false;
  }

  loadEmiData(currentLoanId: string) {
    this.loading = true;
    this.errorMessage = '';

    this.emiService.getScheduleByLoanId(currentLoanId).subscribe({
      next: (data: any) => {
        this.loading = false;
        if (data && data.length > 0) {
          this.emiList = data;
        } else {
          // If no EMI schedule exists, try to generate one automatically
          this.generateEmiScheduleForLoan(currentLoanId);
        }
      },
      error: (err: any) => {
        this.loading = false;
        console.error('Error fetching EMI data:', err);
        this.errorMessage = 'Error fetching EMI data: ' + (err.error?.message || 'Backend API not responding');
      }
    });
  }

  generateEmiScheduleForLoan(loanId: string) {
    this.loading = true;
    const request = {
      loanId: loanId,
      principalAmount: this.principalAmount,
      interestRate: this.interestRate,
      tenure: this.tenure,
      startDate: this.startDate
    };

    console.log('🚀 FRONTEND: Sending EMI generation request:', request);

    this.emiService.generateSchedule(request).subscribe({
      next: (data: any) => {
        console.log('✅ FRONTEND: Received EMI generation response:', data);
        this.loading = false;
        if (data && data.length > 0) {
          this.emiList = data;
          console.log('✅ Generated EMI schedule for loan:', loanId);
        } else {
          this.errorMessage = 'Failed to generate EMI schedule.';
        }
      },
      error: (err: any) => {
        console.error('❌ FRONTEND: Error generating EMI schedule:', err);
        this.loading = false;
        this.errorMessage = 'Error generating EMI schedule: ' + (err.error?.message || 'Backend API not responding');
      }
    });
  }

  /** SEARCH EMI SCHEDULE BY LOAN ID **/
  onSearch() {
    if (!this.searchLoanId.trim()) {
      this.errorMessage = 'Please enter a Loan ID.';
      return;
    }

    this.errorMessage = '';
    this.loading = true;
    this.emiList = [];
    this.currentLoanId = this.searchLoanId;

    console.log('Searching for EMI schedule for loan ID:', this.searchLoanId);

    // Load both EMI schedule and payment records
    this.emiService.getScheduleByLoanId(this.searchLoanId).subscribe({
      next: (data: any) => {
        console.log('EMI schedule response:', data);
        this.loading = false;
        if (data && data.length > 0) {
          this.emiList = data;
          console.log('Found', data.length, 'EMI schedules');
          // Load paid EMIs after getting schedule
          this.loadPaidEmis(this.searchLoanId);
        } else {
          console.log('No EMI schedules found for loan:', this.searchLoanId);
          this.tryGenerateScheduleForSearchedLoan();
        }
      },
      error: (err: any) => {
        this.loading = false;
        console.error('Search EMI error:', err);
        this.errorMessage = 'Error fetching EMI data: ' + (err.error?.message || 'Backend API not responding');
      }
    });
  }

  tryGenerateScheduleForSearchedLoan() {
    this.errorMessage = 'No EMI schedule found for this loan. Please use the Generate EMI Schedule form below to create one.';
  }

  /** EXISTING METHOD FOR GENERATING SCHEDULE **/
  onGenerate() {
    if (!this.loanId || !this.principalAmount || !this.interestRate || !this.tenure || !this.startDate) {
      this.errorMessage = 'Please fill all fields.';
      return;
    }

    this.errorMessage = '';
    this.loading = true;

    const request = {
      loanId: this.loanId,
      principalAmount: this.principalAmount,
      interestRate: this.interestRate,
      tenure: this.tenure,
      startDate: this.startDate
    };

    console.log('🚀 FRONTEND: Sending EMI generation request:', request);

    this.emiService.generateSchedule(request).subscribe({
      next: (data: any) => {
        console.log('✅ FRONTEND: Received EMI generation response:', data);
        this.loading = false;
        if (data && data.length > 0) {
          this.emiList = data;
          this.currentLoanId = this.loanId;
          console.log('✅ Generated EMI schedule for loan:', this.loanId, 'with', data.length, 'EMIs');
          this.errorMessage = '';
        } else {
          this.errorMessage = 'Failed to generate EMI schedule.';
        }
      },
      error: (err: any) => {
        console.error('❌ FRONTEND: Error generating EMI schedule:', err);
        this.loading = false;
        this.errorMessage = 'Error generating EMI schedule: ' + (err.error?.message || 'Backend API not responding');
      }
    });
  }

  generateLocalEmiSchedule() {
    try {
      const principal = this.principalAmount;
      const monthlyRate = this.interestRate / 100 / 12;
      const numPayments = this.tenure;

      // Calculate EMI using standard formula
      const emi = (principal * monthlyRate * Math.pow(1 + monthlyRate, numPayments)) /
        (Math.pow(1 + monthlyRate, numPayments) - 1);

      const schedule: any[] = [];
      let remainingBalance = principal;
      const startDate = new Date(this.startDate);

      for (let i = 1; i <= numPayments; i++) {
        const interestAmount = remainingBalance * monthlyRate;
        const principalAmount = emi - interestAmount;
        remainingBalance = Math.max(0, remainingBalance - principalAmount);

        // Calculate due date for each EMI
        const dueDate = new Date(startDate.getFullYear(), startDate.getMonth() + i, startDate.getDate());

        schedule.push({
          id: i,
          loanId: this.loanId,
          emiNumber: i,
          dueDate: dueDate.toISOString().split('T')[0],
          emiAmount: Math.round(emi * 100) / 100,
          amount: Math.round(emi * 100) / 100,
          principalAmount: Math.round(principalAmount * 100) / 100,
          interestAmount: Math.round(interestAmount * 100) / 100,
          remainingBalance: Math.round(remainingBalance * 100) / 100,
          status: 'PENDING'
        });
      }

      this.emiList = schedule;
      this.loading = false;
      this.currentLoanId = this.loanId;

      console.log('Generated', schedule.length, 'EMIs from', schedule[0]?.dueDate, 'to', schedule[schedule.length - 1]?.dueDate);

    } catch (error) {
      console.error('Error generating EMI schedule:', error);
      this.errorMessage = 'Error calculating EMI schedule.';
      this.loading = false;
    }
  }

  /** FRONTEND STATUS CALCULATION **/
  getDisplayStatus(emi: any): string {
    // Check if this EMI has been paid based on payment records
    const emiKey = `${emi.loanId}-${emi.emiNumber}`;
    if (this.paidEmis.has(emiKey)) {
      return 'Paid';
    }

    // First check if backend has set a specific status
    if (emi.status && emi.status.toLowerCase() === 'paid') {
      return 'Paid';
    }

    // For other backend statuses, respect them
    if (emi.status && emi.status.toLowerCase() !== 'pending') {
      return emi.status.charAt(0).toUpperCase() + emi.status.slice(1).toLowerCase();
    }

    // Only use date-based calculation for PENDING status or no status
    const today = new Date();
    const dueDate = new Date(emi.dueDate);
    const calculatedStatus = today > dueDate ? 'Overdue' : 'Upcoming';

    return calculatedStatus;
  }

  // Filter EMIs to show only unpaid ones
  getFilteredEmiList(): any[] {
    return this.emiList.filter(emi => {
      const emiKey = `${emi.loanId}-${emi.emiNumber}`;
      return !this.paidEmis.has(emiKey);
    });
  }

  // Get count of paid EMIs
  getPaidCount(): number {
    return this.paidEmis.size;
  }

  getPaidPercentage(): number {
    return this.emiList.length > 0
      ? (this.getPaidCount() / this.emiList.length) * 100
      : 0;
  }

  getProgressColorClass(): string {
    const paid = this.getPaidCount();
    const total = this.emiList.length;

    if (paid === 0) return 'progress-red';
    if (paid < total) return 'progress-yellow';
    return 'progress-green';
  }
}
