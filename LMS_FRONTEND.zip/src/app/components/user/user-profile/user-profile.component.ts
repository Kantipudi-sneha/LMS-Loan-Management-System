import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { UserProfileDTO } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';


@Component({
  selector: 'app-user-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  profileForm!: FormGroup;
  changePasswordForm!: FormGroup;
  isLoading = false;
  isUpdating = false;
  isChangingPassword = false;
  alertMessage = '';
  alertType = 'info';
  currentUser: any; // Adjust type to match your AuthService
  userProfile: UserProfileDTO | null = null;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUser();
    this.initForms();
    this.loadUserProfile();
  }

  initForms(): void {
    // Profile Update Form
    this.profileForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      mobileNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      dateOfBirth: ['', Validators.required],
      aadharNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{12}$/)]],
      panNumber: ['', [Validators.required, Validators.pattern(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/)]],
      address: ['', [Validators.required, Validators.minLength(10)]],
      occupation: ['', Validators.required],
      employerName: ['', Validators.required],
      monthlyIncome: ['', [Validators.required, Validators.min(10000)]],
      bankName: ['', Validators.required],
      accountNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{9,18}$/)]],
      ifscCode: ['', [Validators.required, Validators.pattern(/^[A-Z]{4}0[A-Z0-9]{6}$/)]]
    });

    // Change Password Form
    this.changePasswordForm = this.fb.group({
      currentPassword: ['', Validators.required],
      newPassword: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', Validators.required]
    }, { validators: this.passwordMatchValidator });
  }

  passwordMatchValidator(form: FormGroup) {
    const newPassword = form.get('newPassword')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;
    return newPassword === confirmPassword ? null : { passwordMismatch: true };
  }

  loadUserProfile(): void {
    this.isLoading = true;
    this.alertMessage = '';
    
    this.authService.getUserProfile().subscribe({
      next: (profile) => {
        this.userProfile = profile;
        this.populateForm(profile);
        this.isLoading = false;
      },
      error: (error) => {
        this.alertMessage = 'Failed to load user profile. Please try again.';
        this.alertType = 'danger';
        this.isLoading = false;
      }
    });
  }

  populateForm(profile: UserProfileDTO): void {
    this.profileForm.patchValue({
      username: profile.username,
      email: profile.email,
      mobileNumber: profile.mobileNumber,
      dateOfBirth: profile.dateOfBirth,
      aadharNumber: profile.aadharNumber,
      panNumber: profile.panNumber,
      address: profile.address,
      occupation: profile.occupation,
      employerName: profile.employerName,
      monthlyIncome: profile.monthlyIncome,
      bankName: profile.bankName,
      accountNumber: profile.accountNumber,
      ifscCode: profile.ifscCode
    });
  }

  onProfileUpdate(): void {
    if (this.profileForm.valid) {
      this.isUpdating = true;
      this.alertMessage = '';
      
      const profileData = this.profileForm.value;
      
      this.authService.updateUserProfile(profileData).subscribe({
        next: (response) => {
          this.alertMessage = 'Profile updated successfully!';
          this.alertType = 'success';
          this.userProfile = { ...this.userProfile, ...profileData };
          setTimeout(() => {
            this.alertMessage = '';
          }, 3000);
        },
        error: (error) => {
          this.alertMessage = error.error?.message || 'Failed to update profile. Please try again.';
          this.alertType = 'danger';
        },
        complete: () => {
          this.isUpdating = false;
        }
      });
    } else {
      this.markFormGroupTouched(this.profileForm);
    }
  }

  onChangePassword(): void {
    if (this.changePasswordForm.valid) {
      this.isChangingPassword = true;
      this.alertMessage = '';
      
      const passwordData = this.changePasswordForm.value;
      
      this.authService.changePassword(passwordData).subscribe({
        next: (response) => {
          this.alertMessage = 'Password changed successfully!';
          this.alertType = 'success';
          this.changePasswordForm.reset();
          setTimeout(() => {
            this.alertMessage = '';
          }, 3000);
        },
        error: (error) => {
          this.alertMessage = error.error?.message || 'Failed to change password. Please try again.';
          this.alertType = 'danger';
        },
        complete: () => {
          this.isChangingPassword = false;
        }
      });
    } else {
      this.markFormGroupTouched(this.changePasswordForm);
    }
  }

  onDeleteAccount(): void {
    const password = prompt('Please enter your password to confirm account deletion:');
    if (password) {
      if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
        this.authService.deleteAccount(password).subscribe({
          next: (response) => {
            this.alertMessage = 'Account deleted successfully. Redirecting to home page...';
            this.alertType = 'success';
            setTimeout(() => {
              this.authService.logout();
              this.router.navigate(['/home']);
            }, 2000);
          },
          error: (error) => {
            this.alertMessage = error.error?.message || 'Failed to delete account. Please try again.';
            this.alertType = 'danger';
          }
        });
      }
    }
  }

  markFormGroupTouched(form: FormGroup): void {
    Object.keys(form.controls).forEach(key => {
      const control = form.get(key);
      control?.markAsTouched();
    });
  }

  isFieldInvalid(form: FormGroup, fieldName: string): boolean {
    const field = form.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  getFieldError(form: FormGroup, fieldName: string): string {
    const field = form.get(fieldName);
    if (field && field.errors) {
      if (field.errors['required']) return `${fieldName} is required`;
      if (field.errors['email']) return 'Please enter a valid email address';
      if (field.errors['minlength']) return `${fieldName} must be at least ${field.errors['minlength'].requiredLength} characters`;
      if (field.errors['min']) return `${fieldName} must be at least ${field.errors['min'].min}`;
      if (field.errors['pattern']) {
        if (fieldName === 'mobileNumber') return 'Please enter a valid 10-digit mobile number';
        if (fieldName === 'aadharNumber') return 'Please enter a valid 12-digit Aadhar number';
        if (fieldName === 'panNumber') return 'Please enter a valid PAN number';
        if (fieldName === 'accountNumber') return 'Please enter a valid account number';
        if (fieldName === 'ifscCode') return 'Please enter a valid IFSC code';
        return `${fieldName} format is invalid`;
      }
    }
    return '';
  }

  getPasswordError(): string {
    const form = this.changePasswordForm;
    if (form.errors?.['passwordMismatch']) {
      return 'New password and confirm password do not match';
    }
    return '';
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0
    }).format(amount);
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  }

  getAlertIcon(): string {
    switch (this.alertType) {
      case 'success':
        return 'fas fa-check-circle';
      case 'danger':
        return 'fas fa-exclamation-circle';
      case 'warning':
        return 'fas fa-exclamation-triangle';
      default:
        return 'fas fa-info-circle';
    }
  }
}
