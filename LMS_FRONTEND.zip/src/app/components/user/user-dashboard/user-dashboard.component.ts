import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { LoanService } from '../../../services/loan.service';
import { PaymentService } from '../../../services/payment.service';

@Component({
  selector: 'app-user-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="container">
      <div class="row">
        <div class="col-12">
          <h2 class="mb-4">
            <i class="fas fa-tachometer-alt me-2"></i>Welcome, {{ currentUser?.username }}!
          </h2>
        </div>
      </div>


      <div class="row mb-4">
        <div class="col-md-3 mb-3">
          <div class="card text-center">
            <div class="card-body">
              <i class="fas fa-file-invoice-dollar fa-2x text-primary mb-2"></i>
              <h5 class="card-title">{{ stats.totalLoans }}</h5>
              <p class="card-text">Total Loans</p>
            </div>
          </div>
        </div>
        <div class="col-md-3 mb-3">
          <div class="card text-center">
            <div class="card-body">
              <i class="fas fa-clock fa-2x text-warning mb-2"></i>
              <h5 class="card-title">{{ stats.pendingLoans }}</h5>
              <p class="card-text">Pending Applications</p>
            </div>
          </div>
        </div>
        <div class="col-md-3 mb-3">
          <div class="card text-center">
            <div class="card-body">
              <i class="fas fa-check-circle fa-2x text-success mb-2"></i>
              <h5 class="card-title">{{ stats.approvedLoans }}</h5>
              <p class="card-text">Approved Loans</p>
            </div>
          </div>
        </div>
        <div class="col-md-3 mb-3">
          <div class="card text-center">
            <div class="card-body">
              <i class="fas fa-credit-card fa-2x text-info mb-2"></i>
              <h5 class="card-title">{{ stats.totalPayments }}</h5>
              <p class="card-text">Total Payments</p>
            </div>
          </div>
        </div>
      </div>

      <div class="row mb-4">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h5 class="mb-0">
                <i class="fas fa-bolt me-2"></i>Quick Actions
              </h5>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-4 mb-3">
                  <a routerLink="/user/apply-loan" class="btn btn-primary btn-lg w-100">
                    <i class="fas fa-plus-circle me-2"></i>Apply for Loan
                  </a>
                </div>
                <div class="col-md-4 mb-3">
                  <a routerLink="/user/loans" class="btn btn-outline-primary btn-lg w-100">
                    <i class="fas fa-list me-2"></i>View My Loans
                  </a>
                </div>
                <div class="col-md-4 mb-3">
                  <a routerLink="/user/payments" class="btn btn-outline-success btn-lg w-100">
                    <i class="fas fa-credit-card me-2"></i>Make Payment
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    
      <div class="row mb-4">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h5 class="mb-0">
                <i class="fas fa-history me-2"></i>Recent Loan Applications
              </h5>
            </div>
            <div class="card-body">
              <div *ngIf="recentLoans.length === 0" class="text-center py-4">
                <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                <p class="text-muted">No loan applications yet.</p>
                <a routerLink="/user/apply-loan" class="btn btn-primary">
                  <i class="fas fa-plus-circle me-2"></i>Apply for Your First Loan
                </a>
              </div>
              
              <div *ngIf="recentLoans.length > 0" class="table-responsive">
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <th>Loan Type</th>
                      <th>Amount</th>
                      <th>Status</th>
                      <th>Applied Date</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr *ngFor="let loan of recentLoans">
                      <td>{{ loan.loanType }}</td>
                      <td>₹{{ loan.amount | number:'1.0-0' }}</td>
                      <td>
                        <span class="badge" [class]="getStatusBadgeClass(loan.status)">
                          {{ loan.status }}
                        </span>
                      </td>
                      <td>{{ loan.appliedDate | date:'shortDate' }}</td>
                      <td>
                        <a routerLink="/user/loans" class="btn btn-sm btn-outline-primary">
                          <i class="fas fa-eye me-1"></i>View
                        </a>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>

     
      <div class="row mb-4">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h5 class="mb-0">
                <i class="fas fa-credit-card me-2"></i>Recent Payments
              </h5>
            </div>
            <div class="card-body">
              <div *ngIf="recentPayments.length === 0" class="text-center py-4">
                <i class="fas fa-credit-card fa-3x text-muted mb-3"></i>
                <p class="text-muted">No payments made yet.</p>
              </div>
              
              <div *ngIf="recentPayments.length > 0" class="table-responsive">
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <th>Loan ID</th>
                      <th>EMI Number</th>
                      <th>Amount</th>
                      <th>Status</th>
                      <th>Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr *ngFor="let payment of recentPayments">
                      <td>{{ payment.loanId }}</td>
                      <td>{{ payment.emiNumber }}</td>
                      <td>₹{{ payment.paymentAmount | number:'1.0-0' }}</td>
                      <td>
                        <span class="badge" [class]="getPaymentStatusBadgeClass(payment.paymentStatus)">
                          {{ payment.paymentStatus }}
                        </span>
                      </td>
                      <td>{{ payment.paymentDate | date:'shortDate' }}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .card {
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .card:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    }
    
    .text-primary {
      color: #667eea !important;
    }
    
    .text-success {
      color: #56ab2f !important;
    }
    
    .text-warning {
      color: #ffc107 !important;
    }
    
    .text-info {
      color: #17a2b8 !important;
    }
    
    .badge {
      padding: 8px 12px;
      border-radius: 20px;
      font-size: 0.8rem;
    }
    
    .badge-pending {
      background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%);
      color: white;
    }
    
    .badge-approved {
      background: linear-gradient(135deg, #56ab2f 0%, #a8e6cf 100%);
      color: white;
    }
    
    .badge-rejected {
      background: linear-gradient(135deg, #ff416c 0%, #ff4b2b 100%);
      color: white;
    }
    
    .badge-completed {
      background: linear-gradient(135deg, #17a2b8 0%, #6f42c1 100%);
      color: white;
    }
    
    .btn {
      border-radius: 10px;
      font-weight: 600;
    }
    
    .btn-lg {
      padding: 15px 25px;
    }
  `]
})
export class UserDashboardComponent implements OnInit {
  currentUser: any;
  stats = {
    totalLoans: 0,
    pendingLoans: 0,
    approvedLoans: 0,
    totalPayments: 0
  };
  recentLoans: any[] = [];
  recentPayments: any[] = [];

  constructor(
    private authService: AuthService,
    private loanService: LoanService,
    private paymentService: PaymentService
  ) { }

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUser();
    this.loadDashboardData();
  }

  loadDashboardData(): void {
    // First try to get current user's loans specifically
    this.loanService.getCurrentUserLoans().subscribe({
      next: (loans) => {
        console.log('Current user loans from API:', loans);
        console.log('Current user:', this.currentUser);
        this.processUserLoans(loans);
      },
      error: (error) => {
        console.error('Error loading current user loans:', error);
        // Fallback to getAllLoanApplications with filtering
        this.loadAndFilterAllLoans();
      }
    });

    this.paymentService.getCurrentUserPayments().subscribe({
      next: (payments) => {
        this.recentPayments = payments.slice(0, 5);
        this.stats.totalPayments = payments.length;
      },
      error: (error) => {
        console.error('Error loading user payments:', error);
        // Fallback to filtered getAllPayments if getCurrentUserPayments fails
        this.loadAndFilterAllPayments();
      }
    });
  }

  // Process user-specific loans
  processUserLoans(loans: any[]): void {
    console.log('Processing user-specific loans:', loans);

    this.recentLoans = loans.slice(0, 5).map((l: any) => ({
      loanType: l.type || l.loanType || l.loan_type || 'Personal Loan',
      amount: l.loanAmount || l.loan_amount,
      status: l.status,
      appliedDate: l.applicationDate || l.application_date
    }));

    this.stats.totalLoans = loans.length;
    this.stats.pendingLoans = loans.filter((l: any) => l.status === 'PENDING').length;
    this.stats.approvedLoans = loans.filter((l: any) => l.status === 'APPROVED').length;
  }

  // Fallback method to filter all loans for current user
  loadAndFilterAllLoans(): void {
    console.log('Fallback: Loading all loans and filtering for current user');

    this.loanService.getAllLoanApplications().subscribe({
      next: (loans) => {
        console.log('All loans from API:', loans);
        console.log('Current user:', this.currentUser);

        // Filter loans for current user only
        const userLoans = loans.filter((loan: any) => this.isCurrentUserLoan(loan));
        console.log('Filtered user loans:', userLoans);

        this.processUserLoans(userLoans);
      },
      error: (error) => {
        console.error('Error loading all loans:', error);
      }
    });
  }

  // Helper method to check if loan belongs to current user
  private isCurrentUserLoan(loan: any): boolean {
    if (!this.currentUser) {
      console.log('No current user found');
      return false;
    }

    // Strict matching - only show loans that clearly belong to current user
    const currentUsername = this.currentUser.username || this.currentUser.sub;

    const isMatch = (
      // Check userId fields
      (loan.userId && (loan.userId === this.currentUser.sub || loan.userId === this.currentUser.id)) ||
      // Check applicantId fields  
      (loan.applicantId && (loan.applicantId === this.currentUser.sub || loan.applicantId === this.currentUser.id)) ||
      // Check applicant name - must match exactly (case-insensitive)
      (loan.applicantName && currentUsername &&
        loan.applicantName.toLowerCase().trim() === currentUsername.toLowerCase().trim()) ||
      // Check username fields
      (loan.username && currentUsername &&
        loan.username.toLowerCase().trim() === currentUsername.toLowerCase().trim()) ||
      // Check email fields
      (loan.email && this.currentUser.email &&
        loan.email.toLowerCase().trim() === this.currentUser.email.toLowerCase().trim())
    );

    console.log(`Dashboard loan ${loan.id} match check:`, {
      loanUserId: loan.userId,
      loanApplicantId: loan.applicantId,
      loanApplicantName: loan.applicantName,
      loanUsername: loan.username,
      loanEmail: loan.email,
      currentUserSub: this.currentUser.sub,
      currentUserId: this.currentUser.id,
      currentUserUsername: currentUsername,
      currentUserEmail: this.currentUser.email,
      isMatch: isMatch
    });

    return isMatch;
  }

  private determineLoanType(amount: number, tenure: number): string {

    if (!amount) return 'Personal Loan';

    if (amount >= 1000000) {
      return 'Home Loan';
    } else if (amount >= 500000) {
      return 'Business Loan';
    } else if (amount >= 200000) {
      return 'Car Loan';
    } else {
      return 'Personal Loan';
    }
  }

  getStatusBadgeClass(status: string): string {
    switch (status?.toUpperCase()) {
      case 'PENDING':
        return 'badge-pending';
      case 'APPROVED':
        return 'badge-approved';
      case 'REJECTED':
        return 'badge-rejected';
      case 'COMPLETED':
        return 'badge-completed';
      default:
        return 'badge-secondary';
    }
  }

  getPaymentStatusBadgeClass(status: string): string {
    switch (status?.toUpperCase()) {
      case 'COMPLETED':
        return 'badge-completed';
      case 'PENDING':
        return 'badge-pending';
      case 'FAILED':
        return 'badge-rejected';
      default:
        return 'badge-secondary';
    }
  }

  loadAndFilterAllPayments(): void {
    this.paymentService.getAllPayments().subscribe({
      next: (payments) => {
        const currentUser = this.authService.getCurrentUser();
        if (currentUser) {
          // Filter payments for current user only
          const userPayments = payments.filter((payment: any) =>
            payment.userId === currentUser.sub ||
            payment.userId === currentUser.id ||
            payment.applicantId === currentUser.sub ||
            payment.applicantId === currentUser.id ||
            payment.username === currentUser.username ||
            payment.email === currentUser.email
          );
          this.recentPayments = userPayments.slice(0, 5);
          this.stats.totalPayments = userPayments.length;
        }
      },
      error: (error) => {
        console.error('Error loading all payments:', error);
      }
    });
  }
}