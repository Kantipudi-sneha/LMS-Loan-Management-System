import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { PaymentService } from '../../../services/payment.service';
import { EmiScheduleService } from '../../../services/emi-schedule.service';
import { HttpClientModule } from '@angular/common/http';
import { PaymentResponseDTO, PaymentRequestDTO } from '../../../models/payment.model';

interface PaymentForm extends PaymentRequestDTO {
  paymentId?: number;
  paymentDate?: string;
  daysOverdue?: number;
  totalDue?: number;
  paymentStatus?: string;
  failureReason?: string;
}

@Component({
  selector: 'app-payment-tracking',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule],
  templateUrl: './payment-tracking.component.html',
  styleUrls: ['./payment-tracking.component.css']
})
export class PaymentTrackingComponent {
  payments: PaymentResponseDTO[] = [];

  selectedPayment: PaymentForm = {
    loanId: '',
    emiNumber: 1,
    paymentDate: new Date().toISOString().substring(0, 10),
    paymentAmount: 0,
    paymentMethod: 'cash'
  };

  message = '';
  error = '';

  // Search properties
  searchLoanId: string = '';
  searchEmiNumber?: number;

  // Available EMI numbers for dropdown
  availableEmiNumbers: number[] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

  constructor(
    private paymentService: PaymentService,
    private emiScheduleService: EmiScheduleService
  ) {
    this.loadAllPayments();
  }

  loadAllPayments(): void {
    this.paymentService.getCurrentUserPayments().subscribe({
      next: (data: PaymentResponseDTO[]) => {
        this.payments = data;
        console.log('Loaded user payments from backend:', this.payments);
      },
      error: (error) => {
        console.error('Error loading user payments:', error);
        // Fallback to filtered getAllPayments if getCurrentUserPayments fails
        this.loadAndFilterAllPayments();
      }
    });
  }

  // Fallback method to filter all payments for current user
  loadAndFilterAllPayments(): void {
    this.paymentService.getAllPayments().subscribe({
      next: (data: PaymentResponseDTO[]) => {
        // Filter payments for current user only
        this.payments = data.filter(payment =>
          payment.loanId && this.isCurrentUserPayment(payment)
        );
        console.log('Loaded and filtered user payments:', this.payments);
      },
      error: (error) => {
        console.error('Error loading all payments:', error);
        this.error = 'Error loading payments: ' + (error.error?.message || 'Backend API not responding');
        this.payments = [];
      }
    });
  }

  // Helper method to check if payment belongs to current user
  private isCurrentUserPayment(payment: any): boolean {
    // Add logic to match payment to current user
    // This could be based on userId, email, or other user identifier
    return true; // Implement proper user matching logic
  }

  onSubmit(form: NgForm) {
    if (form.invalid) return;

    if (this.selectedPayment.paymentId) {
      // Update existing payment
      this.paymentService.updatePayment(this.selectedPayment.paymentId, this.selectedPayment).subscribe({
        next: (updatedPayment) => {
          const index = this.payments.findIndex(p => p.paymentId === this.selectedPayment.paymentId);
          if (index !== -1) {
            this.payments[index] = updatedPayment;
          }
          // Update EMI status to PAID after successful payment update
          this.updateEmiStatus(this.selectedPayment.loanId, this.selectedPayment.emiNumber, 'PAID');
          this.message = 'Payment updated successfully!';
          this.error = '';
          this.resetForm(form);
        },
        error: (error) => {
          console.error('Error updating payment:', error);
          this.error = 'Error updating payment: ' + (error.error?.message || 'Backend API not responding');
          this.message = '';
        }
      });
    } else {
      // Create new payment
      const paymentRequest: PaymentRequestDTO = {
        loanId: this.selectedPayment.loanId,
        emiNumber: this.selectedPayment.emiNumber,
        paymentAmount: this.selectedPayment.paymentAmount,
        paymentMethod: this.selectedPayment.paymentMethod,
        transactionId: this.selectedPayment.transactionId || 'TXN' + Date.now(),
        paymentDate: this.selectedPayment.paymentDate || new Date().toISOString().split('T')[0]
      };

      this.paymentService.createOrUpdatePayment(paymentRequest).subscribe({
        next: (newPayment) => {
          this.payments.push(newPayment);
          // Update EMI status to PAID after successful payment creation
          this.updateEmiStatus(paymentRequest.loanId, paymentRequest.emiNumber, 'PAID');
          this.message = 'Payment added successfully!';
          this.error = '';
          this.resetForm(form);
          console.log('Payment created:', newPayment);
        },
        error: (error) => {
          console.error('Error creating payment:', error);
          this.error = 'Error creating payment: ' + (error.error?.message || 'Backend API not responding');
          this.message = '';
        }
      });
    }
  }

  updateEmiStatus(loanId: string, emiNumber: number, status: string): void {
    console.log(`Attempting to update EMI status: Loan ${loanId}, EMI ${emiNumber} to ${status}`);

    this.emiScheduleService.updateEmiStatus(loanId, emiNumber, status).subscribe({
      next: (response) => {
        console.log(`EMI ${emiNumber} for loan ${loanId} updated to ${status}:`, response);
        // Notify other components that EMI data has been updated
        this.emiScheduleService.notifyEmiUpdated();
      },
      error: (error) => {
        console.error('Error updating EMI status:', error);

        // If status update fails, try removing the paid EMI from schedule
        if (status === 'PAID') {
          console.log('Status update failed, attempting to remove paid EMI from schedule...');
          this.removePaidEmiFromSchedule(loanId, emiNumber);
        } else {
          console.warn('Payment was successful but EMI status update failed. EMI status may need manual update.');
        }
      }
    });
  }

  removePaidEmiFromSchedule(loanId: string, emiNumber: number): void {
    this.emiScheduleService.removePaidEmi(loanId, emiNumber).subscribe({
      next: (response) => {
        console.log(`Paid EMI ${emiNumber} removed from schedule for loan ${loanId}:`, response);
        // Notify other components that EMI data has been updated
        this.emiScheduleService.notifyEmiUpdated();
        this.message += ' EMI removed from schedule.';
      },
      error: (error) => {
        console.error('Error removing paid EMI from schedule:', error);
        console.warn('Could not update EMI schedule. Please refresh the EMI tracking page manually.');
      }
    });
  }

  editPayment(payment: PaymentResponseDTO): void {
    this.selectedPayment = { ...payment };
    this.message = '';
    this.error = '';
  }

  resetForm(form: NgForm): void {
    this.selectedPayment = {
      loanId: '',
      emiNumber: 1,
      paymentAmount: 100,
      transactionId: '',
      paymentMethod: 'cash',
      paymentDate: new Date().toISOString().split('T')[0]
    };
    this.message = '';
    this.error = '';
  }

  searchPaymentByLoanIdAndEmi(): void {
    if (!this.searchLoanId || !this.searchEmiNumber) {
      this.error = 'Please provide both Loan ID and EMI Number';
      return;
    }

    this.paymentService.getPaymentByLoanIdAndEmiNumber(this.searchLoanId, this.searchEmiNumber).subscribe({
      next: (payment) => {
        if (payment) {
          this.payments = [payment];
          this.error = '';
        } else {
          this.payments = [];
          this.error = 'No payments found for the given criteria';
        }
        console.log('Search result:', payment);
      },
      error: (error) => {
        console.error('Error searching payments:', error);
        this.error = 'Error searching payments: ' + (error.error?.message || 'Backend API not responding');
        this.payments = [];
      }
    });
  }

  resetSearch(): void {
    this.searchLoanId = '';
    this.searchEmiNumber = undefined;
    this.message = '';
    this.error = '';
    this.loadAllPayments();
  }
}
