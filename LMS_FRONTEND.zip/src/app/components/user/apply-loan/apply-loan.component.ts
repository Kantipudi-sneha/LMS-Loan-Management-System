import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { LoanService } from '../../../services/loan.service';
import { AuthService } from '../../../services/auth.service';
import { LoanApplication } from '../../../models/loan.model'; // Make sure this file exists and has correct interface

@Component({
  selector: 'app-apply-loan',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './apply-loan.component.html',
  styleUrls: ['./apply-loan.component.css']
})
export class ApplyLoanComponent implements OnInit {
  loanForm!: FormGroup;
  isLoading = false;
  alertMessage = '';
  alertType: 'info' | 'success' | 'danger' = 'info';
  loanTypes = [
    { value: 'PERSONAL', label: 'Personal Loan' },
    { value: 'BUSINESS', label: 'Business Loan' },
    { value: 'HOME', label: 'Home Loan' },
    { value: 'EDUCATION', label: 'Education Loan' },
    { value: 'VEHICLE', label: 'Vehicle Loan' }
  ];

  constructor(
    private fb: FormBuilder,
    private loanService: LoanService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.initForm();
  }

  private initForm(): void {
    this.loanForm = this.fb.group({
      loanType: ['', Validators.required],
      amount: ['', [Validators.required, Validators.min(10000), Validators.max(10000000)]],
      tenure: ['', [Validators.required, Validators.min(12), Validators.max(300)]],
      purpose: ['', [Validators.required, Validators.minLength(10)]],
      monthlyIncome: ['', [Validators.required, Validators.min(10000)]],
      employmentType: ['', Validators.required],
      applicantName: ['', Validators.required],
      workExperience: ['', [Validators.required, Validators.min(1)]],
      existingLoans: [false],
      existingLoanAmount: [0],
      collateral: [''],
      additionalDocuments: ['']
    });

    this.loanForm.get('existingLoans')?.valueChanges.subscribe((hasExistingLoans: boolean) => {
      if (hasExistingLoans) {
        this.loanForm.get('existingLoanAmount')?.setValidators([Validators.required, Validators.min(1000)]);
      } else {
        this.loanForm.get('existingLoanAmount')?.clearValidators();
        this.loanForm.get('existingLoanAmount')?.setValue(0);
      }
      this.loanForm.get('existingLoanAmount')?.updateValueAndValidity();
    });
  }

  onSubmit(): void {
    if (this.loanForm.valid) {
      this.isLoading = true;
      this.alertMessage = '';

      const currentUser = this.authService.getCurrentUser();
      const loanData: LoanApplication = {
        applicantName: this.loanForm.value.applicantName || currentUser?.name || '',
        email: currentUser?.email || '',
        loanAmount: this.loanForm.value.amount,
        loanTenure: this.loanForm.value.tenure,
        loanType: this.loanForm.value.loanType,
        purpose: this.loanForm.value.purpose,
        monthlyIncome: this.loanForm.value.monthlyIncome,
        employmentType: this.loanForm.value.employmentType,
        employmentStatus: this.loanForm.value.employmentType, // Using employmentType as status
        applicationDate: new Date().toISOString(),
        userId: currentUser?.id,
        status: 'PENDING'
      };

      this.loanService.applyForLoan(loanData).subscribe({
        next: (response: LoanApplication) => {
          this.alertMessage = 'Loan application submitted successfully! Your application is under review.';
          this.alertType = 'success';
          this.loanForm.reset();
          setTimeout(() => {
            this.router.navigate(['/user/loans']);
          }, 2000);
        },
        error: (error: any) => {
          this.alertMessage = error.error?.message || 'Failed to submit loan application. Please try again.';
          this.alertType = 'danger';
        },
        complete: () => {
          this.isLoading = false;
        }
      });
    } else {
      this.markFormGroupTouched();
    }
  }

  private markFormGroupTouched(): void {
    Object.keys(this.loanForm.controls).forEach(key => {
      const control = this.loanForm.get(key);
      control?.markAsTouched();
    });
  }

  isFieldInvalid(fieldName: string): boolean {
    const field = this.loanForm.get(fieldName);
    return !!(field && field.invalid && (field.dirty || field.touched));
  }

  getFieldError(fieldName: string): string {
    const field = this.loanForm.get(fieldName);
    if (field && field.errors) {
      if (field.errors['required']) return `${fieldName} is required`;
      if (field.errors['min']) return `${fieldName} must be at least ${field.errors['min'].min}`;
      if (field.errors['max']) return `${fieldName} must be at most ${field.errors['max'].max}`;
      if (field.errors['minlength']) return `${fieldName} must be at least ${field.errors['minlength'].requiredLength} characters`;
    }
    return '';
  }

  calculateEMI(): number {
    const amount = this.loanForm.get('amount')?.value || 0;
    const tenure = this.loanForm.get('tenure')?.value || 0;
    const rate = 12; 

    if (amount && tenure) {
      const monthlyRate = rate / 12 / 100;
      const emi = amount * monthlyRate * Math.pow(1 + monthlyRate, tenure) / (Math.pow(1 + monthlyRate, tenure) - 1);
      return Math.round(emi);
    }
    return 0;
  }

  getTotalAmount(): number {
    const tenure = this.loanForm.get('tenure')?.value || 0;
    return this.calculateEMI() * tenure;
  }
}
