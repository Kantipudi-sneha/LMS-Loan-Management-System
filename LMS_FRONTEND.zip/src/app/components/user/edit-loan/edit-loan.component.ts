import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { LoanService } from '../../../services/loan.service';
import { AuthService } from '../../../services/auth.service';
import { LoanApplication } from '../../../models/loan.model';

@Component({
    selector: 'app-edit-loan',
    standalone: true,
    imports: [CommonModule, ReactiveFormsModule],
    templateUrl: './edit-loan.component.html',
    styleUrls: ['./edit-loan.component.css']
})
export class EditLoanComponent implements OnInit {
    loanForm!: FormGroup;
    isLoading = false;
    alertMessage = '';
    alertType: 'info' | 'success' | 'danger' = 'info';
    loanId!: number;
    originalLoan: any = null;

    loanTypes = [
        { value: 'PERSONAL', label: 'Personal Loan' },
        { value: 'BUSINESS', label: 'Business Loan' },
        { value: 'HOME', label: 'Home Loan' },
        { value: 'EDUCATION', label: 'Education Loan' },
        { value: 'VEHICLE', label: 'Vehicle Loan' }
    ];

    constructor(
        private fb: FormBuilder,
        private loanService: LoanService,
        private authService: AuthService,
        private router: Router,
        private route: ActivatedRoute
    ) { }

    ngOnInit(): void {
        this.loanId = Number(this.route.snapshot.paramMap.get('id'));
        if (this.loanId) {
            this.loadLoanData();
        } else {
            this.router.navigate(['/user/loans']);
        }
    }

    private loadLoanData(): void {
        this.isLoading = true;
        console.log('Loading loan data for ID:', this.loanId);

        
        this.loanService.getAllLoanApplications().subscribe({
            next: (loans: any[]) => {
                console.log('All loans received:', loans);
                const loan = loans.find(l => l.id?.toString() === this.loanId.toString());
                console.log('Found loan:', loan);

                if (!loan) {
                    this.alertMessage = 'Loan application not found.';
                    this.alertType = 'danger';
                   
                    return;
                }

                this.originalLoan = loan;

                
                const currentUser = this.authService.getCurrentUser();
                console.log('Current user:', currentUser);
                const isOwner = this.isUserOwner(loan, currentUser);
                console.log('Is owner:', isOwner);

                if (!isOwner) {
                    this.alertMessage = 'You are not authorized to edit this loan application.';
                    this.alertType = 'danger';
                    
                    return;
                }

                
                if (loan.status !== 'PENDING') {
                    this.alertMessage = 'Only pending loan applications can be edited.';
                    this.alertType = 'danger';
                    
                    return;
                }

                console.log('Initializing form with loan data:', loan);
                this.initForm(loan);
            },
            error: (error: any) => {
                console.error('Error loading loan data:', error);
                this.alertMessage = 'Failed to load loan data. Please try again.';
                this.alertType = 'danger';
                
            },
            complete: () => {
                this.isLoading = false;
            }
        });
    }

    private isUserOwner(loan: any, currentUser: any): boolean {
        if (!currentUser) return false;

        return loan['applicantName'] === currentUser.name ||
            loan['email'] === currentUser.email ||
            loan['userId']?.toString() === currentUser.id?.toString() ||
            loan['applicantId']?.toString() === currentUser.sub?.toString();
    }

    private initForm(loan?: any): void {
        console.log('Initializing form with loan data:', loan);

        
        const formData = {
            loanType: loan?.loanType || loan?.type || '',
            amount: loan?.loanAmount || loan?.amount || '',
            tenure: loan?.loanTenure || loan?.tenure || loan?.loanTenure || '',
            purpose: loan?.purpose || '',
            monthlyIncome: loan?.monthlyIncome || '',
            employmentType: loan?.employmentType || loan?.employmentStatus || '',
            applicantName: loan?.applicantName || loan?.name || '',
            workExperience: loan?.workExperience || '',
            existingLoans: loan?.existingLoans || false,
            existingLoanAmount: loan?.existingLoanAmount || 0,
            collateral: loan?.collateral || '',
            additionalDocuments: loan?.additionalDocuments || ''
        };

        console.log('Form data to be set:', formData);

        this.loanForm = this.fb.group({
            loanType: [formData.loanType, Validators.required],
            amount: [formData.amount, [Validators.required, Validators.min(10000), Validators.max(10000000)]],
            tenure: [formData.tenure, [Validators.required, Validators.min(12), Validators.max(300)]],
            purpose: [formData.purpose, [Validators.required, Validators.minLength(10)]],
            monthlyIncome: [formData.monthlyIncome, [Validators.required, Validators.min(10000)]],
            employmentType: [formData.employmentType, Validators.required],
            applicantName: [formData.applicantName, Validators.required],
            workExperience: [formData.workExperience, [Validators.required, Validators.min(1)]],
            existingLoans: [formData.existingLoans],
            existingLoanAmount: [formData.existingLoanAmount],
            collateral: [formData.collateral],
            additionalDocuments: [formData.additionalDocuments]
        });

        console.log('Form initialized with values:', this.loanForm.value);

        this.loanForm.get('existingLoans')?.valueChanges.subscribe((hasExistingLoans: boolean) => {
            if (hasExistingLoans) {
                this.loanForm.get('existingLoanAmount')?.setValidators([Validators.required, Validators.min(1000)]);
            } else {
                this.loanForm.get('existingLoanAmount')?.clearValidators();
                this.loanForm.get('existingLoanAmount')?.setValue(0);
            }
            this.loanForm.get('existingLoanAmount')?.updateValueAndValidity();
        });
    }

    onSubmit(): void {
        console.log('Form submitted');
        

        if (this.loanForm.valid) {
            this.isLoading = true;
            this.alertMessage = '';

            const currentUser = this.authService.getCurrentUser();
            console.log('Current user for update:', currentUser);

            const updatedLoanData: LoanApplication = {
                ...this.originalLoan,
                applicantName: this.loanForm.value.applicantName,
                loanAmount: this.loanForm.value.amount,
                loanTenure: this.loanForm.value.tenure,
                loanType: this.loanForm.value.loanType,
                purpose: this.loanForm.value.purpose,
                monthlyIncome: this.loanForm.value.monthlyIncome,
                employmentType: this.loanForm.value.employmentType,
                employmentStatus: this.loanForm.value.employmentType,
                workExperience: this.loanForm.value.workExperience,
                existingLoans: this.loanForm.value.existingLoans,
                existingLoanAmount: this.loanForm.value.existingLoanAmount,
                collateral: this.loanForm.value.collateral,
                additionalDocuments: this.loanForm.value.additionalDocuments,
                email: currentUser?.email || this.originalLoan.email,
                userId: currentUser?.id || this.originalLoan.userId
            };

            
            console.log('Loan ID for update:', this.loanId);

         
            this.loanService.updateLoanApplication(this.loanId, updatedLoanData).subscribe({
                next: (response: LoanApplication) => {
                    console.log('Update successful:', response);
                    this.alertMessage = 'Loan application updated successfully!';
                    this.alertType = 'success';
                    setTimeout(() => {
                        this.router.navigate(['/user/loans']);
                    }, 2000);
                },
                error: (error: any) => {
                    console.error('Direct update failed:', error);
                    console.log('Trying fallback strategy...');
                    this.fallbackUpdateStrategy(updatedLoanData);
                },
                complete: () => {
                    this.isLoading = false;
                }
            });
        } else {
            console.log('Form is invalid, marking fields as touched');
            this.markFormGroupTouched();

            
            Object.keys(this.loanForm.controls).forEach(key => {
                const control = this.loanForm.get(key);
                if (control && control.invalid) {
                    console.log(`Invalid field: ${key}`, control.errors);
                }
            });

            this.alertMessage = 'Please fill in all required fields correctly.';
            this.alertType = 'danger';
        }
    }

    private fallbackUpdateStrategy(updatedLoanData: LoanApplication): void {
       
        const { id, ...loanDataWithoutId } = updatedLoanData as any;

        this.loanService.deleteLoanApplication(this.loanId).subscribe({
            next: () => {
                this.loanService.applyForLoan(loanDataWithoutId).subscribe({
                    next: (response: LoanApplication) => {
                        this.alertMessage = 'Loan application updated successfully!';
                        this.alertType = 'success';
                        setTimeout(() => {
                            this.router.navigate(['/user/loans']);
                        }, 2000);
                    },
                    error: (error: any) => {
                        this.alertMessage = 'Failed to update loan application. Please try again.';
                        this.alertType = 'danger';
                    },
                    complete: () => {
                        this.isLoading = false;
                    }
                });
            },
            error: (error: any) => {
                this.alertMessage = 'Failed to update loan application. Please try again.';
                this.alertType = 'danger';
                this.isLoading = false;
            }
        });
    }

    private markFormGroupTouched(): void {
        Object.keys(this.loanForm.controls).forEach(key => {
            const control = this.loanForm.get(key);
            control?.markAsTouched();
        });
    }

    isFieldInvalid(fieldName: string): boolean {
        const field = this.loanForm.get(fieldName);
        return !!(field && field.invalid && (field.dirty || field.touched));
    }

    getFieldError(fieldName: string): string {
        const field = this.loanForm.get(fieldName);
        if (field && field.errors) {
            if (field.errors['required']) return `${fieldName} is required`;
            if (field.errors['min']) return `${fieldName} must be at least ${field.errors['min'].min}`;
            if (field.errors['max']) return `${fieldName} must be at most ${field.errors['max'].max}`;
            if (field.errors['minlength']) return `${fieldName} must be at least ${field.errors['minlength'].requiredLength} characters`;
        }
        return '';
    }

    calculateEMI(): number {
        const amount = this.loanForm.get('amount')?.value || 0;
        const tenure = this.loanForm.get('tenure')?.value || 0;
        const rate = 12; // annual interest rate in %

        if (amount && tenure) {
            const monthlyRate = rate / 12 / 100;
            const emi = amount * monthlyRate * Math.pow(1 + monthlyRate, tenure) / (Math.pow(1 + monthlyRate, tenure) - 1);
            return Math.round(emi);
        }
        return 0;
    }

    getTotalAmount(): number {
        const tenure = this.loanForm.get('tenure')?.value || 0;
        return this.calculateEMI() * tenure;
    }

    onCancel(): void {
        this.router.navigate(['/user/loans']);
    }
}
