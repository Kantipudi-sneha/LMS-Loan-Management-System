import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PaymentRequestDTO, PaymentResponseDTO, Penalty } from 'src/app/models/payment.model';
import { PaymentService } from 'src/app/services/payment.service';
import { LoanService } from 'src/app/services/loan.service';
import { EmiScheduleService } from 'src/app/services/emi-schedule.service';
import { Loan } from 'src/app/models/loan.model';

@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  paymentData: PaymentRequestDTO = {
    loanId: '',
    emiNumber: 1,
    paymentAmount: 0,
    paymentMethod: 'Credit Card'
  };

  payments: PaymentResponseDTO[] = [];
  penalties: Penalty[] = [];
  loans: Loan[] = [];
  selectedLoanId: string = '';
  statusMessage: string = '';
  isLoading: boolean = false;
  showPenalties: boolean = false;

  constructor(
    private paymentService: PaymentService,
    private loanService: LoanService,
    private emiScheduleService: EmiScheduleService
  ) { }

  ngOnInit(): void {
    this.loadPayments();
  }

  loadLoans(): void {
    this.isLoading = true;
    this.loanService.getAllLoans().subscribe({
      next: (data: Loan[]) => {
        this.loans = data.filter(loan => loan.status === 'DISBURSED');
        this.isLoading = false;
        console.log('Loaded loans from backend:', this.loans);
      },
      error: (error) => {
        console.error('Error loading loans:', error);
        this.statusMessage = 'Error loading loans: ' + (error.error?.message || 'Backend API not responding');
        this.loans = [];
        this.isLoading = false;
      }
    });
  }

  loadPayments(): void {
    this.isLoading = true;
    this.paymentService.getCurrentUserPayments().subscribe({
      next: (data: PaymentResponseDTO[]) => {
        this.payments = data;
        this.isLoading = false;
        console.log('Loaded user payments from backend:', this.payments);
      },
      error: (error) => {
        console.error('Error loading user payments:', error);
        // Fallback to filtered getAllPayments if getCurrentUserPayments fails
        this.loadAndFilterAllPayments();
      }
    });
  }

  loadAndFilterAllPayments(): void {
    this.paymentService.getAllPayments().subscribe({
      next: (data: PaymentResponseDTO[]) => {
        // Filter payments for current user only
        this.payments = data.filter(payment =>
          payment.loanId && this.isCurrentUserPayment(payment)
        );
        this.isLoading = false;
        console.log('Loaded and filtered user payments:', this.payments);
      },
      error: (error) => {
        console.error('Error loading all payments:', error);
        this.statusMessage = 'Error loading payments: ' + (error.error?.message || 'Backend API not responding');
        this.payments = [];
        this.isLoading = false;
      }
    });
  }

  private isCurrentUserPayment(payment: any): boolean {
    // Add logic to match payment to current user
    // This could be based on userId, email, or other user identifier
    return true; // Implement proper user matching logic
  }

  loadPaymentsByLoanId(): void {
    this.loadPayments();
  }

  loadPenaltiesByLoanId(): void {
    this.penalties = [];
  }

  submitPayment(): void {
    if (!this.paymentData.loanId || this.paymentData.paymentAmount <= 0) {
      this.statusMessage = 'Please enter valid payment details.';
      return;
    }

    this.isLoading = true;
    this.statusMessage = '';

    const paymentRequest: PaymentRequestDTO = {
      loanId: this.paymentData.loanId,
      emiNumber: this.paymentData.emiNumber,
      paymentAmount: this.paymentData.paymentAmount,
      paymentMethod: this.paymentData.paymentMethod,
      transactionId: 'TXN' + Date.now(),
      paymentDate: new Date().toISOString().split('T')[0]
    };

    this.paymentService.createOrUpdatePayment(paymentRequest).subscribe({
      next: (newPayment: PaymentResponseDTO) => {
        this.statusMessage = 'Payment successful!';
        this.payments.unshift(newPayment);

        // Update EMI status to PAID after successful payment creation
        this.updateEmiStatus(paymentRequest.loanId, paymentRequest.emiNumber, 'PAID');

        // Reset form
        this.paymentData = {
          loanId: '',
          emiNumber: 1,
          paymentAmount: 0,
          paymentMethod: 'Credit Card'
        };

        this.isLoading = false;
        console.log('Payment added successfully:', newPayment);
      },
      error: (error) => {
        console.error('Error creating payment:', error);
        this.statusMessage = 'Error creating payment: ' + (error.error?.message || 'Backend API not responding');
        this.isLoading = false;
      }
    });
  }

  // New method to update EMI status
  updateEmiStatus(loanId: string, emiNumber: number, status: string): void {
    console.log(`Attempting to update EMI status: Loan ${loanId}, EMI ${emiNumber} to ${status}`);

    this.emiScheduleService.updateEmiStatus(loanId, emiNumber, status).subscribe({
      next: (response) => {
        console.log(`EMI ${emiNumber} for loan ${loanId} updated to ${status}:`, response);
        // Notify other components that EMI data has been updated
        this.emiScheduleService.notifyEmiUpdated();
      },
      error: (error) => {
        console.error('Error updating EMI status:', error);

        // If status update fails, try removing the paid EMI from schedule
        if (status === 'PAID') {
          console.log('Status update failed, attempting to remove paid EMI from schedule...');
          this.removePaidEmiFromSchedule(loanId, emiNumber);
        } else {
          console.warn('Payment was successful but EMI status update failed. EMI status may need manual update.');
        }
      }
    });
  }

  // New method to remove paid EMI from schedule
  removePaidEmiFromSchedule(loanId: string, emiNumber: number): void {
    this.emiScheduleService.removePaidEmi(loanId, emiNumber).subscribe({
      next: (response) => {
        console.log(`Paid EMI ${emiNumber} removed from schedule for loan ${loanId}:`, response);
        // Notify other components that EMI data has been updated
        this.emiScheduleService.notifyEmiUpdated();
        this.statusMessage += ' EMI removed from schedule.';
      },
      error: (error) => {
        console.error('Error removing paid EMI from schedule:', error);
        console.warn('Could not update EMI schedule. Please refresh the EMI tracking page manually.');
      }
    });
  }

  togglePenalties(): void {
    this.showPenalties = !this.showPenalties;
    if (this.showPenalties && this.selectedLoanId) {
      this.loadPenaltiesByLoanId();
    }
  }

  getPaymentStatusClass(status: string): string {
    switch (status.toLowerCase()) {
      case 'paid':
        return 'status-paid';
      case 'pending':
        return 'status-pending';
      case 'failed':
        return 'status-failed';
      default:
        return '';
    }
  }

  getPenaltyStatusClass(status: string): string {
    switch (status.toLowerCase()) {
      case 'paid':
        return 'status-paid';
      case 'pending':
        return 'status-pending';
      case 'waived':
        return 'status-waived';
      default:
        return '';
    }
  }
}
