import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { LoanService } from 'src/app/services/loan.service';
import { DisbursementService } from 'src/app/services/disbursement.service';
import { AuthService } from 'src/app/services/auth.service';
import { LoanApplication, LoanDisbursement } from 'src/app/models/loan.model';

@Component({
  selector: 'app-loans',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './loans.component.html',
  styleUrls: ['./loans.component.css']
})
export class LoansComponent implements OnInit {
  loans: LoanApplication[] = [];
  disbursements: LoanDisbursement[] = [];
  isLoading = false;
  errorMessage = '';
  currentUser: any;

  constructor(
    private loanService: LoanService,
    private disbursementService: DisbursementService,
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUser();
    this.loadLoans();
    this.loadDisbursements();
  }

  refreshLoans(): void {
    this.loadLoans();
    this.loadDisbursements();
  }

  loadLoans(): void {
    this.isLoading = true;
    this.errorMessage = '';

    console.log('Current user:', this.currentUser);
    console.log('Current user ID:', this.currentUser?.id);
    console.log('Current user sub:', this.currentUser?.sub);
    console.log('Current user username:', this.currentUser?.username);
    console.log('Current user email:', this.currentUser?.email);

    // First try to get current user's loans specifically
    this.loanService.getCurrentUserLoans().subscribe({
      next: (data) => {
        console.log('Current user loans received:', data);
        this.processUserLoans(data);
      },
      error: (err) => {
        console.error('Error loading current user loans:', err);
        // Fallback to getAllLoanApplications with filtering
        this.loadAllLoansAndFilter();
      }
    });
  }

  // Process user-specific loans
  processUserLoans(data: any[]): void {
    const userLoans = data;
    console.log(`Showing ${userLoans.length} user-specific loans`);
    this.loans = userLoans.map((loan: any) => ({
      ...loan,
      tenure: loan.loanTenure ?? loan.term ?? loan.tenure ?? 0,
      applicationDate: loan.applicationDate ?? loan.appliedDate ?? '',
      loanType: loan.loanType ?? 'PERSONAL'
    }));

    console.log('Final processed user loans:', this.loans);
    this.isLoading = false;
  }

  // Fallback method to filter all loans for current user
  loadAllLoansAndFilter(): void {
    console.log('Fallback: Loading all loans and filtering for current user');

    this.loanService.getAllLoanApplications().subscribe({
      next: (data) => {
        console.log('All loans received for filtering:', data);

        // Filter loans for current user only
        const userLoans = data.filter((loan: any) => this.isCurrentUserLoan(loan));
        console.log(`Filtered to ${userLoans.length} loans for current user`);

        this.loans = userLoans.map((loan: any) => ({
          ...loan,
          tenure: loan.loanTenure ?? loan.term ?? loan.tenure ?? 0,
          applicationDate: loan.applicationDate ?? loan.appliedDate ?? '',
          loanType: loan.loanType ?? 'PERSONAL'
        }));

        console.log('Final filtered loans:', this.loans);
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Error loading all loans:', err);
        this.errorMessage = 'Failed to load loans. Please try again later.';
        this.isLoading = false;
      }
    });
  }

  // Helper method to check if loan belongs to current user
  private isCurrentUserLoan(loan: any): boolean {
    if (!this.currentUser) {
      console.log('No current user found for loan filtering');
      return false;
    }

    // Strict matching - only show loans that clearly belong to current user
    const currentUsername = this.currentUser.username || this.currentUser.sub;

    const isMatch = (
      // Check userId fields
      (loan.userId && (loan.userId === this.currentUser.sub || loan.userId === this.currentUser.id)) ||
      // Check applicantId fields  
      (loan.applicantId && (loan.applicantId === this.currentUser.sub || loan.applicantId === this.currentUser.id)) ||
      // Check applicant name - must match exactly (case-insensitive)
      (loan.applicantName && currentUsername &&
        loan.applicantName.toLowerCase().trim() === currentUsername.toLowerCase().trim()) ||
      // Check username fields
      (loan.username && currentUsername &&
        loan.username.toLowerCase().trim() === currentUsername.toLowerCase().trim()) ||
      // Check email fields
      (loan.email && this.currentUser.email &&
        loan.email.toLowerCase().trim() === this.currentUser.email.toLowerCase().trim())
    );

    console.log(`Loans component loan ${loan.id} match check:`, {
      loanUserId: loan.userId,
      loanApplicantId: loan.applicantId,
      loanApplicantName: loan.applicantName,
      loanUsername: loan.username,
      loanEmail: loan.email,
      currentUserSub: this.currentUser.sub,
      currentUserId: this.currentUser.id,
      currentUserUsername: currentUsername,
      currentUserEmail: this.currentUser.email,
      isMatch: isMatch
    });

    return isMatch;
  }

  loadDisbursements(): void {
    this.disbursementService.getAll().subscribe({
      next: (data) => {
        this.disbursements = data;
        console.log('Disbursements loaded:', this.disbursements);
      },
      error: (err) => {
        console.error('Error loading disbursements:', err);
      }
    });
  }

  getStatusBadgeClass(status: string): string {
    switch (status?.toUpperCase()) {
      case 'APPROVED':
        return 'badge-success';
      case 'REJECTED':
        return 'badge-danger';
      case 'PENDING':
        return 'badge-warning';
      case 'PROCESSING':
        return 'badge-info';
      default:
        return 'badge-secondary';
    }
  }

  getStatusIcon(status: string): string {
    switch (status?.toUpperCase()) {
      case 'APPROVED':
        return 'fas fa-check-circle';
      case 'REJECTED':
        return 'fas fa-times-circle';
      case 'PENDING':
        return 'fas fa-clock';
      case 'PROCESSING':
        return 'fas fa-cog fa-spin';
      default:
        return 'fas fa-question-circle';
    }
  }

  formatDate(dateString?: string): string {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0
    }).format(amount);
  }

  applyForNewLoan(): void {
    this.router.navigate(['/user/apply-loan']);
  }

  editLoan(loanId: number): void {
    this.router.navigate(['/user/edit-loan', loanId]);
  }

  selectedLoan: any = null;
  loanToDelete: number | null = null;
  showDetailsModal = false;
  showDeleteModal = false;

  viewLoanDetails(loanId?: number): void {
    console.log('viewLoanDetails called with loanId:', loanId);
    if (!loanId) {
      console.log('No loanId provided');
      return;
    }

    const loan = this.loans.find(l => l.id === loanId);
    console.log('Found loan:', loan);
    if (!loan) {
      console.log('Loan not found for ID:', loanId);
      return;
    }

    this.selectedLoan = loan;
    this.showDetailsModal = true;
  }

  deleteLoan(loanId?: number): void {
    console.log('deleteLoan called with loanId:', loanId);
    if (!loanId) {
      console.error('No loan ID provided for deletion');
      return;
    }

    this.loanToDelete = loanId;
    this.showDeleteModal = true;
  }

  confirmDelete(): void {
    if (!this.loanToDelete) return;

    console.log('User confirmed deletion, calling service...');
    this.loanService.deleteLoanApplication(this.loanToDelete).subscribe({
      next: (response) => {
        console.log('Delete API response:', response);
        this.loans = this.loans.filter(loan => loan.id !== this.loanToDelete);
        console.log('Loan deleted successfully from UI');


        this.showDeleteModal = false;
        this.selectedLoan = { message: 'Loan application deleted successfully!' };
        this.showDetailsModal = true;

        this.loanToDelete = null;
      },
      error: (error) => {
        console.error('Error deleting loan:', error);
        this.errorMessage = `Failed to delete loan application: ${error.error?.message || error.message}`;

        this.showDeleteModal = false;
        this.selectedLoan = { message: `Failed to delete loan: ${error.error?.message || error.message}` };
        this.showDetailsModal = true;

        this.loanToDelete = null;
      }
    });
  }

  closeDetailsModal(): void {
    this.showDetailsModal = false;
    this.selectedLoan = null;
  }

  closeDeleteModal(): void {
    this.showDeleteModal = false;
    this.loanToDelete = null;
  }


  getTotalLoans(): number {
    return this.loans.length;
  }

  getApprovedLoans(): number {
    return this.loans.filter(loan => loan.status?.toUpperCase() === 'APPROVED').length;
  }

  getPendingLoans(): number {
    return this.loans.filter(loan => loan.status?.toUpperCase() === 'PENDING').length;
  }

  getRejectedLoans(): number {
    return this.loans.filter(loan => loan.status?.toUpperCase() === 'REJECTED').length;
  }


  getLoanTypeFromPurpose(purpose?: string): string {
    console.log('Getting loan type for purpose:', purpose);

    if (!purpose) {
      console.log('No purpose provided, defaulting to PERSONAL');
      return 'PERSONAL';
    }

    const purposeLower = purpose.toLowerCase();
    console.log('Purpose lowercase:', purposeLower);

    if (purposeLower.includes('home') || purposeLower.includes('house') || purposeLower.includes('property')) {
      console.log('Detected HOME loan');
      return 'HOME';
    } else if (purposeLower.includes('business') || purposeLower.includes('startup') || purposeLower.includes('company')) {
      console.log('Detected BUSINESS loan');
      return 'BUSINESS';
    } else if (purposeLower.includes('education') || purposeLower.includes('study') || purposeLower.includes('college') || purposeLower.includes('school')) {
      console.log('Detected EDUCATION loan');
      return 'EDUCATION';
    } else if (purposeLower.includes('vehicle') || purposeLower.includes('car') || purposeLower.includes('bike') || purposeLower.includes('auto')) {
      console.log('Detected VEHICLE loan');
      return 'VEHICLE';
    } else {
      console.log('No specific type detected, defaulting to PERSONAL');
      return 'PERSONAL';
    }
  }

  getDisbursementStatusText(loan: LoanApplication): string {
    if (loan.status === 'REJECTED') {
      return 'REJECTED';
    }

    if (loan.status !== 'APPROVED') {
      return 'N/A';
    }

    const disbursement = this.disbursements.find(d => d.loanId === loan.id);
    console.log(`Loan ${loan.id} disbursement:`, disbursement);
    return disbursement?.status || 'PENDING';
  }

  getDisbursementStatusClass(status?: string): string {
    switch (status?.toUpperCase()) {
      case 'DISBURSED':
        return 'badge-success';
      case 'PENDING':
        return 'badge-warning';
      case 'APPROVED':
        return 'badge-info';
      case 'FAILED':
        return 'badge-danger';
      case 'REJECTED':
        return 'badge-danger';
      case 'CANCELLED':
        return 'badge-secondary';
      default:
        return 'badge-light';
    }
  }

  getDisbursementStatusIcon(status?: string): string {
    switch (status?.toUpperCase()) {
      case 'DISBURSED':
        return 'fas fa-check-circle';
      case 'PENDING':
        return 'fas fa-clock';
      case 'APPROVED':
        return 'fas fa-thumbs-up';
      case 'FAILED':
        return 'fas fa-times-circle';
      case 'REJECTED':
        return 'fas fa-ban';
      case 'CANCELLED':
        return 'fas fa-minus-circle';
      default:
        return 'fas fa-question-circle';
    }
  }
}
