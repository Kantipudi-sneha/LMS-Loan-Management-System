export interface Admin {
  id?: number;
  username: string;
  email: string;
  password?: string;
  role: string;
  isActive: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface AdminDTO {
  username: string;
  email: string;
  password: string;
  confirmPassword: string;
  role: string;
}

export interface AdminApprovalDTO {
  adminId: number;
  approve: boolean;
}


export interface AdminResponse {
  id: number;
  username: string;
  email: string;
  role: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}
