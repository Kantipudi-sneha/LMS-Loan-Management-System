export interface Loan {
  loanId?: string;
  loanType: string;
  amount: number;
  interestRate: number;
  term: number; // tenure in months
  tenure?: number; // alias for UI
  monthlyPayment: number;
  totalAmount: number;
  status: string;
  userId?: number;
  createdAt?: string;
  updatedAt?: string;
  applicationDate?: string; // for UI display
}

export interface LoanApplication {
  [x: string]: any;
  id?: number;
  applicantName: string; // maps to applicant_name in DB
  applicationDate: string; // maps to application_date
  email: string;
  loanAmount: number; // maps to loan_amount
  loanTenure: number; // maps to loan_tenure
  status: string;

  // Extra fields for UI/form compatibility
  userId?: number;
  loanType?: string; // optional for UI logic
  purpose?: string;
  monthlyIncome?: number;
  employmentStatus?: string;
  employmentType?: string;
  creditScore?: number;
  appliedDate?: string;
  approvedDate?: string;
  rejectedDate?: string;
  rejectionReason?: string;
  tenure?: number; // alias for term
  amount?: number; // alias for loanAmount
  term?: number; // alias for loanTenure
}

export interface LoanApproval {
  id?: number;
  loanApplicationId: number;
  adminId: number;
  approvedAmount: number;
  approvedInterestRate: number;
  approvedTerm: number;
  approvalDate?: string;
  comments?: string;
  status: string;
}

export interface LoanDisbursement {
  id?: number;
  loanId?: number;
  amount?: number;
  status?: 'PENDING' | 'APPROVED' | 'DISBURSED' | 'FAILED' | 'REJECTED' | 'CANCELLED';
  utrNumber?: string;
  customerAccountNumber?: string;
  referenceId?: string;
  disbursementMethod?: string;
  createdAt?: string;
  updatedAt?: string;
  
  // UI compatibility field
  disbursedAmount?: number; // Maps to 'amount'
}

export interface EmiSchedule {
  id?: number;
  loanId: string;
  emiNumber: number;
  dueDate: string;
  amount: number;
  principalAmount: number;
  interestAmount: number;
  remainingBalance: number;
  status: string;
}

export interface EmiScheduleRequestDTO {
  loanId: string;
  emiNumber: number;
  status: string;
}

export interface UpdateEmiStatusRequestDTO {
  loanId: string;
  emiNumber: number;
  status: string;
}
