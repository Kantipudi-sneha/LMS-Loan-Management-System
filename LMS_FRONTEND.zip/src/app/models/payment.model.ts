import { Loan } from "./loan.model";

export interface Payment {
  paymentId?: number;
  loanId: string;
  emiNumber: number;
  paymentDate?: string;
  paymentAmount: number;
  paymentMethod: string;
  transactionId?: string;
  daysOverdue: number;
  totalDue: number;
  paymentStatus: string;
  failureReason?: string;
  loan?: Loan;
}

export interface PaymentRequestDTO {
  loanId: string;
  emiNumber: number;
  paymentAmount: number;
  paymentMethod: string;
  transactionId?: string;
  paymentDate?: string;
}

export interface PaymentResponseDTO {
  paymentId: number;
  loanId: string;
  emiNumber: number;
  paymentDate: string;
  paymentAmount: number;
  paymentMethod: string;
  transactionId: string;
  daysOverdue: number;
  totalDue: number;
  paymentStatus: string;
  failureReason: string;
}

export interface Penalty {
  id?: number;
  loanId: string;
  emiNumber: number;
  penaltyAmount: number;
  penaltyDate?: string;
  reason: string;
  status: string;
}

export interface PenaltyRequestDTO {
  loanId: string;
  emiNumber: number;
  penaltyAmount: number;
  reason: string;
}
