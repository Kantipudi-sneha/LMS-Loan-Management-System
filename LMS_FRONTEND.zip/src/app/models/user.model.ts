export interface User {
  id?: number;
  username: string;
  email: string;
  mobileNumber: string;
  dateOfBirth: string;
  aadharNumber: string;
  panNumber: string;
  address: string;
  occupation: string;
  employerName: string;
  monthlyIncome: number;
  bankName: string;
  accountNumber: string;
  ifscCode: string;
  isActive: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface UserRegistrationDTO {
  username: string;
  email: string;
  password: string;
  confirmPassword: string;
  mobileNumber: string;
  dateOfBirth: string;
  aadharNumber: string;
  panNumber: string;
  address: string;
  occupation: string;
  employerName: string;
  monthlyIncome: number;
  bankName: string;
  accountNumber: string;
  ifscCode: string;
}

export interface UserProfileDTO {
  id?: number;
  username: string;
  email: string;
  mobileNumber: string;
  dateOfBirth: string;
  aadharNumber: string;
  panNumber: string;
  address: string;
  occupation: string;
  employerName: string;
  monthlyIncome: number;
  bankName: string;
  accountNumber: string;
  ifscCode: string;
}

export interface UserResponseDTO {
  id: number;
  username: string;
  email: string;
  mobileNumber: string;
  dateOfBirth: string;
  aadharNumber: string;
  panNumber: string;
  address: string;
  occupation: string;
  employerName: string;
  monthlyIncome: number;
  bankName: string;
  accountNumber: string;
  ifscCode: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  role?: string;
  roles?: string[];
  firstName?: string;
  lastName?: string;
  phoneNumber?: string;
}

export interface LoginDTO {
  username: string;
  password: string;
}

export interface ChangePasswordDTO {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

export interface AuthResponse {
  token: string;
  username: string;
  roles: string[];
}
