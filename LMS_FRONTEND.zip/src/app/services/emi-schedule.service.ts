import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class EmiScheduleService {
  private baseUrl = 'http://localhost:8080/api/emi-schedule';

  // Event that components can listen to
  private emiUpdatedSource = new Subject<void>();
  emiUpdated$ = this.emiUpdatedSource.asObservable();

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) { }

  // Notify listeners that EMI data should refresh
  notifyEmiUpdated() {
    this.emiUpdatedSource.next();
  }

  getAllSchedules(): Observable<any[]> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<any[]>(this.baseUrl, { headers });
  }

  generateSchedule(request: any): Observable<any[]> {
    const headers = this.authService.getAuthHeaders();
    console.log('Generating EMI schedule with request:', request);
    return this.http.post<any[]>(`${this.baseUrl}/generate`, request, { headers });
  }

  getScheduleByLoanId(loanId: string): Observable<any[]> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/loan/${loanId}`, { headers });
  }

  updateEmiStatus(loanId: string, emiNumber: number, status: string): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    console.log(`Updating EMI status: Loan ${loanId}, EMI ${emiNumber} to ${status}`);
    return this.http.put(`${this.baseUrl}/${loanId}/${emiNumber}`, { status }, { headers });
  }

  removePaidEmi(loanId: string, emiNumber: number): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    console.log(`Removing paid EMI: Loan ${loanId}, EMI ${emiNumber}`);
    return this.http.delete(`${this.baseUrl}/${loanId}/${emiNumber}`, { headers });
  }
}
