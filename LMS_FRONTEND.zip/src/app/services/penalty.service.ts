import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

export interface PenaltyRequest {
  loanId: string;
  emiNumber: number;
  reason: string;
}

export interface Penalty {
  penaltyId: number;
  loanId: string;
  emiNumber: number;
  penaltyAmount: number;
  reason: string;
}

export interface EmiSchedule {
  loanId: string;
  emiNumber: number;
  dueDate: string;
  principal: number;
  interest: number;
  emiAmount: number;
  status: string;
  createdDate: string;
  lastModified: string;
}

@Injectable({
  providedIn: 'root'
})
export class PenaltyTrackingService {
  private baseUrl = 'http://localhost:8080/api/penalties';
  private emiBaseUrl = 'http://localhost:8080/api/emi-schedule';

  constructor(private http: HttpClient) {}

  getAllPenalties(): Observable<Penalty[]> {
    return this.http.get<Penalty[]>(this.baseUrl);
  }

  calculateAndAddPenalty(penaltyRequest: PenaltyRequest): Observable<Penalty> {
    return this.http.post<Penalty>(`${this.baseUrl}/calculate-add`, penaltyRequest);
  }

  getEmiSchedule(loanId: string, emiNumber: number): Observable<EmiSchedule[]> {
    return this.http.get<EmiSchedule[]>(`${this.emiBaseUrl}/loan/${loanId}/emi/${emiNumber}`);
  }

  getPenaltiesByLoanAndEmiNumber(loanId: string, emiNumber: number): Observable<Penalty[]> {
    return this.http.get<Penalty[]>(`${this.baseUrl}/loan/${loanId}/emi/${emiNumber}`);
  }
}
