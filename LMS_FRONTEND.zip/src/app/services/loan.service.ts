import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import {
  Loan,
  LoanApplication,
  LoanApproval,
  EmiSchedule,
  EmiScheduleRequestDTO,
  UpdateEmiStatusRequestDTO
} from '../models/loan.model';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class LoanService {
   
  private readonly API_URL = 'http://localhost:8080';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) { }

  getAllLoans(): Observable<Loan[]> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<Loan[]>(`${this.API_URL}/api/loans`, { headers });
  }

 
  getCurrentUserLoans(): Observable<Loan[]> {
    const headers = this.authService.getAuthHeaders();
    const currentUser = this.authService.getCurrentUser();

    if (!currentUser || !currentUser.sub) {
      console.error('User not authenticated or missing ID');
      return new Observable<Loan[]>(observer => {
        observer.error('User not authenticated');
        observer.complete();
      });
    }

    return this.http.get<Loan[]>(`${this.API_URL}/api/loans/user/${currentUser.sub}`, { headers });
  }

  
  getLoanById(loanId: string): Observable<any> {
    const headers = this.authService.getAuthHeaders();
 
    return this.getAllLoans().pipe(
      map((loans: any[]) => {
        const loan = loans.find(l => l.id?.toString() === loanId || l.loanId?.toString() === loanId);
        if (!loan) {
          throw new Error('Loan not found');
        }
        return loan;
      })
    );
  }


 
  applyForLoan(loanApplication: LoanApplication): Observable<LoanApplication> {
    const headers = this.authService.getAuthHeaders();
    console.log('Submitting loan application:', loanApplication);
    return this.http.post<LoanApplication>(`${this.API_URL}/api/loans/apply`, loanApplication, { headers });
  }

  
  getAllLoanApplications(): Observable<LoanApplication[]> {
    const headers = this.authService.getAuthHeaders();
  
    return this.http.get<LoanApplication[]>(`${this.API_URL}/api/loans`, { headers });
  }

 
  getLoanApplicationById(id: number): Observable<LoanApplication> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<LoanApplication>(`${this.API_URL}/api/loans/${id}`, { headers });
  }


  updateLoanStatus(id: number, status: string): Observable<LoanApplication> {
    const headers = this.authService.getAuthHeaders();
    return this.http.put<LoanApplication>(`${this.API_URL}/api/loans/${id}/status?status=${status}`, {}, { headers });
  }


  deleteLoanApplication(id: number): Observable<void> {
    const headers = this.authService.getAuthHeaders();
    return this.http.delete<void>(`${this.API_URL}/api/loans/${id}`, { headers });
  }


  updateLoanApplication(id: number, loanApplication: LoanApplication): Observable<LoanApplication> {
    const headers = this.authService.getAuthHeaders();
    return this.http.put<LoanApplication>(`${this.API_URL}/api/loans/${id}`, loanApplication, { headers });
  }

 
  getEmiSchedules(loanId: string): Observable<EmiSchedule[]> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<EmiSchedule[]>(`${this.API_URL}/api/emi-schedules/loan/${loanId}`, { headers });
  }


  updateEmiStatus(request: UpdateEmiStatusRequestDTO): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    return this.http.put(`${this.API_URL}/api/emi-schedules/update-status`, request, { headers });
  }

 
  getUserLoansByUserId(userId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.API_URL}/user/${userId}`);
  }

  getUserLoansByName(applicantName: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.API_URL}/applicant/${applicantName}`);
  }

  getUserLoansByEmail(email: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.API_URL}/email/${email}`);
  }


  calculateEMI(principal: number, rate: number, time: number): number {
    const monthlyRate = rate / (12 * 100);
    const months = time * 12;

    if (monthlyRate === 0) {
      return principal / months;
    }

    const emi = principal * monthlyRate * Math.pow(1 + monthlyRate, months) / (Math.pow(1 + monthlyRate, months) - 1);
    return Math.round(emi * 100) / 100;
  }

  calculateTotalAmount(principal: number, rate: number, time: number): number {
    const emi = this.calculateEMI(principal, rate, time);
    const months = time * 12;
    return Math.round(emi * months * 100) / 100;
  }

  
  getApprovedLoans(): Observable<LoanApplication[]> {
    const headers = this.authService.getAuthHeaders();
    // Fallback to client-side filtering if backend endpoint doesn't exist
    return this.http.get<LoanApplication[]>(`${this.API_URL}/api/loans`, { headers }).pipe(
      map((loans: any[]) => {
   
        return loans.filter(loan => loan.status === 'APPROVED');
      })
    );
  }
}
