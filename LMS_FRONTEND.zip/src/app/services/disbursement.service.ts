import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { LoanDisbursement } from '../models/loan.model';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class DisbursementService {
  private baseUrl = 'http://localhost:8080/api/disbursements';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  getAll(): Observable<LoanDisbursement[]> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<LoanDisbursement[]>(`${this.baseUrl}`, { headers });
  }

  getById(id: number): Observable<LoanDisbursement> {
    const headers = this.authService.getAuthHeaders();
    console.log(`Fetching disbursement with ID: ${id}`);
    return this.http.get<LoanDisbursement>(`${this.baseUrl}/${id}`, { headers }).pipe(
      tap((data: any) => console.log('Disbursement data received:', data)),
      catchError((error: any) => {
        console.error('Error fetching disbursement:', error);
        throw error;
      })
    );
  }

  create(payload: Omit<LoanDisbursement, 'id'>): Observable<LoanDisbursement> {
    const headers = this.authService.getAuthHeaders();
    console.log('Creating disbursement with payload:', payload);
    return this.http.post<LoanDisbursement>(`${this.baseUrl}`, payload, { headers });
  }

  update(id: number, payload: Omit<LoanDisbursement, 'id'>): Observable<LoanDisbursement> {
    const headers = this.authService.getAuthHeaders();
    return this.http.put<LoanDisbursement>(`${this.baseUrl}/${id}`, payload, { headers });
  }

  delete(id: number): Observable<void> {
    const headers = this.authService.getAuthHeaders();
    return this.http.delete<void>(`${this.baseUrl}/${id}`, { headers });
  }

  getByLoanId(loanId: number): Observable<LoanDisbursement[]> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<LoanDisbursement[]>(`${this.baseUrl}/loan/${loanId}`, { headers });
  }

  // Update UTR and mark as DISBURSED (matches your backend)
  updateUTR(id: number, utrNumber: string): Observable<LoanDisbursement> {
    const headers = this.authService.getAuthHeaders();
    return this.http.put<LoanDisbursement>(`${this.baseUrl}/${id}/utr?utrNumber=${utrNumber}`, {}, { headers });
  }

  // Cancel disbursement (matches your backend)
  cancelDisbursement(id: number): Observable<boolean> {
    const headers = this.authService.getAuthHeaders();
    return this.http.delete<boolean>(`${this.baseUrl}/${id}`, { headers });
  }

  // Admin approval methods (keeping these for future backend implementation)
  approve(id: number): Observable<LoanDisbursement> {
    const headers = this.authService.getAuthHeaders();
    return this.http.put<LoanDisbursement>(`${this.baseUrl}/${id}/approve`, {}, { headers });
  }

  reject(id: number, reason: string): Observable<LoanDisbursement> {
    const headers = this.authService.getAuthHeaders();
    return this.http.put<LoanDisbursement>(`${this.baseUrl}/${id}/reject`, { reason }, { headers });
  }

  disburse(id: number): Observable<LoanDisbursement> {
    const headers = this.authService.getAuthHeaders();
    return this.http.put<LoanDisbursement>(`${this.baseUrl}/${id}/disburse`, {}, { headers });
  }

  markFailed(id: number, reason: string): Observable<LoanDisbursement> {
    const headers = this.authService.getAuthHeaders();
    return this.http.put<LoanDisbursement>(`${this.baseUrl}/${id}/failed`, { reason }, { headers });
  }
}
