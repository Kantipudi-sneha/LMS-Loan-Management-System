import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { 
  Payment, 
  PaymentRequestDTO, 
  PaymentResponseDTO, 
  Penalty, 
  PenaltyRequestDTO 
} from '../models/payment.model';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {
  private readonly API_URL = 'http://localhost:8080';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  // Create or update payment
  createOrUpdatePayment(paymentData: PaymentRequestDTO): Observable<PaymentResponseDTO> {
    const headers = this.authService.getAuthHeaders();
    return this.http.post<PaymentResponseDTO>(`${this.API_URL}/api/payments/add`, paymentData, { headers });
  }

  // Get all payments
  getAllPayments(): Observable<PaymentResponseDTO[]> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<PaymentResponseDTO[]>(`${this.API_URL}/api/payments`, { headers });
  }
  
  // Get current user's payments
  getCurrentUserPayments(): Observable<PaymentResponseDTO[]> {
    const headers = this.authService.getAuthHeaders();
    const currentUser = this.authService.getCurrentUser();
    
    if (!currentUser || !currentUser.sub) {
      console.error('User not authenticated or missing ID');
      return new Observable<PaymentResponseDTO[]>(observer => {
        observer.error('User not authenticated');
        observer.complete();
      });
    }
    
    return this.http.get<PaymentResponseDTO[]>(`${this.API_URL}/api/payments/user/${currentUser.sub}`, { headers });
  }

  // Get payments by loan ID
  getPaymentsByLoanId(loanId: string): Observable<PaymentResponseDTO[]> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<PaymentResponseDTO[]>(`${this.API_URL}/api/payments/loan/${loanId}`, { headers });
  }

  // Update payment
  updatePayment(paymentId: number, paymentData: PaymentRequestDTO): Observable<PaymentResponseDTO> {
    const headers = this.authService.getAuthHeaders();
    return this.http.put<PaymentResponseDTO>(`${this.API_URL}/api/payments/update/${paymentId}`, paymentData, { headers });
  }

  // Get payment by loan ID and EMI number
  getPaymentByLoanIdAndEmiNumber(loanId: string, emiNumber: number): Observable<PaymentResponseDTO> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<PaymentResponseDTO>(`${this.API_URL}/api/payments/loan/${loanId}/emi/${emiNumber}`, { headers });
  }

  // Create penalty
  createPenalty(penaltyData: PenaltyRequestDTO): Observable<Penalty> {
    const headers = this.authService.getAuthHeaders();
    return this.http.post<Penalty>(`${this.API_URL}/api/penalties/add`, penaltyData, { headers });
  }

  // Get penalties by loan ID
  getPenaltiesByLoanId(loanId: string): Observable<Penalty[]> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<Penalty[]>(`${this.API_URL}/api/penalties/loan/${loanId}`, { headers });
  }

  // Update penalty status
  updatePenaltyStatus(penaltyId: number, status: string): Observable<Penalty> {
    const headers = this.authService.getAuthHeaders();
    return this.http.put<Penalty>(`${this.API_URL}/api/penalties/${penaltyId}/status?status=${status}`, {}, { headers });
  }

  // Calculate overdue amount
  calculateOverdueAmount(principal: number, rate: number, daysOverdue: number): number {
    const dailyRate = rate / (365 * 100);
    return Math.round(principal * dailyRate * daysOverdue * 100) / 100;
  }

  // Calculate total due amount
  calculateTotalDue(principal: number, overdueAmount: number, penalties: number): number {
    return Math.round((principal + overdueAmount + penalties) * 100) / 100;
  }
}
