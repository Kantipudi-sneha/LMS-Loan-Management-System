import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserResponseDTO } from '../models/user.model';
import { LoanApplication, LoanApproval } from '../models/loan.model';
import { AdminApprovalDTO } from '../models/admin.model'; // if defined here



import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private readonly API_URL = 'http://localhost:8080';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}


  getAllUsers(): Observable<UserResponseDTO[]> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<UserResponseDTO[]>(`${this.API_URL}/admin/users`, { headers });
  }

  getUserById(id: number): Observable<UserResponseDTO> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<UserResponseDTO>(`${this.API_URL}/admin/users/${id}`, { headers });
  }


  activateUser(id: number): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    return this.http.put<any>(`${this.API_URL}/admin/users/${id}/activate`, {}, { headers });
  }

  deactivateUser(id: number): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    return this.http.put<any>(`${this.API_URL}/admin/users/${id}/deactivate`, {}, { headers });
  }

  
  deleteInactiveUser(id: number): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    return this.http.delete<any>(`${this.API_URL}/admin/users/${id}`, { headers });
  }

  getAllLoanApplications(): Observable<LoanApplication[]> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<LoanApplication[]>(`${this.API_URL}/api/loans`, { headers });
  }

  
  getLoanApplicationById(id: number): Observable<LoanApplication> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<LoanApplication>(`${this.API_URL}/api/loans/${id}`, { headers });
  }

  
  approveLoanApplication(loanId: number, approvalData: AdminApprovalDTO): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    return this.http.put<any>(`${this.API_URL}/api/loans/${loanId}/status?status=APPROVED`, approvalData, { headers });
  }

 
  rejectLoanApplication(applicationId: number, reason: string): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    return this.http.put<any>(`${this.API_URL}/api/loans/${applicationId}/status?status=REJECTED&reason=${reason}`, {}, { headers });
  }

  updateLoanApplicationStatus(id: number, status: string, reason?: string): Observable<LoanApplication> {
    const headers = this.authService.getAuthHeaders();
    let url = `${this.API_URL}/api/loans/${id}/status?status=${status}`;
    if (reason) {
      url += `&reason=${reason}`;
    }
    return this.http.put<LoanApplication>(url, {}, { headers });
  }

  getDashboardStats(): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<any>(`${this.API_URL}/admin/dashboard/stats`, { headers });
  }

  getLoanApprovalStats(): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<any>(`${this.API_URL}/admin/dashboard/loan-stats`, { headers });
  }

  getUserStats(): Observable<any> {
    const headers = this.authService.getAuthHeaders();
    return this.http.get<any>(`${this.API_URL}/admin/dashboard/user-stats`, { headers });
  }
}
