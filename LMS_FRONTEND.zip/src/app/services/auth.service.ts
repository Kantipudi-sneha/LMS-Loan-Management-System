import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { Router } from '@angular/router';
import { jwtDecode } from 'jwt-decode';

import { UserRegistrationDTO, LoginDTO, AuthResponse, UserProfileDTO, ChangePasswordDTO } from '../models/user.model';
import { AdminDTO } from '../models/admin.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly API_URL = 'http://localhost:8080';
  private currentUserSubject = new BehaviorSubject<any>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(
    private http: HttpClient,
    private router: Router
  ) {
    this.loadStoredUser();
  }

  private loadStoredUser(): void {
    const token = localStorage.getItem('token');
    if (token) {
      try {
        const decoded = jwtDecode(token);
        this.currentUserSubject.next(decoded);
      } catch (error) {
        this.logout();
      }
    }
  }

  
  registerUser(userData: UserRegistrationDTO): Observable<any> {
    return this.http.post(`${this.API_URL}/user/register`, userData);
  }

  
  loginUser(credentials: LoginDTO): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.API_URL}/user/login`, credentials)
      .pipe(
        tap(response => {
          localStorage.setItem('token', response.token);
          const decoded = jwtDecode(response.token);
          this.currentUserSubject.next(decoded);
        })
      );
  }

  
  registerAdmin(adminData: AdminDTO): Observable<any> {
    return this.http.post(`${this.API_URL}/admin/register`, adminData);
  }

  loginAdmin(credentials: LoginDTO): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.API_URL}/admin/login`, credentials)
      .pipe(
        tap(response => {
          localStorage.setItem('token', response.token);
          const decoded = jwtDecode(response.token);
          this.currentUserSubject.next(decoded);
        })
      );
  }

 
  getUserProfile(): Observable<UserProfileDTO> {
    const headers = this.getAuthHeaders();
    return this.http.get<UserProfileDTO>(`${this.API_URL}/user/details`, { headers });
  }


  updateUserProfile(profileData: UserProfileDTO): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.put(`${this.API_URL}/user/update-profile`, profileData, { headers });
  }


  changePassword(passwordData: ChangePasswordDTO): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.put(`${this.API_URL}/user/change-password`, passwordData, { headers });
  }

 
  deleteAccount(password: string): Observable<any> {
    const headers = this.getAuthHeaders();
    return this.http.delete(`${this.API_URL}/user/delete-account?password=${password}`, { headers });
  }


  logout(): void {
    const token = localStorage.getItem('token');
    if (token) {
      const headers = this.getAuthHeaders();
      this.http.post(`${this.API_URL}/user/logout`, {}, { headers }).subscribe();
    }
    
    localStorage.removeItem('token');
    this.currentUserSubject.next(null);
    this.router.navigate(['/home']);
  }

  // Get Auth Headers
  getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token');
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
  }

 
  isAuthenticated(): boolean {
    const token = localStorage.getItem('token');
    if (!token) return false;
    
    try {
      const decoded: any = jwtDecode(token);
      const currentTime = Date.now() / 1000;
      return decoded.exp > currentTime;
    } catch {
      return false;
    }
  }

 
  isAdmin(): boolean {
    const user = this.currentUserSubject.value;
    return user && (user.roles?.includes('ADMIN') || user.roles?.includes('ROLE_ADMIN'));
  }

  
  getCurrentUser(): any {
    return this.currentUserSubject.value;
  }

  
  getToken(): string | null {
    return localStorage.getItem('token');
  }
}
