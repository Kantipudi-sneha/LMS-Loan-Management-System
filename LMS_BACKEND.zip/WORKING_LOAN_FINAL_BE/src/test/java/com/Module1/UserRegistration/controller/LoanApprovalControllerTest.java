package com.Module1.UserRegistration.controller;

import com.Module1.UserRegistration.DTO.LoanApprovalDTO;
import com.Module1.UserRegistration.model.LoanApproval;
import com.Module1.UserRegistration.service.LoanApprovalService;
import com.Module1.UserRegistration.mapper.LoanApprovalMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LoanApprovalControllerTest {

    @Mock
    private LoanApprovalService loanApprovalService;

    @Mock
    private LoanApprovalMapper loanApprovalMapper;

    @InjectMocks
    private LoanApprovalController loanApprovalController;

    private LoanApproval loanApproval;
    private LoanApprovalDTO loanApprovalDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        loanApproval = new LoanApproval();
        loanApproval.setId(1L);
        loanApproval.setLoanApplicationId(101L);
        loanApproval.setVerificationStatus("APPROVED");
        loanApproval.setApprovalComments("All good");
        loanApproval.setApprovedBy("admin");
        loanApproval.setRiskScore(80);

        loanApprovalDTO = new LoanApprovalDTO();
        loanApprovalDTO.setLoanApplicationId(1L);
        loanApprovalDTO.setLoanApplicationId(101L);
        loanApprovalDTO.setVerificationStatus("APPROVED");
        loanApprovalDTO.setApprovalComments("All good");
        loanApprovalDTO.setApprovedBy("admin");
        loanApprovalDTO.setRiskScore(80);
    }

    @Test
    void testCreateApproval() {
        when(loanApprovalMapper.toEntity(loanApprovalDTO)).thenReturn(loanApproval);
        when(loanApprovalService.saveApproval(loanApproval)).thenReturn(loanApproval);
        when(loanApprovalMapper.toDTO(loanApproval)).thenReturn(loanApprovalDTO);

        LoanApprovalDTO result = loanApprovalController.createApproval(loanApprovalDTO);

        assertNotNull(result);
        assertEquals("APPROVED", result.getVerificationStatus());
        verify(loanApprovalService, times(1)).saveApproval(loanApproval);
    }

    @Test
    void testGetAllApprovals() {
        when(loanApprovalService.getAllApprovals()).thenReturn(Arrays.asList(loanApproval));
        when(loanApprovalMapper.toDTO(loanApproval)).thenReturn(loanApprovalDTO);

        List<LoanApprovalDTO> result = loanApprovalController.getAllApprovals();

        assertEquals(1, result.size());
        assertEquals("APPROVED", result.get(0).getVerificationStatus());
        verify(loanApprovalService, times(1)).getAllApprovals();
    }

    @Test
    void testGetApprovalById_Found() {
        when(loanApprovalService.getApprovalById(1L)).thenReturn(Optional.of(loanApproval));
        when(loanApprovalMapper.toDTO(loanApproval)).thenReturn(loanApprovalDTO);

        Optional<LoanApprovalDTO> result = loanApprovalController.getApprovalById(1L);

        assertTrue(result.isPresent());
        assertEquals(101L, result.get().getLoanApplicationId());
    }

    @Test
    void testGetApprovalById_NotFound() {
        when(loanApprovalService.getApprovalById(2L)).thenReturn(Optional.empty());

        Optional<LoanApprovalDTO> result = loanApprovalController.getApprovalById(2L);

        assertFalse(result.isPresent());
    }

    @Test
    void testDeleteApproval_Success() {
        when(loanApprovalService.deleteApproval(1L)).thenReturn(true);

        String result = loanApprovalController.deleteApproval(1L);

        assertEquals("Approval deleted successfully.", result);
        verify(loanApprovalService, times(1)).deleteApproval(1L);
    }

    @Test
    void testDeleteApproval_Failure() {
        when(loanApprovalService.deleteApproval(2L)).thenReturn(false);

        String result = loanApprovalController.deleteApproval(2L);

        assertEquals("Approval not found.", result);
    }

    @Test
    void testCreateTestApproval() {
        LoanApproval saved = new LoanApproval();
        saved.setId(99L);
        saved.setLoanApplicationId(3L);
        saved.setVerificationStatus("APPROVED");
        saved.setApprovalComments("Test approval for presentation");
        saved.setApprovedBy("admin");
        saved.setRiskScore(75);

        LoanApprovalDTO savedDTO = new LoanApprovalDTO();
        savedDTO.setLoanApplicationId(99L);
        savedDTO.setLoanApplicationId(3L);
        savedDTO.setVerificationStatus("APPROVED");
        savedDTO.setApprovalComments("Test approval for presentation");
        savedDTO.setApprovedBy("admin");
        savedDTO.setRiskScore(75);

        when(loanApprovalService.saveApproval(any(LoanApproval.class))).thenReturn(saved);
        when(loanApprovalMapper.toDTO(saved)).thenReturn(savedDTO);

        LoanApprovalDTO result = loanApprovalController.createTestApproval();

        assertNotNull(result);
        assertEquals(3L, result.getLoanApplicationId());
        assertEquals("APPROVED", result.getVerificationStatus());
    }
}
