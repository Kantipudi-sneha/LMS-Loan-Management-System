package com.Module1.UserRegistration.service;

import com.Module1.UserRegistration.model.LoanDisbursement;
import com.Module1.UserRegistration.repo.LoanDisbursementRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LoanDisbursementServiceTest {

    @Mock
    private LoanDisbursementRepository loanDisbursementRepository;

    @InjectMocks
    private LoanDisbursementService loanDisbursementService;

    private LoanDisbursement disbursement;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        disbursement = new LoanDisbursement();
        disbursement.setId(1L);
        disbursement.setLoanId(100L);
        disbursement.setAmount(50000.0);
        disbursement.setCustomerAccountNumber("1234567890");
        disbursement.setStatus("PENDING");
    }

    @Test
    void testInitiateDisbursement() {
        when(loanDisbursementRepository.save(any(LoanDisbursement.class))).thenReturn(disbursement);

        LoanDisbursement saved = loanDisbursementService.initiateDisbursement(disbursement);

        assertNotNull(saved);
        assertEquals("PENDING", saved.getStatus());
        verify(loanDisbursementRepository, times(1)).save(disbursement);
    }

    @Test
    void testGetAllDisbursements() {
        when(loanDisbursementRepository.findAll()).thenReturn(List.of(disbursement));

        List<LoanDisbursement> result = loanDisbursementService.getAllDisbursements();

        assertEquals(1, result.size());
        assertEquals(disbursement.getId(), result.get(0).getId());
    }

    @Test
    void testGetDisbursementById() {
        when(loanDisbursementRepository.findById(1L)).thenReturn(Optional.of(disbursement));

        Optional<LoanDisbursement> result = loanDisbursementService.getDisbursementById(1L);

        assertTrue(result.isPresent());
        assertEquals(1L, result.get().getId());
    }

    @Test
    void testUpdateDisbursement() {
        LoanDisbursement updated = new LoanDisbursement();
        updated.setAmount(60000.0);
        updated.setLoanId(100L);
        updated.setCustomerAccountNumber("1111111111");
        updated.setReferenceId("REF123");

        when(loanDisbursementRepository.findById(1L)).thenReturn(Optional.of(disbursement));
        when(loanDisbursementRepository.save(any(LoanDisbursement.class))).thenReturn(updated);

        LoanDisbursement result = loanDisbursementService.updateDisbursement(1L, updated);

        assertEquals(60000.0, result.getAmount());
        assertEquals("1111111111", result.getCustomerAccountNumber());
    }

    @Test
    void testUpdateUTR() {
        when(loanDisbursementRepository.findById(1L)).thenReturn(Optional.of(disbursement));
        disbursement.setUtrNumber("UTR123");

        when(loanDisbursementRepository.save(any(LoanDisbursement.class))).thenReturn(disbursement);

        LoanDisbursement result = loanDisbursementService.updateUTR(1L, "UTR123");

        assertEquals("UTR123", result.getUtrNumber());
        assertEquals("DISBURSED", result.getStatus());
    }

    @Test
    void testApproveDisbursement() {
        when(loanDisbursementRepository.findById(1L)).thenReturn(Optional.of(disbursement));
        disbursement.setStatus("APPROVED");
        when(loanDisbursementRepository.save(any(LoanDisbursement.class))).thenReturn(disbursement);

        LoanDisbursement result = loanDisbursementService.approveDisbursement(1L);

        assertEquals("APPROVED", result.getStatus());
    }

    @Test
    void testRejectDisbursement() {
        when(loanDisbursementRepository.findById(1L)).thenReturn(Optional.of(disbursement));
        disbursement.setStatus("REJECTED");
        when(loanDisbursementRepository.save(any(LoanDisbursement.class))).thenReturn(disbursement);

        LoanDisbursement result = loanDisbursementService.rejectDisbursement(1L);

        assertEquals("REJECTED", result.getStatus());
    }

    @Test
    void testMarkDisbursementFailed() {
        when(loanDisbursementRepository.findById(1L)).thenReturn(Optional.of(disbursement));
        disbursement.setStatus("FAILED");
        when(loanDisbursementRepository.save(any(LoanDisbursement.class))).thenReturn(disbursement);

        LoanDisbursement result = loanDisbursementService.markDisbursementFailed(1L);

        assertEquals("FAILED", result.getStatus());
    }

    @Test
    void testCancelDisbursement() {
        when(loanDisbursementRepository.findById(1L)).thenReturn(Optional.of(disbursement));

        boolean result = loanDisbursementService.cancelDisbursement(1L);

        assertTrue(result);
        assertEquals("CANCELLED", disbursement.getStatus());
    }

    @Test
    void testGetDisbursementsByLoanId() {
        when(loanDisbursementRepository.findByLoanId(100L)).thenReturn(List.of(disbursement));

        List<LoanDisbursement> result = loanDisbursementService.getDisbursementsByLoanId(100L);

        assertEquals(1, result.size());
        assertEquals(100L, result.get(0).getLoanId());
    }

    @Test
    void testGetDisbursementsByStatus() {
        when(loanDisbursementRepository.findByStatus("PENDING")).thenReturn(List.of(disbursement));

        List<LoanDisbursement> result = loanDisbursementService.getDisbursementsByStatus("PENDING");

        assertEquals(1, result.size());
        assertEquals("PENDING", result.get(0).getStatus());
    }
}
