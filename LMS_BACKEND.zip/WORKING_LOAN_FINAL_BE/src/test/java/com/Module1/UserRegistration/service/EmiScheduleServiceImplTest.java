package com.Module1.UserRegistration.service;

import com.Module1.UserRegistration.model.EmiSchedule;
import com.Module1.UserRegistration.repo.EmiScheduleRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class EmiScheduleServiceImplTest {

    @Mock
    private EmiScheduleRepository emiScheduleRepository;

    @InjectMocks
    private EmiScheduleServiceImpl emiScheduleService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllSchedule() {
        List<EmiSchedule> schedules = Collections.singletonList(new EmiSchedule());
        when(emiScheduleRepository.findAll()).thenReturn(schedules);

        List<EmiSchedule> result = emiScheduleService.getAllSchedule();

        assertEquals(1, result.size());
        verify(emiScheduleRepository, times(1)).findAll();
    }

    @Test
    void testGetScheduleByLoanId() {
        List<EmiSchedule> schedules = Collections.singletonList(new EmiSchedule());
        when(emiScheduleRepository.findByLoanId("L001")).thenReturn(schedules);

        List<EmiSchedule> result = emiScheduleService.getScheduleByLoanId("L001");

        assertEquals(1, result.size());
        verify(emiScheduleRepository, times(1)).findByLoanId("L001");
    }

    

    

    @Test
    void testUpdateEmiStatus_FoundAndUpdated() {
        String loanId = "L003";
        EmiSchedule schedule = new EmiSchedule();
        schedule.setLoanId(loanId);
        schedule.setEmiNumber(1);
        schedule.setStatus("upcoming");

        when(emiScheduleRepository.findByLoanIdAndEmiNumber(loanId, 1)).thenReturn(Optional.of(schedule));
        when(emiScheduleRepository.save(any(EmiSchedule.class))).thenAnswer(invocation -> invocation.getArgument(0));

        EmiSchedule updated = emiScheduleService.updateEmiStatus(loanId, 1, "paid");

        assertEquals("paid", updated.getStatus());
        verify(emiScheduleRepository, times(1)).save(schedule);
    }

   

   
    @Test
    void testGetScheduleByLoanIdAndEmiNumber() {
        List<EmiSchedule> schedules = Collections.singletonList(new EmiSchedule());
        when(emiScheduleRepository.getScheduleByLoanIdAndEmiNumber("L006", 1)).thenReturn(schedules);

        List<EmiSchedule> result = emiScheduleService.getScheduleByLoanIdAndEmiNumber("L006", 1);

        assertEquals(1, result.size());
        verify(emiScheduleRepository, times(1)).getScheduleByLoanIdAndEmiNumber("L006", 1);
    }
}

