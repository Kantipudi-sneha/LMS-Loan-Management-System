package com.Module1.UserRegistration.service;

import com.Module1.UserRegistration.DTO.PenaltyRequestDTO;
import com.Module1.UserRegistration.model.EmiSchedule;
import com.Module1.UserRegistration.model.Penalty;
import com.Module1.UserRegistration.repo.EmiScheduleRepository;
import com.Module1.UserRegistration.repo.PenaltyRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PenaltyServiceImplTest {

    @Mock
    private PenaltyRepository penaltyRepository;

    @Mock
    private EmiScheduleRepository emiScheduleRepository;

    @InjectMocks
    private PenaltyServiceImpl penaltyService;

    private Penalty penalty;

    @BeforeEach
    void setUp() {
        penalty = new Penalty();
        penalty.setPenaltyId(1);
        penalty.setLoanId("L123");
        penalty.setEmiNumber(1);
        penalty.setPenaltyAmount(BigDecimal.valueOf(100));
        penalty.setReason("Late payment");
        penalty.setCreatedDate(LocalDateTime.now());
    }

    @Test
    void testAddPenalty_ShouldSaveAndReturnPenalty() {
        when(penaltyRepository.save(any(Penalty.class))).thenReturn(penalty);

        Penalty result = penaltyService.addPenalty(penalty);

        assertNotNull(result);
        assertEquals("L123", result.getLoanId());
        verify(penaltyRepository, times(1)).save(penalty);
    }

    @Test
    void testGetPenaltiesByLoanAndEmiNumber() {
        when(penaltyRepository.findByLoanIdAndEmiNumber("L123", 1))
                .thenReturn(Collections.singletonList(penalty));

        List<Penalty> result = penaltyService.getPenaltiesByLoanAndEmiNumber("L123", 1);

        assertEquals(1, result.size());
        assertEquals("L123", result.get(0).getLoanId());
    }

    @Test
    void testGetAllPenalties() {
        when(penaltyRepository.findAll()).thenReturn(Arrays.asList(penalty));

        List<Penalty> result = penaltyService.getAllPenalties();

        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
    }

   

    @Test
    void testCalculateAndAddPenalty_NotOverdue_ShouldThrowException() {
        PenaltyRequestDTO request = new PenaltyRequestDTO();
        request.setLoanId("L123");
        request.setEmiNumber(1);
        request.setReason("Late");

        EmiSchedule emiSchedule = new EmiSchedule();
        emiSchedule.setLoanId("L123");
        emiSchedule.setEmiNumber(1);
        emiSchedule.setDueDate(LocalDate.now().plusDays(1));

        when(emiScheduleRepository.findByLoanIdAndEmiNumber("L123", 1))
                .thenReturn(Optional.of(emiSchedule));

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> penaltyService.calculateAndAddPenalty(request));

        assertEquals("No penalty applicable as EMI is not overdue.", ex.getMessage());
    }

    @Test
    void testCalculateAndAddPenalty_ReasonMissing_ShouldThrowException() {
        PenaltyRequestDTO request = new PenaltyRequestDTO();
        request.setLoanId("L123");
        request.setEmiNumber(1);

        EmiSchedule emiSchedule = new EmiSchedule();
        emiSchedule.setLoanId("L123");
        emiSchedule.setEmiNumber(1);
        emiSchedule.setDueDate(LocalDate.now().minusDays(5));

        when(emiScheduleRepository.findByLoanIdAndEmiNumber("L123", 1))
                .thenReturn(Optional.of(emiSchedule));

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> penaltyService.calculateAndAddPenalty(request));

        assertEquals("Reason is required when penalty is applied.", ex.getMessage());
    }

    @Test
    void testCalculateAndAddPenalty_NewPenalty_ShouldSave() {
        PenaltyRequestDTO request = new PenaltyRequestDTO();
        request.setLoanId("L123");
        request.setEmiNumber(1);
        request.setReason("Late payment");

        EmiSchedule emiSchedule = new EmiSchedule();
        emiSchedule.setLoanId("L123");
        emiSchedule.setEmiNumber(1);
        emiSchedule.setDueDate(LocalDate.now().minusDays(2));

        when(emiScheduleRepository.findByLoanIdAndEmiNumber("L123", 1))
                .thenReturn(Optional.of(emiSchedule));
        when(penaltyRepository.findByLoanIdAndEmiNumber("L123", 1)).thenReturn(Collections.emptyList());
        when(penaltyRepository.save(any(Penalty.class))).thenReturn(penalty);

        Penalty result = penaltyService.calculateAndAddPenalty(request);

        assertNotNull(result);
        assertEquals("L123", result.getLoanId());
        verify(penaltyRepository, times(1)).save(any(Penalty.class));
    }

    @Test
    void testCalculateAndAddPenalty_ExistingPenalty_ShouldUpdate() {
        PenaltyRequestDTO request = new PenaltyRequestDTO();
        request.setLoanId("L123");
        request.setEmiNumber(1);
        request.setReason("Updated reason");

        EmiSchedule emiSchedule = new EmiSchedule();
        emiSchedule.setLoanId("L123");
        emiSchedule.setEmiNumber(1);
        emiSchedule.setDueDate(LocalDate.now().minusDays(3));

        when(emiScheduleRepository.findByLoanIdAndEmiNumber("L123", 1))
                .thenReturn(Optional.of(emiSchedule));
        when(penaltyRepository.findByLoanIdAndEmiNumber("L123", 1))
                .thenReturn(Collections.singletonList(penalty));
        when(penaltyRepository.save(any(Penalty.class))).thenReturn(penalty);

        Penalty result = penaltyService.calculateAndAddPenalty(request);

        assertNotNull(result);
        assertEquals("Updated reason", result.getReason());
        verify(penaltyRepository, times(1)).save(penalty);
    }

    @Test
    void testGetPenaltiesByEmiNumber_Found() {
        when(penaltyRepository.findByEmiNumber(1))
                .thenReturn(Collections.singletonList(penalty));

        Optional<List<Penalty>> result = penaltyService.getPenaltiesByEmiNumber(1);

        assertTrue(result.isPresent());
        assertEquals(1, result.get().size());
    }

    @Test
    void testGetPenaltiesByEmiNumber_NotFound() {
        when(penaltyRepository.findByEmiNumber(99))
                .thenReturn(Collections.emptyList());

        Optional<List<Penalty>> result = penaltyService.getPenaltiesByEmiNumber(99);

        assertFalse(result.isPresent());
    }

    @Test
    void testCleanupInvalidPenalties_ShouldDeleteInvalidOnes() {
        Penalty invalidPenalty = new Penalty();
        invalidPenalty.setLoanId("X999");
        invalidPenalty.setEmiNumber(9);

        when(penaltyRepository.findAll()).thenReturn(Arrays.asList(penalty, invalidPenalty));
        when(emiScheduleRepository.findByLoanIdAndEmiNumber("L123", 1)).thenReturn(Optional.of(new EmiSchedule()));
        when(emiScheduleRepository.findByLoanIdAndEmiNumber("X999", 9)).thenReturn(Optional.empty());

        int deletedCount = penaltyService.cleanupInvalidPenalties();

        assertEquals(1, deletedCount);
        verify(penaltyRepository, times(1)).delete(invalidPenalty);
    }
}
