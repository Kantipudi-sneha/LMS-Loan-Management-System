package com.Module1.UserRegistration.service;

import com.Module1.UserRegistration.DTO.LoanApplicationDTO;
import com.Module1.UserRegistration.model.LoanApplication;
import com.Module1.UserRegistration.model.LoanApproval;
import com.Module1.UserRegistration.repo.LoanApplicationRepository;
import com.Module1.UserRegistration.repo.LoanApprovalRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class LoanApplicationServiceTest {

    @Mock
    private LoanApplicationRepository loanApplicationRepository;

    @Mock
    private LoanApprovalRepository loanApprovalRepository;

    @InjectMocks
    private LoanApplicationService loanApplicationService;

    private LoanApplication loanApp;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        loanApp = LoanApplication.builder()
                .id(1L)
                .applicantName("John Doe")
                .email("john@example.com")
                .loanAmount(new BigDecimal("50000"))
                .loanTenure(12)
                .loanType("PERSONAL")
                .purpose("Medical")
                .status("PENDING")
                .applicationDate(LocalDate.now())
                .build();
    }

    // ✅ Test applyLoan()
    @Test
    void testApplyLoan() {
        LoanApplicationDTO dto = LoanApplicationDTO.builder()
                .id(1L)
                .applicantName("John Doe")
                .email("john@example.com")
                .loanAmount(new BigDecimal("50000"))
                .loanTenure(12)
                .loanType("PERSONAL")
                .purpose("Medical")
                .build();

        when(loanApplicationRepository.save(any(LoanApplication.class))).thenReturn(loanApp);

        LoanApplicationDTO result = loanApplicationService.applyLoan(dto);

        assertNotNull(result);
        assertEquals("John Doe", result.getApplicantName());
        assertEquals("PENDING", result.getStatus()); // Should be set by service
    }

    // ✅ Test getAllLoans()
    @Test
    void testGetAllLoans() {
        when(loanApplicationRepository.findAll()).thenReturn(List.of(loanApp));

        List<LoanApplicationDTO> loans = loanApplicationService.getAllLoans();

        assertEquals(1, loans.size());
        assertEquals("John Doe", loans.get(0).getApplicantName());
    }

    // ✅ Test getLoanById()
    @Test
    void testGetLoanById() {
        when(loanApplicationRepository.findById(1L)).thenReturn(Optional.of(loanApp));

        Optional<LoanApplicationDTO> result = loanApplicationService.getLoanById(1L);

        assertTrue(result.isPresent());
        assertEquals("John Doe", result.get().getApplicantName());
    }

    // ✅ Test updateLoanStatus() without approvalData
    @Test
    void testUpdateLoanStatusWithoutApproval() {
        when(loanApplicationRepository.findById(1L)).thenReturn(Optional.of(loanApp));
        when(loanApplicationRepository.save(any(LoanApplication.class))).thenReturn(loanApp);

        LoanApplicationDTO result = loanApplicationService.updateLoanStatus(1L, "REJECTED");

        assertNotNull(result);
        assertEquals("REJECTED", result.getStatus());
        verify(loanApprovalRepository, never()).save(any()); // No approval record
    }

    // ✅ Test updateLoanStatus() with approvalData (Approved case)
    @Test
    void testUpdateLoanStatusWithApproval() {
        Map<String, Object> approvalData = new HashMap<>();
        approvalData.put("adminId", "123");

        when(loanApplicationRepository.findById(1L)).thenReturn(Optional.of(loanApp));
        when(loanApplicationRepository.save(any(LoanApplication.class))).thenReturn(loanApp);
        when(loanApprovalRepository.save(any(LoanApproval.class))).thenAnswer(i -> i.getArgument(0));

        LoanApplicationDTO result = loanApplicationService.updateLoanStatus(1L, "APPROVED", approvalData);

        assertNotNull(result);
        assertEquals("APPROVED", result.getStatus());
        verify(loanApprovalRepository, times(1)).save(any(LoanApproval.class)); // Approval record created
    }

    // ✅ Test deleteLoan()
    @Test
    void testDeleteLoan() {
        when(loanApplicationRepository.existsById(1L)).thenReturn(true);

        boolean result = loanApplicationService.deleteLoan(1L);

        assertTrue(result);
        verify(loanApplicationRepository, times(1)).deleteById(1L);
    }

    // ✅ Test deleteLoan() - Loan not found
    
}
