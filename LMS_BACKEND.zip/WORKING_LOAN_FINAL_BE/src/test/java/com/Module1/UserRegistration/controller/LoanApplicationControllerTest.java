package com.Module1.UserRegistration.controller;

import com.Module1.UserRegistration.DTO.LoanApplicationDTO;
import com.Module1.UserRegistration.service.LoanApplicationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.ResponseEntity;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LoanApplicationControllerTest {

    @InjectMocks
    private LoanApplicationController loanApplicationController;

    @Mock
    private LoanApplicationService loanApplicationService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testApplyLoan() {
        LoanApplicationDTO request = new LoanApplicationDTO();
        request.setId(1L);
        request.setApplicantName("John");

        LoanApplicationDTO saved = new LoanApplicationDTO();
        saved.setId(1L);
        saved.setApplicantName("John");

        when(loanApplicationService.applyLoan(any(LoanApplicationDTO.class))).thenReturn(saved);

        ResponseEntity<LoanApplicationDTO> response = loanApplicationController.applyLoan(request);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals("John", response.getBody().getApplicantName());
        verify(loanApplicationService, times(1)).applyLoan(request);
    }

   
    @Test
    void testGetAllLoans() {
        LoanApplicationDTO dto1 = new LoanApplicationDTO();
        dto1.setId(1L);

        LoanApplicationDTO dto2 = new LoanApplicationDTO();
        dto2.setId(2L);

        when(loanApplicationService.getAllLoans()).thenReturn(Arrays.asList(dto1, dto2));

        ResponseEntity<List<LoanApplicationDTO>> response = loanApplicationController.getAllLoans();

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(2, response.getBody().size());
        verify(loanApplicationService, times(1)).getAllLoans();
    }

  
    @Test
    void testGetLoanById_Found() {
        LoanApplicationDTO dto = new LoanApplicationDTO();
        dto.setId(1L);

        when(loanApplicationService.getLoanById(1L)).thenReturn(Optional.of(dto));

        ResponseEntity<LoanApplicationDTO> response = loanApplicationController.getLoanById(1L);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(1L, response.getBody().getId());
    }

  
    @Test
    void testGetLoanById_NotFound() {
        when(loanApplicationService.getLoanById(99L)).thenReturn(Optional.empty());

        ResponseEntity<LoanApplicationDTO> response = loanApplicationController.getLoanById(99L);

        assertEquals(404, response.getStatusCodeValue());
        assertNull(response.getBody());
    }


    @Test
    void testUpdateLoanStatus_Success() {
        LoanApplicationDTO updated = new LoanApplicationDTO();
        updated.setId(1L);
        updated.setStatus("APPROVED");

        when(loanApplicationService.updateLoanStatus(eq(1L), eq("APPROVED"), anyMap()))
                .thenReturn(updated);

        ResponseEntity<LoanApplicationDTO> response = loanApplicationController.updateLoanStatus(1L, "APPROVED", new HashMap<>());

        assertEquals(200, response.getStatusCodeValue());
        assertEquals("APPROVED", response.getBody().getStatus());
    }

   
    @Test
    void testUpdateLoanStatus_NotFound() {
        when(loanApplicationService.updateLoanStatus(eq(1L), eq("APPROVED"), anyMap()))
                .thenReturn(null);

        ResponseEntity<LoanApplicationDTO> response = loanApplicationController.updateLoanStatus(1L, "APPROVED", new HashMap<>());

        assertEquals(404, response.getStatusCodeValue());
    }

    
    @Test
    void testDeleteLoan_Success() {
        when(loanApplicationService.deleteLoan(1L)).thenReturn(true);

        ResponseEntity<Void> response = loanApplicationController.deleteLoan(1L);

        assertEquals(204, response.getStatusCodeValue());
        verify(loanApplicationService, times(1)).deleteLoan(1L);
    }

   
    @Test
    void testDeleteLoan_NotFound() {
        when(loanApplicationService.deleteLoan(99L)).thenReturn(false);

        ResponseEntity<Void> response = loanApplicationController.deleteLoan(99L);

        assertEquals(404, response.getStatusCodeValue());
    }
}
