package com.Module1.UserRegistration.controller;

import com.Module1.UserRegistration.DTO.PenaltyRequestDTO;
import com.Module1.UserRegistration.model.Penalty;
import com.Module1.UserRegistration.service.PenaltyService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class PenaltyControllerTest {

    private MockMvc mockMvc;
    private PenaltyService penaltyService;
    private ObjectMapper objectMapper;


    @BeforeEach
    void setup() {
        penaltyService = mock(PenaltyService.class);
        PenaltyController controller = new PenaltyController();

        // Inject mock into private field
        ReflectionTestUtils.setField(controller, "penaltyService", penaltyService);

        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
        objectMapper = new ObjectMapper();
    }


    @Test
    void testAddPenalty() throws Exception {
        PenaltyRequestDTO request = new PenaltyRequestDTO(null, "L1", 1, null, "Late payment", null);

        Penalty savedEntity = new Penalty(1, "L1", 1,
                new BigDecimal("100.00"), "Late payment", LocalDateTime.now());

        when(penaltyService.addPenalty(any(Penalty.class))).thenReturn(savedEntity);

        mockMvc.perform(post("/api/penalties/add")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.penaltyId").value(1))
                .andExpect(jsonPath("$.loanId").value("L1"))
                .andExpect(jsonPath("$.emiNumber").value(1))
                .andExpect(jsonPath("$.reason").value("Late payment"));
    }

    @Test
    void testGetAllPenalties() throws Exception {
        Penalty savedEntity = new Penalty(1, "L1", 1,
                new BigDecimal("100.00"), "Late payment", LocalDateTime.now());

        when(penaltyService.getAllPenalties()).thenReturn(Collections.singletonList(savedEntity));

        mockMvc.perform(get("/api/penalties"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].loanId").value("L1"))
                .andExpect(jsonPath("$[0].penaltyAmount").value(100.00));
    }

    @Test
    void testCleanupInvalidPenalties() throws Exception {
        when(penaltyService.cleanupInvalidPenalties()).thenReturn(2);

        mockMvc.perform(delete("/api/penalties/cleanup"))
                .andExpect(status().isOk())
                .andExpect(content().string("Deleted 2 penalties with invalid loan IDs"));
    }

    @Test
    void testGetPenaltiesByLoanAndEmi() throws Exception {
        Penalty savedEntity = new Penalty(1, "L1", 1,
                new BigDecimal("50.00"), "Late fee", LocalDateTime.now());

        when(penaltyService.getPenaltiesByLoanAndEmiNumber("L1", 1))
                .thenReturn(Collections.singletonList(savedEntity));

        mockMvc.perform(get("/api/penalties/loan/L1/emi/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].penaltyAmount").value(50.00))
                .andExpect(jsonPath("$[0].reason").value("Late fee"));
    }

    @Test
    void testCalculateAndAddPenalty() throws Exception {
        PenaltyRequestDTO request = new PenaltyRequestDTO(null, "L2", 2, null, "Missed payment", null);

        Penalty savedEntity = new Penalty(10, "L2", 2,
                new BigDecimal("150.00"), "Missed payment", LocalDateTime.now());

        when(penaltyService.calculateAndAddPenalty(any(PenaltyRequestDTO.class))).thenReturn(savedEntity);

        mockMvc.perform(post("/api/penalties/calculate-add")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.penaltyId").value(10))
                .andExpect(jsonPath("$.penaltyAmount").value(150.00));
    }
}
