package com.Module1.UserRegistration.controller;

import com.Module1.UserRegistration.model.EmiSchedule;
import com.Module1.UserRegistration.service.EmiScheduleService;
import com.Module1.UserRegistration.repo.EmiScheduleRepository;
import com.Module1.UserRegistration.DTO.UpdateEmiStatusRequestDTO;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class EmiScheduleControllerTest {

    @InjectMocks
    private EmiScheduleController emiScheduleController;

    @Mock
    private EmiScheduleService emiScheduleService;

    @Mock
    private EmiScheduleRepository emiScheduleRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // ✅ Test getAllSchedules
    @Test
    void testGetAllSchedules() {
        List<EmiSchedule> schedules = List.of(new EmiSchedule(), new EmiSchedule());
        when(emiScheduleService.getAllSchedule()).thenReturn(schedules);

        List<EmiSchedule> result = emiScheduleController.getAllSchedules();

        assertEquals(2, result.size());
        verify(emiScheduleService, times(1)).getAllSchedule();
    }

    // ✅ Test generateSchedule (success)
    @Test
    void testGenerateSchedule_Success() {
        Map<String, Object> request = new HashMap<>();
        request.put("loanId", "1");
        request.put("principalAmount", 10000);
        request.put("interestRate", 10);
        request.put("tenure", 12);
        request.put("startDate", LocalDate.now().toString());

        List<EmiSchedule> mockSchedules = List.of(new EmiSchedule());
        when(emiScheduleService.generateSchedule(anyString(), any(BigDecimal.class), any(BigDecimal.class), anyInt(), any(LocalDate.class)))
                .thenReturn(mockSchedules);
        when(emiScheduleService.getScheduleByLoanId("1")).thenReturn(mockSchedules);

        ResponseEntity<?> response = emiScheduleController.generateSchedule(request);

        assertEquals(200, response.getStatusCodeValue());
        assertTrue(((List<?>) response.getBody()).size() > 0);

        verify(emiScheduleService, times(1)).generateSchedule(anyString(), any(), any(), anyInt(), any(LocalDate.class));
    }

    // ✅ Test generateSchedule (error case)
    @Test
    void testGenerateSchedule_Error() {
        Map<String, Object> request = new HashMap<>();
        request.put("loanId", "1");
        request.put("principalAmount", "INVALID"); // will cause error

        ResponseEntity<?> response = emiScheduleController.generateSchedule(request);

        assertEquals(500, response.getStatusCodeValue());
        assertTrue(((Map<?, ?>) response.getBody()).containsKey("error"));
    }

    // ✅ Test testGenerateSchedule()
    @Test
    void testTestGenerateSchedule() {
        List<EmiSchedule> mockSchedules = List.of(new EmiSchedule());
        when(emiScheduleService.generateSchedule(anyString(), any(), any(), anyInt(), any(LocalDate.class)))
                .thenReturn(mockSchedules);

        ResponseEntity<?> response = emiScheduleController.testGenerateSchedule();

        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
    }

    // ✅ Test getScheduleByLoanId
    @Test
    void testGetScheduleByLoanId() {
        List<EmiSchedule> schedules = List.of(new EmiSchedule());
        when(emiScheduleService.getScheduleByLoanId("123")).thenReturn(schedules);

        List<EmiSchedule> result = emiScheduleController.getScheduleByLoanId("123");

        assertEquals(1, result.size());
        verify(emiScheduleService).getScheduleByLoanId("123");
    }

    // ✅ Test getEmiByLoanAndEmiNumber
    @Test
    void testGetEmiByLoanAndEmiNumber() {
        List<EmiSchedule> schedules = List.of(new EmiSchedule());
        when(emiScheduleService.getScheduleByLoanIdAndEmiNumber("123", 1)).thenReturn(schedules);

        List<EmiSchedule> result = emiScheduleController.getEmiByLoanAndEmiNumber("123", 1);

        assertEquals(1, result.size());
        verify(emiScheduleService).getScheduleByLoanIdAndEmiNumber("123", 1);
    }

    // ✅ Test updateEmiStatus
    @Test
    void testUpdateEmiStatus() {
        UpdateEmiStatusRequestDTO request = new UpdateEmiStatusRequestDTO();
        request.setLoanId("123");
        request.setEmiNumber(1);
        request.setStatus("PAID");

        EmiSchedule updated = new EmiSchedule();
        updated.setLoanId("123");
        when(emiScheduleService.updateEmiStatus("123", 1, "PAID")).thenReturn(updated);

        ResponseEntity<EmiSchedule> response = emiScheduleController.updateEmiStatus(request);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals("123", response.getBody().getLoanId());
        verify(emiScheduleService).updateEmiStatus("123", 1, "PAID");
    }
}
