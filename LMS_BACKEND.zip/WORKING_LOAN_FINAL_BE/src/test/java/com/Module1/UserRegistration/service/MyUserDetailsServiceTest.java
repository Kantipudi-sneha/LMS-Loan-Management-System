package com.Module1.UserRegistration.service;

import com.Module1.UserRegistration.model.Admin;
import com.Module1.UserRegistration.model.User;
import com.Module1.UserRegistration.model.UserPrincipal;
import com.Module1.UserRegistration.model.UserRole;
import com.Module1.UserRegistration.repo.AdminRepository;
import com.Module1.UserRegistration.repo.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class MyUserDetailsServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private AdminRepository adminRepository;

    @InjectMocks
    private MyUserDetailsService myUserDetailsService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // ✅ Case 1: User found in UserRepository
    @Test
    void testLoadUserByUsername_UserFound() {
        User user = new User();
        user.setUsername("john");
        user.setPassword("password123");
        user.setRole(UserRole.USER);   // IMPORTANT: to avoid NPE in UserPrincipal

        when(userRepository.findByUsername("john")).thenReturn(Optional.of(user));

        UserDetails result = myUserDetailsService.loadUserByUsername("john");

        assertNotNull(result);
        assertTrue(result instanceof UserPrincipal);
        assertEquals("john", result.getUsername());
        assertEquals("password123", result.getPassword());
        assertTrue(result.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_USER")));

        verify(userRepository, times(1)).findByUsername("john");
        verifyNoInteractions(adminRepository);
    }

    // ✅ Case 2: User not found, but Admin found
    @Test
    void testLoadUserByUsername_AdminFound() {
        Admin admin = new Admin();
        admin.setUsername("admin1");
        admin.setPassword("securepass");
        admin.setRole(UserRole.ADMIN);

        when(userRepository.findByUsername("admin1")).thenReturn(Optional.empty());
        when(adminRepository.findByUsername("admin1")).thenReturn(Optional.of(admin));

        UserDetails result = myUserDetailsService.loadUserByUsername("admin1");

        assertNotNull(result);
        assertTrue(result instanceof UserPrincipal);
        assertEquals("admin1", result.getUsername());
        assertEquals("securepass", result.getPassword());
        assertTrue(result.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_ADMIN")));

        verify(userRepository, times(1)).findByUsername("admin1");
        verify(adminRepository, times(1)).findByUsername("admin1");
    }

   
}
