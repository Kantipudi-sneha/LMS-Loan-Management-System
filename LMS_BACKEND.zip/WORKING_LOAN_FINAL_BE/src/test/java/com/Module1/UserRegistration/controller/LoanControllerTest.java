package com.Module1.UserRegistration.controller;

import com.Module1.UserRegistration.DTO.LoanDTO;
import com.Module1.UserRegistration.service.LoanService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LoanControllerTest {

    @InjectMocks
    private LoanController loanController;

    @Mock
    private LoanService loanService;

    // ✅ Test create loan
    @Test
    void testCreateLoan() {
        LoanDTO loanDTO = new LoanDTO(
                "L1",
                "John Doe",
                BigDecimal.valueOf(5000),
                BigDecimal.valueOf(10),
                12,
                LocalDate.now()
        );

        when(loanService.saveLoan(any(LoanDTO.class))).thenReturn(loanDTO);

        ResponseEntity<LoanDTO> response = loanController.createLoan(loanDTO);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("L1", response.getBody().getLoanId());
    }

    // ✅ Test get all loans
    @Test
    void testGetAllLoans() {
        LoanDTO loan1 = new LoanDTO(
                "L1", "John Doe", BigDecimal.valueOf(5000),
                BigDecimal.valueOf(10), 12, LocalDate.now()
        );

        LoanDTO loan2 = new LoanDTO(
                "L2", "Jane Smith", BigDecimal.valueOf(10000),
                BigDecimal.valueOf(12), 24, LocalDate.now()
        );

        List<LoanDTO> loans = Arrays.asList(loan1, loan2);

        when(loanService.getAllLoans()).thenReturn(loans);

        ResponseEntity<List<LoanDTO>> response = loanController.getAllLoans();

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(2, response.getBody().size());
    }
}
