package com.Module1.UserRegistration.service;

import com.Module1.UserRegistration.DTO.LoanDTO;
import com.Module1.UserRegistration.model.Loan;
import com.Module1.UserRegistration.repo.LoanRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LoanServiceImplTest {

    @Mock
    private LoanRepository loanRepository;

    @InjectMocks
    private LoanServiceImpl loanService;

    // ✅ Test saveLoan()
    @Test
    void testSaveLoan() {
        LoanDTO dto = new LoanDTO("L1", "Alice",
                BigDecimal.valueOf(10000),
                BigDecimal.valueOf(5.5),
                12,
                LocalDate.now());

        Loan entity = new Loan("L1", "Alice",
                BigDecimal.valueOf(10000),
                BigDecimal.valueOf(5.5),
                12,
                LocalDate.now());

        when(loanRepository.save(any(Loan.class))).thenReturn(entity);

        LoanDTO result = loanService.saveLoan(dto);

        assertNotNull(result);
        assertEquals("L1", result.getLoanId());
        assertEquals("Alice", result.getCustomerName());
        verify(loanRepository, times(1)).save(any(Loan.class));
    }

    // ✅ Test getLoanById() - found
    @Test
    void testGetLoanByIdFound() {
        Loan entity = new Loan("L1", "Bob",
                BigDecimal.valueOf(20000),
                BigDecimal.valueOf(6.0),
                24,
                LocalDate.now());

        when(loanRepository.findById("L1")).thenReturn(Optional.of(entity));

        LoanDTO result = loanService.getLoanById("L1");

        assertNotNull(result);
        assertEquals("Bob", result.getCustomerName());
    }

    // ✅ Test getLoanById() - not found
   

    // ✅ Test getAllLoans()
    @Test
    void testGetAllLoans() {
        Loan loan1 = new Loan("L1", "Alice", BigDecimal.valueOf(10000), BigDecimal.valueOf(5.5), 12, LocalDate.now());
        Loan loan2 = new Loan("L2", "Bob", BigDecimal.valueOf(15000), BigDecimal.valueOf(6.0), 24, LocalDate.now());

        when(loanRepository.findAll()).thenReturn(Arrays.asList(loan1, loan2));

        List<LoanDTO> result = loanService.getAllLoans();

        assertEquals(2, result.size());
        assertEquals("Alice", result.get(0).getCustomerName());
        assertEquals("Bob", result.get(1).getCustomerName());
    }

    // ✅ Test getLoansByCustomerName()
    @Test
    void testGetLoansByCustomerName() {
        Loan loan = new Loan("L3", "Charlie",
                BigDecimal.valueOf(5000),
                BigDecimal.valueOf(7.0),
                6,
                LocalDate.now());

        when(loanRepository.findByCustomerName("Charlie")).thenReturn(List.of(loan));

        List<LoanDTO> result = loanService.getLoansByCustomerName("Charlie");

        assertEquals(1, result.size());
        assertEquals("Charlie", result.getFirst().getCustomerName());
    }
}
