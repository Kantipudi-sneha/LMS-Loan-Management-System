package com.Module1.UserRegistration.controller;

import com.Module1.UserRegistration.DTO.LoanDisbursementDTO;
import com.Module1.UserRegistration.model.LoanDisbursement;
import com.Module1.UserRegistration.service.LoanDisbursementService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LoanDisbursementControllerTest {

    @Mock
    private LoanDisbursementService loanDisbursementService;

    @InjectMocks
    private LoanDisbursementController loanDisbursementController;

    private LoanDisbursement entity;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        entity = new LoanDisbursement();
        entity.setId(1L);
        entity.setLoanId(123L); // ✅ use Long, not String
        entity.setAmount(50000.0); // ✅ use Double, not BigDecimal
        entity.setStatus("PENDING");
        entity.setUtrNumber("UTR12345");
        entity.setCustomerAccountNumber("1234567890");
        entity.setReferenceId("REF001");
        entity.setDisbursementMethod("NEFT");
    }


    @Test
    void testInitiateDisbursement() {
        when(loanDisbursementService.initiateDisbursement(any())).thenReturn(entity);

        LoanDisbursementDTO dto = new LoanDisbursementDTO();
        dto.setLoanId(123L); // ✅ Long
        dto.setAmount(50000.0); // ✅ Double


        ResponseEntity<LoanDisbursementDTO> response = loanDisbursementController.initiateDisbursement(dto);

        assertEquals(200, response.getStatusCode().value());
        assertEquals(123L, response.getBody().getLoanId());
        verify(loanDisbursementService, times(1)).initiateDisbursement(any());
    }

    @Test
    void testGetAllDisbursements() {
        when(loanDisbursementService.getAllDisbursements()).thenReturn(Arrays.asList(entity));

        ResponseEntity<?> response = loanDisbursementController.getAllDisbursements();

        assertEquals(200, response.getStatusCodeValue());
        List<?> list = (List<?>) response.getBody();
        assertEquals(1, list.size());
    }

    @Test
    void testGetDisbursementById_Found() {
        when(loanDisbursementService.getDisbursementById(1L)).thenReturn(Optional.of(entity));

        ResponseEntity<LoanDisbursementDTO> response = loanDisbursementController.getDisbursementById(1L);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals("PENDING", response.getBody().getStatus());
    }

    @Test
    void testGetDisbursementById_NotFound() {
        when(loanDisbursementService.getDisbursementById(2L)).thenReturn(Optional.empty());

        ResponseEntity<LoanDisbursementDTO> response = loanDisbursementController.getDisbursementById(2L);

        assertEquals(404, response.getStatusCodeValue());
        assertNull(response.getBody());
    }

    @Test
    void testApproveDisbursement() {
        entity.setStatus("APPROVED");
        when(loanDisbursementService.approveDisbursement(1L)).thenReturn(entity);

        ResponseEntity<LoanDisbursementDTO> response = loanDisbursementController.approveDisbursement(1L);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals("APPROVED", response.getBody().getStatus());
    }

    @Test
    void testCancelDisbursement() {
        when(loanDisbursementService.cancelDisbursement(1L)).thenReturn(true);

        ResponseEntity<Boolean> response = loanDisbursementController.cancelDisbursement(1L);

        assertEquals(200, response.getStatusCodeValue());
        assertTrue(response.getBody());
    }
}
