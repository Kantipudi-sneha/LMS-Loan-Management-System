package com.Module1.UserRegistration.service;

import com.Module1.UserRegistration.DTO.ChangePasswordDTO;
import com.Module1.UserRegistration.DTO.UserProfileDTO;
import com.Module1.UserRegistration.DTO.UserRegistrationDTO;
import com.Module1.UserRegistration.model.User;
import com.Module1.UserRegistration.repo.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private JwtService jwtService;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private UserService userService;

    private User user;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        user = User.builder()
                .username("john")
                .email("john@example.com")
                .mobileNumber("9876543210")
                .dateOfBirth(LocalDate.of(1990, 1, 1))
                .password("encodedPassword")
                .aadharNumber("123456789012")
                .panNumber("ABCDE1234F")
                .address("Some address")
                .occupation("Engineer")
                .employerName("ABC Corp")
                .monthlyIncome(new BigDecimal("50000"))
                .bankName("HDFC")
                .accountNumber("1234567890")
                .ifscCode("HDFC000123")
                .isActive(true)
                .build();
    }

    @Test
    void testRegisterUser_Success() {
        UserRegistrationDTO dto = new UserRegistrationDTO();
        dto.setUsername("john");
        dto.setEmail("john@example.com");
        dto.setPassword("password");

        when(passwordEncoder.encode("password")).thenReturn("encodedPassword");
        when(userRepository.save(any(User.class))).thenReturn(user);

        ResponseEntity<?> response = userService.registerUser(dto);

        assertEquals(200, response.getStatusCodeValue());
        assertTrue(((Map<?, ?>) response.getBody()).get("message").toString().contains("User registered successfully"));
    }

    @Test
    void testUpdateUserProfile_Success() {
        UserProfileDTO updatedProfile = UserProfileDTO.builder()
                .email("new@example.com")
                .mobileNumber("9999999999")
                .address("New Address")
                .build();

        when(jwtService.extractUserName("validToken")).thenReturn("john");
        when(userRepository.findByUsername("john")).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenReturn(user);

        ResponseEntity<?> response = userService.updateUserProfile("Bearer validToken", updatedProfile);

        assertEquals(200, response.getStatusCodeValue());
        UserProfileDTO body = (UserProfileDTO) response.getBody();
        assertEquals("new@example.com", body.getEmail());
    }

    @Test
    void testUpdateUserProfile_UserNotFound() {
        when(jwtService.extractUserName("validToken")).thenReturn("john");
        when(userRepository.findByUsername("john")).thenReturn(Optional.empty());

        ResponseEntity<?> response = userService.updateUserProfile("Bearer validToken", new UserProfileDTO());

        assertEquals(404, response.getStatusCodeValue());
        assertEquals("User not found", response.getBody());
    }

    @Test
    void testGetUserProfile_Success() {
        when(jwtService.extractUserName("validToken")).thenReturn("john");
        when(userRepository.findByUsername("john")).thenReturn(Optional.of(user));

        UserProfileDTO profile = userService.getUserProfile("Bearer validToken");

        assertNotNull(profile);
        assertEquals("john", profile.getUsername());
        assertEquals("john@example.com", profile.getEmail());
    }

    @Test
    void testGetUserProfile_UserNotFound() {
        when(jwtService.extractUserName("validToken")).thenReturn("john");
        when(userRepository.findByUsername("john")).thenReturn(Optional.empty());

        UserProfileDTO profile = userService.getUserProfile("Bearer validToken");

        assertNull(profile);
    }

    @Test
    void testChangePassword_Success() {
        ChangePasswordDTO changePasswordDTO = new ChangePasswordDTO();
        changePasswordDTO.setCurrentPassword("oldPass");
        changePasswordDTO.setNewPassword("newPass");

        when(jwtService.extractUserName("validToken")).thenReturn("john");
        when(userRepository.findByUsername("john")).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("oldPass", "encodedPassword")).thenReturn(true);
        when(passwordEncoder.encode("newPass")).thenReturn("encodedNewPass");

        ResponseEntity<?> response = userService.changePassword("Bearer validToken", changePasswordDTO);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Password changed successfully", ((Map<?, ?>) response.getBody()).get("message"));
    }

    @Test
    void testChangePassword_IncorrectCurrentPassword() {
        ChangePasswordDTO changePasswordDTO = new ChangePasswordDTO();
        changePasswordDTO.setCurrentPassword("wrongPass");
        changePasswordDTO.setNewPassword("newPass");

        when(jwtService.extractUserName("validToken")).thenReturn("john");
        when(userRepository.findByUsername("john")).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("wrongPass", "encodedPassword")).thenReturn(false);

        ResponseEntity<?> response = userService.changePassword("Bearer validToken", changePasswordDTO);

        assertEquals(400, response.getStatusCodeValue());
        assertEquals("Current password is incorrect", ((Map<?, ?>) response.getBody()).get("message"));
    }

    @Test
    void testDeleteUserAccount_Success() {
        when(jwtService.extractUserName("validToken")).thenReturn("john");
        when(userRepository.findByUsername("john")).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("userPass", "encodedPassword")).thenReturn(true);

        ResponseEntity<?> response = userService.deleteUserAccount("Bearer validToken", "userPass");

        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Account deleted successfully", ((Map<?, ?>) response.getBody()).get("message"));
        verify(userRepository, times(1)).delete(user);
    }

    @Test
    void testDeleteUserAccount_WrongPassword() {
        when(jwtService.extractUserName("validToken")).thenReturn("john");
        when(userRepository.findByUsername("john")).thenReturn(Optional.of(user));
        when(passwordEncoder.matches("wrongPass", "encodedPassword")).thenReturn(false);

        ResponseEntity<?> response = userService.deleteUserAccount("Bearer validToken", "wrongPass");

        assertEquals(400, response.getStatusCodeValue());
        assertEquals("Password is incorrect", ((Map<?, ?>) response.getBody()).get("message"));
        verify(userRepository, never()).delete(any());
    }
}
