package com.Module1.UserRegistration.service;

import com.Module1.UserRegistration.model.LoanApproval;
import com.Module1.UserRegistration.repo.LoanApprovalRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LoanApprovalServiceTest {

    @InjectMocks
    private LoanApprovalService loanApprovalService;

    @Mock
    private LoanApprovalRepository loanApprovalRepository;

    // ✅ Test: saveApproval()
    @Test
    void testSaveApprovalSetsApprovalDateIfNull() {
        LoanApproval approval = new LoanApproval();
        approval.setLoanApplicationId(1L);
        approval.setApprovalDate(null); // should be auto-set

        LoanApproval savedApproval = new LoanApproval();
        savedApproval.setId(1L);
        savedApproval.setLoanApplicationId(1L);
        savedApproval.setApprovalDate(LocalDate.now());

        when(loanApprovalRepository.save(any(LoanApproval.class))).thenReturn(savedApproval);

        LoanApproval result = loanApprovalService.saveApproval(approval);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertNotNull(result.getApprovalDate());
    }

    @Test
    void testGetAllApprovals() {
        LoanApproval approval1 = new LoanApproval();
        approval1.setId(1L);
        approval1.setLoanApplicationId(1L);

        LoanApproval approval2 = new LoanApproval();
        approval2.setId(2L);
        approval2.setLoanApplicationId(2L); // ✅ fix

        List<LoanApproval> approvals = Arrays.asList(approval1, approval2);

        when(loanApprovalRepository.findAll()).thenReturn(approvals);

        List<LoanApproval> result = loanApprovalService.getAllApprovals();

        assertEquals(2, result.size());
        assertEquals(2L, result.get(1).getLoanApplicationId()); // ✅ now it passes
    }


    // ✅ Test: getApprovalById()
    @Test
    void testGetApprovalById() {
        LoanApproval approval = new LoanApproval();
        approval.setId(1L);
        approval.setLoanApplicationId(1L);

        when(loanApprovalRepository.findById(1L)).thenReturn(Optional.of(approval));

        Optional<LoanApproval> result = loanApprovalService.getApprovalById(1L);

        assertTrue(result.isPresent());
        assertEquals(1L, result.get().getLoanApplicationId());
    }

    // ✅ Test: deleteApproval() - exists
    @Test
    void testDeleteApprovalExists() {
        when(loanApprovalRepository.existsById(1L)).thenReturn(true);

        boolean result = loanApprovalService.deleteApproval(1L);

        assertTrue(result);
        verify(loanApprovalRepository, times(1)).deleteById(1L);
    }

    // ✅ Test: deleteApproval() - does not exist
   
}
