package com.Module1.UserRegistration.service;

import com.Module1.UserRegistration.DTO.PaymentRequestDTO;
import com.Module1.UserRegistration.DTO.PaymentResponseDTO;
import com.Module1.UserRegistration.exception.CustomException;
import com.Module1.UserRegistration.model.EmiSchedule;
import com.Module1.UserRegistration.model.Payment;
import com.Module1.UserRegistration.model.Penalty;
import com.Module1.UserRegistration.repo.EmiScheduleRepository;
import com.Module1.UserRegistration.repo.LoanRepository;
import com.Module1.UserRegistration.repo.PaymentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PaymentServiceImplTest {

    @InjectMocks
    private PaymentServiceImpl paymentService;

    @Mock
    private PaymentRepository paymentRepository;
    @Mock
    private LoanRepository loanRepository;
    @Mock
    private EmiScheduleRepository emiScheduleRepository;
    @Mock
    private PenaltyService penaltyService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // === saveOrUpdatePayment ===
    @Test
    void testSaveOrUpdatePayment_Success_NoOverdue() {
        PaymentRequestDTO request = new PaymentRequestDTO();
        request.setLoanId("LN001");
        request.setEmiNumber(1);
        request.setPaymentDate(LocalDate.of(2025, 8, 25));
        request.setPaymentMethod("UPI");
        request.setTransactionId("TXN123");

        EmiSchedule emi = new EmiSchedule();
        emi.setLoanId("LN001");
        emi.setEmiNumber(1);
        emi.setDueDate(LocalDate.of(2025, 8, 25));
        emi.setEmiAmount(BigDecimal.valueOf(1000));

        when(emiScheduleRepository.findByLoanIdAndEmiNumber("LN001", 1))
                .thenReturn(Optional.of(emi));

        Payment saved = new Payment();
        saved.setPaymentId(1); // int
        saved.setLoanId("LN001");
        saved.setEmiNumber(1);
        saved.setPaymentAmount(BigDecimal.valueOf(1000));
        saved.setPaymentStatus("SUCCESS");
        saved.setDaysOverdue(0);
        saved.setTotalDue(BigDecimal.valueOf(1000));

        when(paymentRepository.save(any(Payment.class))).thenReturn(saved);

        PaymentResponseDTO result = paymentService.saveOrUpdatePayment(request);

        assertEquals("LN001", result.getLoanId());
        assertEquals("SUCCESS", result.getPaymentStatus());
        assertEquals(BigDecimal.ZERO, result.getPenaltyAmount());
        verify(paymentRepository, times(1)).save(any(Payment.class));
        verify(emiScheduleRepository, times(1)).save(any(EmiSchedule.class));
        verifyNoInteractions(penaltyService);
    }

    @Test
    void testSaveOrUpdatePayment_WithOverdue_AddsPenalty() {
        PaymentRequestDTO request = new PaymentRequestDTO();
        request.setLoanId("LN002");
        request.setEmiNumber(2);
        request.setPaymentDate(LocalDate.of(2025, 8, 30)); // 5 days late
        request.setPaymentMethod("CARD");
        request.setTransactionId("TXN456");

        EmiSchedule emi = new EmiSchedule();
        emi.setLoanId("LN002");
        emi.setEmiNumber(2);
        emi.setDueDate(LocalDate.of(2025, 8, 25));
        emi.setEmiAmount(BigDecimal.valueOf(2000));

        when(emiScheduleRepository.findByLoanIdAndEmiNumber("LN002", 2))
                .thenReturn(Optional.of(emi));

        when(penaltyService.getPenaltiesByLoanAndEmiNumber("LN002", 2)).thenReturn(Collections.emptyList());

        Payment saved = new Payment();
        saved.setPaymentId(2);
        saved.setLoanId("LN002");
        saved.setEmiNumber(2);
        saved.setPaymentStatus("SUCCESS");
        saved.setDaysOverdue(5);
        saved.setTotalDue(BigDecimal.valueOf(2250)); // 2000 + 250 penalty

        when(paymentRepository.save(any(Payment.class))).thenReturn(saved);

        PaymentResponseDTO result = paymentService.saveOrUpdatePayment(request);

        assertEquals("LN002", result.getLoanId());
        assertEquals(5, result.getDaysOverdue());
        assertEquals(BigDecimal.valueOf(250), result.getPenaltyAmount());
        verify(penaltyService, times(1)).addPenalty(any(Penalty.class));
    }

    @Test
    void testSaveOrUpdatePayment_EmiNotFound() {
        PaymentRequestDTO request = new PaymentRequestDTO();
        request.setLoanId("X001");
        request.setEmiNumber(99);

        when(emiScheduleRepository.findByLoanIdAndEmiNumber("X001", 99))
                .thenReturn(Optional.empty());

        assertThrows(CustomException.class,
                () -> paymentService.saveOrUpdatePayment(request));
    }

    // === updatePayment ===
    @Test
    void testUpdatePayment_Success() {
        int paymentId = 5;
        PaymentRequestDTO request = new PaymentRequestDTO();
        request.setLoanId("LN003");
        request.setEmiNumber(3);
        request.setPaymentDate(LocalDate.of(2025, 8, 26));
        request.setPaymentMethod("NETBANKING");
        request.setTransactionId("TXN789");

        Payment existing = new Payment();
        existing.setPaymentId(paymentId);

        EmiSchedule emi = new EmiSchedule();
        emi.setLoanId("LN003");
        emi.setEmiNumber(3);
        emi.setDueDate(LocalDate.of(2025, 8, 20));
        emi.setEmiAmount(BigDecimal.valueOf(1500));

        when(paymentRepository.findById(paymentId)).thenReturn(Optional.of(existing));
        when(emiScheduleRepository.findByLoanIdAndEmiNumber("LN003", 3)).thenReturn(Optional.of(emi));
        when(paymentRepository.save(any(Payment.class))).thenReturn(existing);

        PaymentResponseDTO result = paymentService.updatePayment(paymentId, request);

        assertEquals("LN003", result.getLoanId());
        assertEquals("SUCCESS", result.getPaymentStatus());
        verify(paymentRepository, times(1)).save(existing);
    }

    @Test
    void testUpdatePayment_NotFound() {
        when(paymentRepository.findById(99L)).thenReturn(Optional.empty());

        PaymentRequestDTO request = new PaymentRequestDTO();
        request.setLoanId("X");
        request.setEmiNumber(1);

        assertThrows(CustomException.class,
                () -> paymentService.updatePayment(99, request));
    }

    // === getAllPayments ===
    @Test
    void testGetAllPayments() {
        Payment p1 = new Payment();
        p1.setPaymentId(1);
        p1.setLoanId("L1");
        p1.setDaysOverdue(0);

        Payment p2 = new Payment();
        p2.setPaymentId(2);
        p2.setLoanId("L2");
        p2.setDaysOverdue(3);

        when(paymentRepository.findAll()).thenReturn(Arrays.asList(p1, p2));

        List<PaymentResponseDTO> result = paymentService.getAllPayments();

        assertEquals(2, result.size());
        assertEquals(BigDecimal.ZERO, result.get(0).getPenaltyAmount());
        assertEquals(BigDecimal.valueOf(150), result.get(1).getPenaltyAmount());
    }

    // === getPaymentsByLoanId ===
    @Test
    void testGetPaymentsByLoanId() {
        Payment p = new Payment();
        p.setPaymentId(1);
        p.setLoanId("LN004");
        p.setDaysOverdue(2);

        when(paymentRepository.findByLoanId("LN004")).thenReturn(Collections.singletonList(p));

        List<PaymentResponseDTO> result = paymentService.getPaymentsByLoanId("LN004");

        assertEquals(1, result.size());
        assertEquals(BigDecimal.valueOf(100), result.get(0).getPenaltyAmount());
    }

    // === getPaymentByLoanIdAndEmiNumber ===
    @Test
    void testGetPaymentByLoanIdAndEmiNumber_Found() {
        Payment p = new Payment();
        p.setPaymentId(10);
        p.setLoanId("LN005");
        p.setEmiNumber(5);
        p.setDaysOverdue(1);

        when(paymentRepository.findByLoanIdAndEmiNumber("LN005", 5)).thenReturn(Optional.of(p));

        Optional<PaymentResponseDTO> result = paymentService.getPaymentByLoanIdAndEmiNumber("LN005", 5);

        assertTrue(result.isPresent());
        assertEquals(BigDecimal.valueOf(50), result.get().getPenaltyAmount());
    }

    @Test
    void testGetPaymentByLoanIdAndEmiNumber_NotFound() {
        when(paymentRepository.findByLoanIdAndEmiNumber("LN999", 9)).thenReturn(Optional.empty());

        Optional<PaymentResponseDTO> result = paymentService.getPaymentByLoanIdAndEmiNumber("LN999", 9);

        assertFalse(result.isPresent());
    }
}
