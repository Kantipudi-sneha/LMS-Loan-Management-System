package com.Module1.UserRegistration.controller;

import com.Module1.UserRegistration.DTO.PaymentRequestDTO;
import com.Module1.UserRegistration.DTO.PaymentResponseDTO;
import com.Module1.UserRegistration.service.PaymentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PaymentControllerTest {

    @InjectMocks
    private PaymentController paymentController;

    @Mock
    private PaymentService paymentService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateOrUpdatePayment_Success() {
        PaymentRequestDTO request = new PaymentRequestDTO();
        PaymentResponseDTO response = new PaymentResponseDTO();
        when(paymentService.saveOrUpdatePayment(any(PaymentRequestDTO.class))).thenReturn(response);

        ResponseEntity<?> result = paymentController.createOrUpdatePayment(request);

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(response, result.getBody());
        verify(paymentService, times(1)).saveOrUpdatePayment(request);
    }

    @Test
    void testCreateOrUpdatePayment_Exception() {
        PaymentRequestDTO request = new PaymentRequestDTO();
        when(paymentService.saveOrUpdatePayment(any(PaymentRequestDTO.class))).thenThrow(new RuntimeException("DB error"));

        ResponseEntity<?> result = paymentController.createOrUpdatePayment(request);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
        assertTrue(((String) result.getBody()).contains("Error processing payment"));
    }

    @Test
    void testGetAllPayments() {
        List<PaymentResponseDTO> list = Arrays.asList(new PaymentResponseDTO(), new PaymentResponseDTO());
        when(paymentService.getAllPayments()).thenReturn(list);

        List<PaymentResponseDTO> result = paymentController.getAllPayments();

        assertEquals(2, result.size());
        verify(paymentService, times(1)).getAllPayments();
    }

    @Test
    void testGetPaymentsByLoanId() {
        String loanId = "LN001";
        List<PaymentResponseDTO> list = Arrays.asList(new PaymentResponseDTO());
        when(paymentService.getPaymentsByLoanId(loanId)).thenReturn(list);

        List<PaymentResponseDTO> result = paymentController.getPaymentsByLoanId(loanId);

        assertEquals(1, result.size());
        verify(paymentService, times(1)).getPaymentsByLoanId(loanId);
    }

    @Test
    void testUpdatePayment() {
        int paymentId = 1;
        PaymentRequestDTO request = new PaymentRequestDTO();
        PaymentResponseDTO response = new PaymentResponseDTO();
        when(paymentService.updatePayment(paymentId, request)).thenReturn(response);

        ResponseEntity<PaymentResponseDTO> result = paymentController.updatePayment(paymentId, request);

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(response, result.getBody());
        verify(paymentService, times(1)).updatePayment(paymentId, request);
    }

    @Test
    void testGetPaymentByLoanIdAndEmiNumber_Found() {
        String loanId = "LN001";
        int emiNumber = 5;
        PaymentResponseDTO response = new PaymentResponseDTO();
        when(paymentService.getPaymentByLoanIdAndEmiNumber(loanId, emiNumber)).thenReturn(Optional.of(response));

        ResponseEntity<PaymentResponseDTO> result = paymentController.getPaymentByLoanIdAndEmiNumber(loanId, emiNumber);

        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(response, result.getBody());
    }

    @Test
    void testGetPaymentByLoanIdAndEmiNumber_NotFound() {
        String loanId = "LN001";
        int emiNumber = 5;
        when(paymentService.getPaymentByLoanIdAndEmiNumber(loanId, emiNumber)).thenReturn(Optional.empty());

        ResponseEntity<PaymentResponseDTO> result = paymentController.getPaymentByLoanIdAndEmiNumber(loanId, emiNumber);

        assertEquals(HttpStatus.NOT_FOUND, result.getStatusCode());
        assertNull(result.getBody());
    }
}
