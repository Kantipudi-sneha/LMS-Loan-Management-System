package com.Module1.UserRegistration.service;

import com.Module1.UserRegistration.DTO.AdminDTO;
import com.Module1.UserRegistration.DTO.UserResponseDTO;
import com.Module1.UserRegistration.exception.CustomException;
import com.Module1.UserRegistration.model.Admin;
import com.Module1.UserRegistration.model.User;
import com.Module1.UserRegistration.model.UserRole;
import com.Module1.UserRegistration.repo.AdminRepository;
import com.Module1.UserRegistration.repo.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class AdminServiceTest {

    @Mock
    private AdminRepository adminRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private JwtService jwtService;

    @InjectMocks
    private AdminService adminService;

    private Admin admin;
    private User user;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        admin = Admin.builder()
                .id(1L)
                .username("admin1")
                .email("admin@test.com")
                .password("encodedPass")
                .active(true)
                .role(UserRole.ADMIN)
                .build();

        user = new User();
        user.setId(100L);
        user.setUsername("user1");
        user.setEmail("user1@test.com");
        user.setActive(false);
        user.setMobileNumber("9999999999");
        user.setDateOfBirth(LocalDate.of(1990, 1, 1));
    }

    // ------------------ registerAdmin ------------------
    @Test
    void testRegisterAdmin_Success() {
        AdminDTO adminDTO = new AdminDTO();
        adminDTO.setUsername("testAdmin");
        adminDTO.setEmail("admin@test.com");
        adminDTO.setMobileNumber("9876543210");
        adminDTO.setPassword("password123");
        adminDTO.setConfirmPassword("password123");
        adminDTO.setAddress("Some address");

        when(adminRepository.existsByEmail(anyString())).thenReturn(false);
        when(adminRepository.existsByMobileNumber(anyString())).thenReturn(false);

        // Fix: simulate DB-generated ID
        when(adminRepository.save(any(Admin.class))).thenAnswer(invocation -> {
            Admin savedAdmin = invocation.getArgument(0);
            savedAdmin.setId(1L);
            return savedAdmin;
        });

        ResponseEntity<?> response = adminService.registerAdmin(adminDTO);

        assertEquals(200, response.getStatusCodeValue());
        Map<String, Object> body = (Map<String, Object>) response.getBody();
        assertEquals("Admin registered successfully. Waiting for approval from SUPER_ADMIN.", body.get("message"));
        assertEquals(1L, body.get("adminId"));
    }

    @Test
    void testRegisterAdmin_PasswordMismatch() {
        AdminDTO dto = new AdminDTO();
        dto.setPassword("pass");
        dto.setConfirmPassword("different");

        assertThrows(IllegalArgumentException.class, () -> adminService.registerAdmin(dto));
    }

    @Test
    void testRegisterAdmin_DuplicateEmail() {
        AdminDTO dto = new AdminDTO();
        dto.setPassword("pass");
        dto.setConfirmPassword("pass");
        dto.setEmail("admin@test.com");

        when(adminRepository.existsByEmail(dto.getEmail())).thenReturn(true);

        assertThrows(CustomException.class, () -> adminService.registerAdmin(dto));
    }

    @Test
    void testRegisterAdmin_DuplicateMobile() {
        AdminDTO dto = new AdminDTO();
        dto.setPassword("pass");
        dto.setConfirmPassword("pass");
        dto.setEmail("admin2@test.com");
        dto.setMobileNumber("12345");

        when(adminRepository.existsByEmail(dto.getEmail())).thenReturn(false);
        when(adminRepository.existsByMobileNumber(dto.getMobileNumber())).thenReturn(true);

        assertThrows(CustomException.class, () -> adminService.registerAdmin(dto));
    }

    // ------------------ getAllUsers ------------------
    @Test
    void testGetAllUsers_Success() {
        when(jwtService.extractUserName(anyString())).thenReturn(admin.getUsername());
        when(adminRepository.findByUsername(admin.getUsername())).thenReturn(Optional.of(admin));
        when(userRepository.findAll()).thenReturn(List.of(user));

        ResponseEntity<List<UserResponseDTO>> response = adminService.getAllUsers("Bearer faketoken");

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(1, Objects.requireNonNull(response.getBody()).size());
    }

    @Test
    void testGetAllUsers_AdminNotFound() {
        when(jwtService.extractUserName(anyString())).thenReturn("missingAdmin");
        when(adminRepository.findByUsername("missingAdmin")).thenReturn(Optional.empty());

        assertThrows(CustomException.class, () -> adminService.getAllUsers("Bearer faketoken"));
    }

    @Test
    void testGetAllUsers_AdminInactive() {
        admin.setActive(false);
        when(jwtService.extractUserName(anyString())).thenReturn(admin.getUsername());
        when(adminRepository.findByUsername(admin.getUsername())).thenReturn(Optional.of(admin));

        assertThrows(CustomException.class, () -> adminService.getAllUsers("Bearer faketoken"));
    }

    // ------------------ getUserById ------------------
    @Test
    void testGetUserById_Success() {
        when(jwtService.extractUserName(anyString())).thenReturn(admin.getUsername());
        when(adminRepository.findByUsername(admin.getUsername())).thenReturn(Optional.of(admin));
        when(userRepository.findById(100L)).thenReturn(Optional.of(user));

        ResponseEntity<?> response = adminService.getUserById("Bearer faketoken", 100L);

        assertEquals(200, response.getStatusCodeValue());
        assertTrue(response.getBody() instanceof UserResponseDTO);
    }

    @Test
    void testGetUserById_UserNotFound() {
        when(jwtService.extractUserName(anyString())).thenReturn(admin.getUsername());
        when(adminRepository.findByUsername(admin.getUsername())).thenReturn(Optional.of(admin));
        when(userRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(CustomException.class, () -> adminService.getUserById("Bearer faketoken", 99L));
    }

    // ------------------ activate/deactivate ------------------
    @Test
    void testActivateUser() {
        when(jwtService.extractUserName(anyString())).thenReturn(admin.getUsername());
        when(adminRepository.findByUsername(admin.getUsername())).thenReturn(Optional.of(admin));
        when(userRepository.findById(100L)).thenReturn(Optional.of(user));

        ResponseEntity<?> response = adminService.activateUser("Bearer faketoken", 100L);

        assertEquals("User activated successfully", ((Map<?, ?>) response.getBody()).get("message"));
        assertTrue(user.isActive());
    }

    @Test
    void testDeactivateUser() {
        user.setActive(true);

        when(jwtService.extractUserName(anyString())).thenReturn(admin.getUsername());
        when(adminRepository.findByUsername(admin.getUsername())).thenReturn(Optional.of(admin));
        when(userRepository.findById(100L)).thenReturn(Optional.of(user));

        ResponseEntity<?> response = adminService.deactivateUser("Bearer faketoken", 100L);

        assertEquals("User deactivated successfully", ((Map<?, ?>) response.getBody()).get("message"));
        assertFalse(user.isActive());
    }

    // ------------------ deleteUserIfInactive ------------------
    @Test
    void testDeleteUserIfInactive_Success() {
        user.setActive(false);
        when(jwtService.extractUserName(anyString())).thenReturn(admin.getUsername());
        when(adminRepository.findByUsername(admin.getUsername())).thenReturn(Optional.of(admin));
        when(userRepository.findById(100L)).thenReturn(Optional.of(user));

        ResponseEntity<?> response = adminService.deleteUserIfInactive("Bearer faketoken", 100L);

        assertEquals("Inactive user deleted successfully", ((Map<?, ?>) response.getBody()).get("message"));
        verify(userRepository, times(1)).delete(user);
    }

    @Test
    void testDeleteUserIfInactive_FailIfActive() {
        user.setActive(true);
        when(jwtService.extractUserName(anyString())).thenReturn(admin.getUsername());
        when(adminRepository.findByUsername(admin.getUsername())).thenReturn(Optional.of(admin));
        when(userRepository.findById(100L)).thenReturn(Optional.of(user));

        ResponseEntity<?> response = adminService.deleteUserIfInactive("Bearer faketoken", 100L);

        assertEquals(400, response.getStatusCodeValue());
        assertEquals("Cannot delete an active user. Deactivate first.",
                ((Map<?, ?>) response.getBody()).get("message"));
    }
}
