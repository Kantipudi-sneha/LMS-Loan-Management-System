package com.Module1.UserRegistration.DTO;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoanDisbursementDTO {
    private Long id;
    private Long loanId;
    private Double amount;
    private String status;
    private String utrNumber;
    private String customerAccountNumber;
    private String referenceId;
    private String disbursementMethod;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
