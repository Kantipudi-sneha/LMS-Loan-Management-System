package com.Module1.UserRegistration.repo;

import com.Module1.UserRegistration.DTO.LoanDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.Module1.UserRegistration.model.Loan;
import java.util.List;

public interface LoanRepository extends JpaRepository<Loan, String> {
    
    @Query("SELECT l FROM Loan l WHERE l.customerName = :customerName")
    List<Loan> findByCustomerName(@Param("customerName") String customerName);
}
