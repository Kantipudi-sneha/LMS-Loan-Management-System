package com.Module1.UserRegistration.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data // generates getters, setters, toString, equals, hashCode
@NoArgsConstructor
@AllArgsConstructor
public class LoanApprovalDTO {
    private Long loanApplicationId;      // alias for loanApplicationId
    private Long id;   // alias for id
    private String verificationStatus;
    private String approvalComments;
    private String approvedBy;
    private Integer riskScore;
}
