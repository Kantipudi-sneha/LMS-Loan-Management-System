package com.Module1.UserRegistration.service;

import java.util.List;
import com.Module1.UserRegistration.DTO.LoanDTO;

public interface LoanService {

    LoanDTO saveLoan(LoanDTO loan);

    LoanDTO getLoanById(String loanId);

    List<LoanDTO> getAllLoans();

    List<LoanDTO> getLoansByCustomerName(String customerName);
}
