package com.Module1.UserRegistration.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "payments")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "payment_id")
    private int paymentId;

    @Column(name = "emi_number")
    private int emiNumber;

    @Column(name = "payment_date", nullable = false)
    private LocalDate paymentDate;

    @Column(name = "payment_amount", nullable = false)
    private BigDecimal paymentAmount;

    @Column(name = "payment_method", nullable = false)
    private String paymentMethod;

    @Column(name = "transaction_id")
    private String transactionId;

    @Column(name = "days_overdue")
    private int daysOverdue;

    @Column(name = "total_due")
    private BigDecimal totalDue;

    @Column(name = "payment_status", nullable = false)
    private String paymentStatus;

    @Column(name = "failure_reason")
    private String failureReason;

    @Column(name = "loan_id", nullable = false)
    private String loanId;
}
