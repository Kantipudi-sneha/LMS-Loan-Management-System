package com.Module1.UserRegistration.service;


import com.Module1.UserRegistration.exception.CustomException;
import com.Module1.UserRegistration.model.Admin;
import com.Module1.UserRegistration.model.User;
import com.Module1.UserRegistration.model.UserPrincipal;
import com.Module1.UserRegistration.repo.AdminRepository;
import com.Module1.UserRegistration.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.Optional;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class MyUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AdminRepository adminRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Check User table first
        Optional<User> optionalUser = userRepository.findByUsername(username);
        if (optionalUser.isPresent()) {
            return new UserPrincipal(optionalUser.get());
        }

        // If not found in User table, check Admin table
        Optional<Admin> optionalAdmin = adminRepository.findByUsername(username);
        if (optionalAdmin.isPresent()) {
            return new UserPrincipal(optionalAdmin.get());
        }

        throw new CustomException("User/Admin not found: " + username);
    }
}