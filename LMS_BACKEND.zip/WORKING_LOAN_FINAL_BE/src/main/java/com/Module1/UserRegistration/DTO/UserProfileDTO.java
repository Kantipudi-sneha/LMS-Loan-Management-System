package com.Module1.UserRegistration.DTO;

import java.math.BigDecimal;
import java.time.LocalDate;

public class UserProfileDTO {

    private String username;
    private String email;
    private String mobileNumber;
    private LocalDate dateOfBirth;
    private String aadharNumber;
    private String panNumber;
    private String address;
    private String occupation;
    private String employerName;
    private BigDecimal monthlyIncome;
    private String bankName;
    private String accountNumber;
    private String ifscCode;

    // No-arg constructor
    public UserProfileDTO() {}

    // All-arg constructor
    public UserProfileDTO(String username, String email, String mobileNumber, LocalDate dateOfBirth,
                          String aadharNumber, String panNumber, String address, String occupation,
                          String employerName, BigDecimal monthlyIncome, String bankName,
                          String accountNumber, String ifscCode) {
        this.username = username;
        this.email = email;
        this.mobileNumber = mobileNumber;
        this.dateOfBirth = dateOfBirth;
        this.aadharNumber = aadharNumber;
        this.panNumber = panNumber;
        this.address = address;
        this.occupation = occupation;
        this.employerName = employerName;
        this.monthlyIncome = monthlyIncome;
        this.bankName = bankName;
        this.accountNumber = accountNumber;
        this.ifscCode = ifscCode;
    }

    // Getters and Setters
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getMobileNumber() { return mobileNumber; }
    public void setMobileNumber(String mobileNumber) { this.mobileNumber = mobileNumber; }

    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }

    public String getAadharNumber() { return aadharNumber; }
    public void setAadharNumber(String aadharNumber) { this.aadharNumber = aadharNumber; }

    public String getPanNumber() { return panNumber; }
    public void setPanNumber(String panNumber) { this.panNumber = panNumber; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getOccupation() { return occupation; }
    public void setOccupation(String occupation) { this.occupation = occupation; }

    public String getEmployerName() { return employerName; }
    public void setEmployerName(String employerName) { this.employerName = employerName; }

    public BigDecimal getMonthlyIncome() { return monthlyIncome; }
    public void setMonthlyIncome(BigDecimal monthlyIncome) { this.monthlyIncome = monthlyIncome; }

    public String getBankName() { return bankName; }
    public void setBankName(String bankName) { this.bankName = bankName; }

    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }

    public String getIfscCode() { return ifscCode; }
    public void setIfscCode(String ifscCode) { this.ifscCode = ifscCode; }

    // Builder-like method for manual construction
    public static UserProfileDTOBuilder builder() { return new UserProfileDTOBuilder(); }

    public static class UserProfileDTOBuilder {
        private String username;
        private String email;
        private String mobileNumber;
        private LocalDate dateOfBirth;
        private String aadharNumber;
        private String panNumber;
        private String address;
        private String occupation;
        private String employerName;
        private BigDecimal monthlyIncome;
        private String bankName;
        private String accountNumber;
        private String ifscCode;

        public UserProfileDTOBuilder username(String username) { this.username = username; return this; }
        public UserProfileDTOBuilder email(String email) { this.email = email; return this; }
        public UserProfileDTOBuilder mobileNumber(String mobileNumber) { this.mobileNumber = mobileNumber; return this; }
        public UserProfileDTOBuilder dateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; return this; }
        public UserProfileDTOBuilder aadharNumber(String aadharNumber) { this.aadharNumber = aadharNumber; return this; }
        public UserProfileDTOBuilder panNumber(String panNumber) { this.panNumber = panNumber; return this; }
        public UserProfileDTOBuilder address(String address) { this.address = address; return this; }
        public UserProfileDTOBuilder occupation(String occupation) { this.occupation = occupation; return this; }
        public UserProfileDTOBuilder employerName(String employerName) { this.employerName = employerName; return this; }
        public UserProfileDTOBuilder monthlyIncome(BigDecimal monthlyIncome) { this.monthlyIncome = monthlyIncome; return this; }
        public UserProfileDTOBuilder bankName(String bankName) { this.bankName = bankName; return this; }
        public UserProfileDTOBuilder accountNumber(String accountNumber) { this.accountNumber = accountNumber; return this; }
        public UserProfileDTOBuilder ifscCode(String ifscCode) { this.ifscCode = ifscCode; return this; }

        public UserProfileDTO build() {
            return new UserProfileDTO(username, email, mobileNumber, dateOfBirth, aadharNumber,
                    panNumber, address, occupation, employerName, monthlyIncome, bankName, accountNumber, ifscCode);
        }
    }
}
