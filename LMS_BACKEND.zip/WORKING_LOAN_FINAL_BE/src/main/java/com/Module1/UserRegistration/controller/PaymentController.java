package com.Module1.UserRegistration.controller;

import com.Module1.UserRegistration.DTO.PaymentRequestDTO;
import com.Module1.UserRegistration.DTO.PaymentResponseDTO;
import com.Module1.UserRegistration.exception.CustomException;
import com.Module1.UserRegistration.model.Payment;
import com.Module1.UserRegistration.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins = "http://localhost:4200")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/add")
    public ResponseEntity<PaymentResponseDTO> createOrUpdatePayment(@RequestBody PaymentRequestDTO request) {
        PaymentResponseDTO saved = paymentService.saveOrUpdatePayment(request);
        return ResponseEntity.ok(saved);
    }

    @GetMapping
    public List<PaymentResponseDTO> getAllPayments() {
        return paymentService.getAllPayments();
    }

    @GetMapping("/loan/{loanId}")
    public List<PaymentResponseDTO> getPaymentsByLoanId(@PathVariable String loanId) {
        return paymentService.getPaymentsByLoanId(loanId);
    }

    @PutMapping("/update/{paymentId}")
    public ResponseEntity<PaymentResponseDTO> updatePayment(
            @PathVariable int paymentId,
            @RequestBody PaymentRequestDTO request) {

        PaymentResponseDTO updated = paymentService.updatePayment(paymentId, request);
        if (updated == null) {
            throw new CustomException("Payment not found with ID " + paymentId);
        }
        return ResponseEntity.ok(updated);
    }

    @GetMapping("/loan/{loanId}/emi/{emiNumber}")
    public ResponseEntity<PaymentResponseDTO> getPaymentByLoanIdAndEmiNumber(
            @PathVariable String loanId,
            @PathVariable int emiNumber) {

        PaymentResponseDTO payment = paymentService.getPaymentByLoanIdAndEmiNumber(loanId, emiNumber)
                .orElseThrow(() -> new CustomException("Payment not found for Loan ID " + loanId + " and EMI " + emiNumber));
        return ResponseEntity.ok(payment);
    }
}
