
package com.Module1.UserRegistration.repo;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.Module1.UserRegistration.model.Penalty;

public interface PenaltyRepository extends JpaRepository<Penalty, Integer> {

    List<Penalty> findByEmiNumber(int emiNumber);

    List<Penalty> findByLoanIdAndEmiNumber(String loanId, int emiNumber);
}
