package com.Module1.UserRegistration.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import com.Module1.UserRegistration.model.EmiSchedule;

public interface EmiScheduleService {

    List<EmiSchedule> getAllSchedule();

    List<EmiSchedule> getScheduleByLoanId(String loanId);

    List<EmiSchedule> generateSchedule(String loanId, BigDecimal principalAmount, BigDecimal interestRate, int tenure, LocalDate startDate);

    EmiSchedule updateEmiStatus(String loanId, Integer emiNumber, String status);

    List<EmiSchedule> getScheduleByLoanIdAndEmiNumber(String loanId, Integer emiNumber);
}
