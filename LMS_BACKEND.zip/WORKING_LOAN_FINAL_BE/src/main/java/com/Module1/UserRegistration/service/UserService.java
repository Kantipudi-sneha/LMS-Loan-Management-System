package com.Module1.UserRegistration.service;

import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.Module1.UserRegistration.DTO.ChangePasswordDTO;
import com.Module1.UserRegistration.DTO.UserProfileDTO;
import com.Module1.UserRegistration.DTO.UserRegistrationDTO;
import com.Module1.UserRegistration.model.User;
import com.Module1.UserRegistration.repo.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public ResponseEntity<?> registerUser(UserRegistrationDTO registrationDTO) {
        try {
            // Create new user
            User user = User.builder()
                    .username(registrationDTO.getUsername())
                    .email(registrationDTO.getEmail())
                    .mobileNumber(registrationDTO.getMobileNumber())
                    .dateOfBirth(registrationDTO.getDateOfBirth())
                    .password(passwordEncoder.encode(registrationDTO.getPassword()))
                    .aadharNumber(registrationDTO.getAadharNumber())
                    .panNumber(registrationDTO.getPanNumber())
                    .address(registrationDTO.getAddress())
                    .occupation(registrationDTO.getOccupation())
                    .employerName(registrationDTO.getEmployerName())
                    .monthlyIncome(registrationDTO.getMonthlyIncome())
                    .bankName(registrationDTO.getBankName())
                    .accountNumber(registrationDTO.getAccountNumber())
                    .ifscCode(registrationDTO.getIfscCode())
                    .role(com.Module1.UserRegistration.model.UserRole.USER)
                    .isActive(true)
                    .build();

            userRepository.save(user);
            return ResponseEntity.ok(Map.of("message", "User registered successfully", "status", "success"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("message", "Failed to register user: " + e.getMessage(), "status", "error"));
        }
    }

    public ResponseEntity<?> updateUserProfile(String authHeader, UserProfileDTO updatedProfile) {
        try {
            String token = authHeader != null && authHeader.startsWith("Bearer ")
                    ? authHeader.substring(7)
                    : authHeader;

            String username = jwtService.extractUserName(token);
            Optional<User> optionalUser = userRepository.findByUsername(username);
            if (optionalUser.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
            }
            User user = optionalUser.get();

            // Map fields
            user.setEmail(updatedProfile.getEmail());
            user.setMobileNumber(updatedProfile.getMobileNumber());
            user.setDateOfBirth(updatedProfile.getDateOfBirth());
            user.setAadharNumber(updatedProfile.getAadharNumber());
            user.setPanNumber(updatedProfile.getPanNumber());
            user.setAddress(updatedProfile.getAddress());
            user.setOccupation(updatedProfile.getOccupation());
            user.setEmployerName(updatedProfile.getEmployerName());
            user.setMonthlyIncome(updatedProfile.getMonthlyIncome());
            user.setBankName(updatedProfile.getBankName());
            user.setAccountNumber(updatedProfile.getAccountNumber());
            user.setIfscCode(updatedProfile.getIfscCode());

            userRepository.save(user);

            // Return updated profile DTO
            UserProfileDTO dto = UserProfileDTO.builder()
                    .username(user.getUsername())
                    .email(user.getEmail())
                    .mobileNumber(user.getMobileNumber())
                    .dateOfBirth(user.getDateOfBirth())
                    .aadharNumber(user.getAadharNumber())
                    .panNumber(user.getPanNumber())
                    .address(user.getAddress())
                    .occupation(user.getOccupation())
                    .employerName(user.getEmployerName())
                    .monthlyIncome(user.getMonthlyIncome())
                    .bankName(user.getBankName())
                    .accountNumber(user.getAccountNumber())
                    .ifscCode(user.getIfscCode())
                    .build();

            return ResponseEntity.ok(dto);
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("message", "Failed to update profile", "status", "error"));
        }
    }

    public UserProfileDTO getUserProfile(String authHeader) {
        try {
            String token = authHeader != null && authHeader.startsWith("Bearer ")
                    ? authHeader.substring(7)
                    : authHeader;

            String username = jwtService.extractUserName(token);
            Optional<User> optionalUser = userRepository.findByUsername(username);
            if (optionalUser.isEmpty()) {
                return null;
            }
            User user = optionalUser.get();
            return UserProfileDTO.builder()
                    .username(user.getUsername())
                    .email(user.getEmail())
                    .mobileNumber(user.getMobileNumber())
                    .dateOfBirth(user.getDateOfBirth())
                    .aadharNumber(user.getAadharNumber())
                    .panNumber(user.getPanNumber())
                    .address(user.getAddress())
                    .occupation(user.getOccupation())
                    .employerName(user.getEmployerName())
                    .monthlyIncome(user.getMonthlyIncome())
                    .bankName(user.getBankName())
                    .accountNumber(user.getAccountNumber())
                    .ifscCode(user.getIfscCode())
                    .build();
        } catch (Exception ex) {
            return null;
        }
    }

    public ResponseEntity<?> changePassword(String authHeader, ChangePasswordDTO changePasswordDTO) {
        try {
            String token = authHeader != null && authHeader.startsWith("Bearer ")
                    ? authHeader.substring(7)
                    : authHeader;

            String username = jwtService.extractUserName(token);
            Optional<User> optionalUser = userRepository.findByUsername(username);
            if (optionalUser.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
            }
            User user = optionalUser.get();

            // Verify current password
            if (!passwordEncoder.matches(changePasswordDTO.getCurrentPassword(), user.getPassword())) {
                return ResponseEntity.badRequest().body(Map.of("message", "Current password is incorrect", "status", "error"));
            }

            // Update password
            user.setPassword(passwordEncoder.encode(changePasswordDTO.getNewPassword()));
            userRepository.save(user);

            return ResponseEntity.ok(Map.of("message", "Password changed successfully", "status", "success"));
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("message", "Failed to change password", "status", "error"));
        }
    }

    public ResponseEntity<?> deleteUserAccount(String authHeader, String password) {
        try {
            String token = authHeader != null && authHeader.startsWith("Bearer ")
                    ? authHeader.substring(7)
                    : authHeader;

            String username = jwtService.extractUserName(token);
            Optional<User> optionalUser = userRepository.findByUsername(username);
            if (optionalUser.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
            }
            User user = optionalUser.get();

            // Verify password
            if (!passwordEncoder.matches(password, user.getPassword())) {
                return ResponseEntity.badRequest().body(Map.of("message", "Password is incorrect", "status", "error"));
            }

            userRepository.delete(user);
            return ResponseEntity.ok(Map.of("message", "Account deleted successfully", "status", "success"));
        } catch (Exception ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("message", "Failed to delete account", "status", "error"));
        }
    }
}