package com.Module1.UserRegistration.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

import com.Module1.UserRegistration.exception.CustomException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.Module1.UserRegistration.DTO.PenaltyRequestDTO;
import com.Module1.UserRegistration.model.EmiSchedule;
import com.Module1.UserRegistration.model.Penalty;
import com.Module1.UserRegistration.repo.EmiScheduleRepository;
import com.Module1.UserRegistration.repo.PenaltyRepository;

@Service
@Transactional
public class PenaltyServiceImpl implements PenaltyService {

    @Autowired
    private PenaltyRepository penaltyRepository;

    @Autowired
    private EmiScheduleRepository emiScheduleRepository;

    @Override
    public Penalty addPenalty(Penalty penalty) {
        if (penalty.getCreatedDate() == null) {
            penalty.setCreatedDate(LocalDateTime.now());
        }
        return penaltyRepository.save(penalty);
    }

    @Override
    public List<Penalty> getPenaltiesByLoanAndEmiNumber(String loanId, int emiNumber) {
        return penaltyRepository.findByLoanIdAndEmiNumber(loanId, emiNumber);
    }

    @Override
    public List<Penalty> getAllPenalties() {
        return penaltyRepository.findAll();
    }

    @Override
    public Penalty calculateAndAddPenalty(PenaltyRequestDTO request) {
        String loanId = request.getLoanId();
        int emiNumber = request.getEmiNumber();

        // 🔹 Check EMI schedule
        Optional<EmiSchedule> emiScheduleOpt = emiScheduleRepository.findByLoanIdAndEmiNumber(loanId, emiNumber);
        if (!emiScheduleOpt.isPresent()) {
            throw new CustomException("EMI schedule not found for loanId: " + loanId + ", emiNumber: " + emiNumber);
        }

        EmiSchedule emiSchedule = emiScheduleOpt.get();
        LocalDate dueDate = emiSchedule.getDueDate();
        LocalDate today = LocalDate.now();

        long daysOverdue = ChronoUnit.DAYS.between(dueDate, today);
        if (daysOverdue <= 0) {
            throw new CustomException("No penalty applicable as EMI is not overdue.");
        }

        if (request.getReason() == null || request.getReason().trim().isEmpty()) {
            throw new CustomException("Reason is required when penalty is applied.");
        }

        BigDecimal penaltyPerDay = BigDecimal.valueOf(50);
        BigDecimal penaltyAmount = penaltyPerDay.multiply(BigDecimal.valueOf(daysOverdue));

        Optional<Penalty> existingPenalty = penaltyRepository.findByLoanIdAndEmiNumber(loanId, emiNumber)
                .stream().findFirst();

        if (existingPenalty.isPresent()) {
            Penalty p = existingPenalty.get();
            p.setPenaltyAmount(penaltyAmount);
            p.setReason(request.getReason());
            return penaltyRepository.save(p);
        } else {
            Penalty penalty = new Penalty();
            penalty.setLoanId(loanId);
            penalty.setEmiNumber(emiNumber);
            penalty.setPenaltyAmount(penaltyAmount);
            penalty.setReason(request.getReason());
            penalty.setCreatedDate(LocalDateTime.now());
            return penaltyRepository.save(penalty);
        }
    }

    @Override
    public Optional<List<Penalty>> getPenaltiesByEmiNumber(int emiNumber) {
        List<Penalty> penalties = penaltyRepository.findByEmiNumber(emiNumber);
        return penalties.isEmpty() ? Optional.empty() : Optional.of(penalties);
    }

    @Override
    public int cleanupInvalidPenalties() {
        List<Penalty> allPenalties = penaltyRepository.findAll();
        int deletedCount = 0;

        for (Penalty penalty : allPenalties) {
            Optional<EmiSchedule> emiExists = emiScheduleRepository.findByLoanIdAndEmiNumber(
                    penalty.getLoanId(), penalty.getEmiNumber());

            if (!emiExists.isPresent()) {
                penaltyRepository.delete(penalty);
                deletedCount++;
            }
        }
        return deletedCount;
    }
}
