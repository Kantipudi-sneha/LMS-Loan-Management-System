package com.Module1.UserRegistration.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PenaltyRequestDTO {
    private Integer penaltyId;      // null when client sends request
    private String loanId;
    private int emiNumber;
    private BigDecimal penaltyAmount; // calculated in service
    private String reason;
    private LocalDateTime createdDate; // set by backend
}
