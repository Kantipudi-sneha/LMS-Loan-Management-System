package com.Module1.UserRegistration.repo;


import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Module1.UserRegistration.model.User;
import com.Module1.UserRegistration.model.UserRole;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    Optional<User> findByMobileNumber(String mobileNumber);
    boolean existsByEmail(String email);
    boolean existsByMobileNumber(String mobileNumber);

    List<User> findByRoleAndIsActive(UserRole role, boolean isActive);

    Optional<User> findByUsername(String username);

    void deleteByUsername(String username);

    boolean existsByAadharNumber(@NotBlank(message = "Aadhar number is required") @Pattern(regexp = "^\\d{12}$", message = "Aadhar must be 12 digits") String aadharNumber);

    boolean existsByPanNumber(@NotBlank(message = "PAN number is required") @Pattern(regexp = "^[A-Z]{5}[0-9]{4}[A-Z]$", message = "Invalid PAN format") String panNumber);

    boolean existsByAccountNumber(@NotBlank(message = "Account number is required") @Size(max = 20, message = "Account number must be less than 20 characters") String accountNumber);
}