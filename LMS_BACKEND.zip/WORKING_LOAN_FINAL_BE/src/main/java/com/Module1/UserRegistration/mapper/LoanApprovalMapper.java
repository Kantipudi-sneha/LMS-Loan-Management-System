package com.Module1.UserRegistration.mapper;

import com.Module1.UserRegistration.DTO.LoanApprovalDTO;
import com.Module1.UserRegistration.model.LoanApproval;
import org.springframework.stereotype.Component;

@Component
public class LoanApprovalMapper {

    public LoanApproval toEntity(LoanApprovalDTO dto) {
        if (dto == null) return null;

        LoanApproval entity = new LoanApproval();
        entity.setLoanApplicationId(dto.getLoanApplicationId());
        entity.setVerificationStatus(dto.getVerificationStatus());
        entity.setApprovalComments(dto.getApprovalComments());
        entity.setApprovedBy(dto.getApprovedBy());
        entity.setRiskScore(dto.getRiskScore());
        return entity;
    }

    public LoanApprovalDTO toDTO(LoanApproval entity) {
        if (entity == null) return null;

        LoanApprovalDTO dto = new LoanApprovalDTO();
        dto.setLoanApplicationId(entity.getLoanApplicationId());
        dto.setVerificationStatus(entity.getVerificationStatus());
        dto.setApprovalComments(entity.getApprovalComments());
        dto.setApprovedBy(entity.getApprovedBy());
        dto.setRiskScore(entity.getRiskScore());
        return dto;
    }
}
