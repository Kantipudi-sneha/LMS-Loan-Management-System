package com.Module1.UserRegistration.model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

import java.time.LocalDate;

@Entity
@Table(name = "loan_applications")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LoanApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String applicantName;
    private String email;
    private BigDecimal loanAmount;
    private Integer loanTenure; 

   
    @Builder.Default
    private String status = "PENDING";

    @Builder.Default
    private LocalDate applicationDate = LocalDate.now();

    @Builder.Default
    private String loanType = "PERSONAL"; 

    private String purpose; }
