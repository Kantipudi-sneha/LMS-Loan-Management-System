package com.Module1.UserRegistration.controller;

import com.Module1.UserRegistration.DTO.LoanApplicationDTO;
import com.Module1.UserRegistration.exception.CustomException;
import com.Module1.UserRegistration.service.LoanApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/loans")
public class LoanApplicationController {

    @Autowired
    private LoanApplicationService loanApplicationService;

    @PostMapping("/apply")
    public ResponseEntity<LoanApplicationDTO> applyLoan(@RequestBody LoanApplicationDTO loanApplicationDTO) {
        LoanApplicationDTO saved = loanApplicationService.applyLoan(loanApplicationDTO);
        return ResponseEntity.ok(saved);
    }

    @GetMapping
    public ResponseEntity<List<LoanApplicationDTO>> getAllLoans() {
        return ResponseEntity.ok(loanApplicationService.getAllLoans());
    }

    @GetMapping("/{id}")
    public ResponseEntity<LoanApplicationDTO> getLoanById(@PathVariable Long id) {
        return loanApplicationService.getLoanById(id)
                .map(ResponseEntity::ok)
                .orElseThrow(() -> new CustomException("Loan not found with id " + id));
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<LoanApplicationDTO> updateLoanStatus(
            @PathVariable Long id,
            @RequestParam String status,
            @RequestBody(required = false) Map<String, Object> approvalData) {

        LoanApplicationDTO updated = loanApplicationService.updateLoanStatus(id, status, approvalData);
        if (updated != null) {
            return ResponseEntity.ok(updated);
        } else {
            throw new CustomException("Loan not found with id " + id);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLoan(@PathVariable Long id) {
        if (loanApplicationService.deleteLoan(id)) {
            return ResponseEntity.noContent().build();
        }
        throw new CustomException("Loan not found with id " + id);
    }
}
