package com.Module1.UserRegistration.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.Module1.UserRegistration.model.EmiSchedule;

public interface EmiScheduleRepository extends JpaRepository<EmiSchedule, Integer> {

    List<EmiSchedule> findByLoanId(String loanId);

    Optional<EmiSchedule> findByLoanIdAndEmiNumber(String loanId, int emiNumber);

    List<EmiSchedule> getScheduleByLoanIdAndEmiNumber(String loanId, int emiNumber);
}
