package com.Module1.UserRegistration.service;

import java.util.List;
import java.util.stream.Collectors;

import com.Module1.UserRegistration.DTO.LoanDTO;
import com.Module1.UserRegistration.exception.CustomException;
import com.Module1.UserRegistration.model.Loan;
import com.Module1.UserRegistration.repo.LoanRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoanServiceImpl implements LoanService {

    @Autowired
    private LoanRepository loanRepository;

    @Override
    public LoanDTO saveLoan(LoanDTO loanDTO) {
        Loan loan = mapToEntity(loanDTO);
        Loan savedLoan = loanRepository.save(loan);
        return mapToDTO(savedLoan);
    }

    @Override
    public LoanDTO getLoanById(String loanId) {
        return loanRepository.findById(loanId)
                .map(this::mapToDTO)
                .orElseThrow(() -> new CustomException("Loan with ID " + loanId + " not found"));
    }

    @Override
    public List<LoanDTO> getAllLoans() {
        List<Loan> loans = loanRepository.findAll();
        if (loans.isEmpty()) {
            throw new CustomException("No loans available");
        }
        return loans.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<LoanDTO> getLoansByCustomerName(String customerName) {
        List<Loan> loans = loanRepository.findByCustomerName(customerName);
        if (loans.isEmpty()) {
            throw new CustomException("No loans found for customer: " + customerName);
        }
        return loans.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    // --- 🔄 Mapper methods ---
    private LoanDTO mapToDTO(Loan loan) {
        return new LoanDTO(
                loan.getLoanId(),
                loan.getCustomerName(),
                loan.getPrincipalAmount(),
                loan.getInterestRate(),
                loan.getTenure(),
                loan.getStartDate()
        );
    }

    private Loan mapToEntity(LoanDTO dto) {
        return new Loan(
                dto.getLoanId(),
                dto.getCustomerName(),
                dto.getPrincipalAmount(),
                dto.getInterestRate(),
                dto.getTenure(),
                dto.getStartDate()
        );
    }
}
