package com.Module1.UserRegistration.repo;

import com.Module1.UserRegistration.model.LoanApproval;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoanApprovalRepository extends JpaRepository<LoanApproval, Long> {
}
