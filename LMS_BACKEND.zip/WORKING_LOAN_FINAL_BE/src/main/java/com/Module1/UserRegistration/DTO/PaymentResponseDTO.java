package com.Module1.UserRegistration.DTO;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentResponseDTO {
    private Integer paymentId;
    private int emiNumber;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate paymentDate;
    private BigDecimal paymentAmount;
    private String paymentMethod;
    private String transactionId;
    private int daysOverdue;
    private BigDecimal totalDue;
    private String paymentStatus;
    private String failureReason;
    private String loanId;
    private BigDecimal penaltyAmount;
}
