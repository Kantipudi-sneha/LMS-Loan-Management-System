package com.Module1.UserRegistration.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.Module1.UserRegistration.exception.CustomException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Module1.UserRegistration.model.EmiSchedule;
import com.Module1.UserRegistration.repo.EmiScheduleRepository;

import jakarta.transaction.Transactional;

@Service
public class EmiScheduleServiceImpl implements EmiScheduleService {

    @Autowired
    private EmiScheduleRepository emiScheduleRepository;

    @Override
    public List<EmiSchedule> getAllSchedule() {
        List<EmiSchedule> schedules = emiScheduleRepository.findAll();
        if (schedules == null || schedules.isEmpty()) {
            throw new CustomException("No EMI schedules found in the database");
        }
        return schedules;
    }

    @Override
    public List<EmiSchedule> getScheduleByLoanId(String loanId) {
        List<EmiSchedule> list = emiScheduleRepository.findByLoanId(loanId);
        if (list == null || list.isEmpty()) {
            throw new CustomException("No EMI schedules found for Loan ID: " + loanId);
        }
        return list;
    }

    @Override
    @Transactional
    public List<EmiSchedule> generateSchedule(String loanId, BigDecimal principalAmount, BigDecimal interestRate, int tenure, LocalDate startDate) {

        if (principalAmount == null || interestRate == null || tenure <= 0 || startDate == null) {
            throw new CustomException("Invalid input for EMI generation: principal, interest rate, tenure, and start date are required");
        }

        // Delete old schedule if exists
        List<EmiSchedule> existingSchedule = emiScheduleRepository.findByLoanId(loanId);
        if (!existingSchedule.isEmpty()) {
            emiScheduleRepository.deleteAll(existingSchedule);
            emiScheduleRepository.flush();
            System.out.println("Deleted " + existingSchedule.size() + " existing schedules for loan: " + loanId);
        }

        List<EmiSchedule> scheduleList = new ArrayList<>();
        double principal = principalAmount.doubleValue();
        double annualRate = interestRate.doubleValue();
        double monthlyRate = annualRate / 12 / 100;

        if (monthlyRate <= 0) {
            throw new CustomException("Invalid monthly interest rate calculated. Check interest rate input.");
        }

        double emi;
        try {
            emi = (principal * monthlyRate * Math.pow(1 + monthlyRate, tenure)) /
                    (Math.pow(1 + monthlyRate, tenure) - 1);
        } catch (Exception e) {
            throw new CustomException("Error while calculating EMI amount");
        }

        System.out.println("Calculated EMI amount: " + emi);

        for (int i = 1; i <= tenure; i++) {
            EmiSchedule schedule = new EmiSchedule();
            schedule.setLoanId(loanId);
            schedule.setEmiNumber(i);
            schedule.setDueDate(startDate.plusMonths(i - 1));
            schedule.setPrincipal(BigDecimal.valueOf(principal / tenure).setScale(2, RoundingMode.HALF_UP));
            schedule.setInterest(BigDecimal.valueOf(emi).subtract(schedule.getPrincipal()).setScale(2, RoundingMode.HALF_UP));
            schedule.setEmiAmount(BigDecimal.valueOf(emi).setScale(2, RoundingMode.HALF_UP));
            schedule.setStatus("upcoming");
            schedule.setCreatedDate(LocalDateTime.now());
            schedule.setLastModified(LocalDateTime.now());

            EmiSchedule savedSchedule;
            try {
                savedSchedule = emiScheduleRepository.save(schedule);
                emiScheduleRepository.flush();
            } catch (Exception e) {
                throw new CustomException("Failed to save EMI schedule " + i + " for Loan ID: " + loanId);
            }

            System.out.println("✅ SAVED EMI with ID: " + savedSchedule.getEmiId() + " to database");
            scheduleList.add(savedSchedule);
        }

        // Final flush to ensure all data is committed
        emiScheduleRepository.flush();

        // Verify data was actually saved
        List<EmiSchedule> verifySchedules = emiScheduleRepository.findByLoanId(loanId);
        if (verifySchedules.size() != tenure) {
            throw new CustomException("EMI generation failed: Expected " + tenure +
                    " schedules, but found " + verifySchedules.size() + " in DB for Loan ID: " + loanId);
        }

        System.out.println("=== EMI GENERATION COMPLETED ===");
        System.out.println("Successfully created " + scheduleList.size() + " EMI schedules for loan: " + loanId);

        return scheduleList;
    }

    @Override
    @Transactional
    public EmiSchedule updateEmiStatus(String loanId, Integer emiNumber, String status) {
        Optional<EmiSchedule> emiOpt = emiScheduleRepository.findByLoanIdAndEmiNumber(loanId, emiNumber);

        if (!emiOpt.isPresent()) {
            throw new CustomException("EMI schedule not found for Loan ID: " + loanId + " and EMI Number: " + emiNumber);
        }

        EmiSchedule emi = emiOpt.get();

        if ("paid".equalsIgnoreCase(status) && "paid".equalsIgnoreCase(emi.getStatus())) {
            throw new CustomException("EMI number " + emiNumber + " for Loan ID: " + loanId + " is already marked as PAID");
        }

        emi.setStatus(status.toLowerCase());
        emi.setLastModified(LocalDateTime.now());

        try {
            return emiScheduleRepository.save(emi);
        } catch (Exception e) {
            throw new CustomException("Failed to update EMI status for Loan ID: " + loanId + " and EMI Number: " + emiNumber);
        }
    }

    @Override
    public List<EmiSchedule> getScheduleByLoanIdAndEmiNumber(String loanId, Integer emiNumber) {
        List<EmiSchedule> list = emiScheduleRepository.getScheduleByLoanIdAndEmiNumber(loanId, emiNumber);
        if (list == null || list.isEmpty()) {
            throw new CustomException("No EMI schedules found for Loan ID: " + loanId + " and EMI Number: " + emiNumber);
        }
        return list;
    }
}
