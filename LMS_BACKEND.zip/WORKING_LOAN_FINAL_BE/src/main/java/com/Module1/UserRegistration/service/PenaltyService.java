package com.Module1.UserRegistration.service;

import java.util.List;
import java.util.Optional;

import com.Module1.UserRegistration.model.Penalty;
import com.Module1.UserRegistration.DTO.PenaltyRequestDTO;

public interface PenaltyService {

    Penalty addPenalty(Penalty penalty);

    List<Penalty> getPenaltiesByLoanAndEmiNumber(String loanId, int emiNumber);

    List<Penalty> getAllPenalties();

 Penalty calculateAndAddPenalty(PenaltyRequestDTO request);

    Optional<List<Penalty>> getPenaltiesByEmiNumber(int emiNumber);
    
    int cleanupInvalidPenalties();
}
