package com.Module1.UserRegistration.controller;

import com.Module1.UserRegistration.DTO.LoanApprovalDTO;
import com.Module1.UserRegistration.exception.CustomException;
import com.Module1.UserRegistration.model.LoanApproval;
import com.Module1.UserRegistration.service.LoanApprovalService;
import com.Module1.UserRegistration.mapper.LoanApprovalMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/approvals")
public class LoanApprovalController {

    @Autowired
    private LoanApprovalService loanApprovalService;

    @Autowired
    private LoanApprovalMapper loanApprovalMapper;

    // Create approval (DTO -> Entity -> Save -> DTO)
    @PostMapping
    public LoanApprovalDTO createApproval(@RequestBody LoanApprovalDTO loanApprovalDTO) {
        System.out.println("Received loan approval request: " + loanApprovalDTO.getLoanApplicationId());

        LoanApproval entity = loanApprovalMapper.toEntity(loanApprovalDTO);
        LoanApproval saved = loanApprovalService.saveApproval(entity);

        System.out.println("Approval controller - saved approval with ID: " + saved.getId());

        return loanApprovalMapper.toDTO(saved);
    }

    // Get all approvals
    @GetMapping
    public List<LoanApprovalDTO> getAllApprovals() {
        return loanApprovalService.getAllApprovals()
                .stream()
                .map(loanApprovalMapper::toDTO)
                .collect(Collectors.toList());
    }

    // Get approval by ID
    @GetMapping("/{id}")
    public LoanApprovalDTO getApprovalById(@PathVariable Long id) {
        return loanApprovalService.getApprovalById(id)
                .map(loanApprovalMapper::toDTO)
                .orElseThrow(() -> new CustomException("Approval not found with ID " + id));
    }

    // Delete approval
    @DeleteMapping("/{id}")
    public String deleteApproval(@PathVariable Long id) {
        boolean deleted = loanApprovalService.deleteApproval(id);
        if (deleted) {
            return "Approval deleted successfully.";
        } else {
            throw new CustomException("Approval not found with ID " + id);
        }
    }

    // Test endpoint (returns DTO)
    @PostMapping("/test")
    public LoanApprovalDTO createTestApproval() {
        LoanApproval testApproval = new LoanApproval();
        testApproval.setLoanApplicationId(3L);
        testApproval.setVerificationStatus("APPROVED");
        testApproval.setApprovalComments("Test approval for presentation");
        testApproval.setApprovedBy("admin");
        testApproval.setRiskScore(75);

        System.out.println("Creating test approval...");
        LoanApproval saved = loanApprovalService.saveApproval(testApproval);

        return loanApprovalMapper.toDTO(saved);
    }
}
