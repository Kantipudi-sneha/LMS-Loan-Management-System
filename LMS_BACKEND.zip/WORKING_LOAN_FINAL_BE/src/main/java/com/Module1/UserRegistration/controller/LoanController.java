package com.Module1.UserRegistration.controller;

import com.Module1.UserRegistration.DTO.LoanDTO;
import com.Module1.UserRegistration.exception.CustomException;
import com.Module1.UserRegistration.service.LoanService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/loans")
public class LoanController {

    @Autowired
    private LoanService loanService;

    // ✅ Create loan
    @PostMapping("/add")
    public ResponseEntity<LoanDTO> createLoan(@RequestBody LoanDTO loanDTO) {
        LoanDTO savedLoan = loanService.saveLoan(loanDTO);
        return ResponseEntity.ok(savedLoan);
    }

    // ✅ Get loan by ID
    @GetMapping("/{loanId}")
    public ResponseEntity<LoanDTO> getLoanById(@PathVariable String loanId) {
        LoanDTO loanDTO = loanService.getLoanById(loanId);
        if (loanDTO != null) {
            return ResponseEntity.ok(loanDTO);
        } else {
            throw new CustomException("Loan not found with ID " + loanId);
        }
    }

    // ✅ Get all loans
    @GetMapping("/all")
    public ResponseEntity<List<LoanDTO>> getAllLoans() {
        List<LoanDTO> loanDTOs = loanService.getAllLoans();
        return ResponseEntity.ok(loanDTOs);
    }

    // ✅ Get loans by customer name
    @GetMapping("/customer/{customerName}")
    public ResponseEntity<List<LoanDTO>> getLoansByCustomerName(@PathVariable String customerName) {
        List<LoanDTO> loanDTOs = loanService.getLoansByCustomerName(customerName);
        return ResponseEntity.ok(loanDTOs);
    }
}
