package com.Module1.UserRegistration.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import com.Module1.UserRegistration.DTO.ChangePasswordDTO;
import com.Module1.UserRegistration.DTO.LoginDTO;
import com.Module1.UserRegistration.DTO.UserProfileDTO;
import com.Module1.UserRegistration.DTO.UserRegistrationDTO;
import com.Module1.UserRegistration.exception.CustomException;
import com.Module1.UserRegistration.repo.UserRepository;
import com.Module1.UserRegistration.service.JwtService;
import com.Module1.UserRegistration.service.UserService;

import jakarta.validation.Valid;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private JwtService jwtService;

    // REGISTER
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@Valid @RequestBody UserRegistrationDTO registrationDTO) {

        if (userRepository.findByUsername(registrationDTO.getUsername()).isPresent()) {
            throw new CustomException("Username already exists");
        }

        if (userRepository.findByEmail(registrationDTO.getEmail()).isPresent()) {
            throw new CustomException("Email already exists");
        }

        return userService.registerUser(registrationDTO);
    }

    // LOGIN
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginDTO loginDTO) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginDTO.getUsername(), loginDTO.getPassword())
        );

        if (authentication.isAuthenticated()) {
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            String token = jwtService.generateToken(userDetails);

            return ResponseEntity.ok()
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                    .body(Map.of(
                            "token", token,
                            "username", userDetails.getUsername(),
                            "roles", new String[]{userDetails.getAuthorities().iterator().next().getAuthority().replace("ROLE_", "")}
                    ));
        }

        throw new CustomException("Invalid credentials");
    }

    // CHANGE PASSWORD
    @PutMapping("/change-password")
    public ResponseEntity<?> changePassword(
            @RequestHeader("Authorization") String token,
            @Valid @RequestBody ChangePasswordDTO changePasswordDTO) {

        return userService.changePassword(token, changePasswordDTO);
    }

    // GET USER DETAILS
    @GetMapping("/details")
    public ResponseEntity<UserProfileDTO> getUserDetails(@RequestHeader("Authorization") String token) {
        UserProfileDTO userProfileDTO = userService.getUserProfile(token);
        if (userProfileDTO == null) {
            throw new CustomException("User not found");
        }
        return ResponseEntity.ok(userProfileDTO);
    }

    // UPDATE USER PROFILE
    @PutMapping("/update-profile")
    public ResponseEntity<?> updateUserProfile(
            @RequestHeader("Authorization") String token,
            @Valid @RequestBody UserProfileDTO updatedProfile) {

        return userService.updateUserProfile(token, updatedProfile);
    }

    // DELETE ACCOUNT
    @DeleteMapping("/delete-account")
    public ResponseEntity<?> deleteUserAccount(
            @RequestHeader("Authorization") String token,
            @RequestParam String password) {

        return userService.deleteUserAccount(token, password);
    }

    // LOGOUT
    @PostMapping("/logout")
    public ResponseEntity<?> logout(@RequestHeader("Authorization") String token) {
        String jwt = token.substring(7);
        jwtService.logout(jwt);
        return ResponseEntity.ok(Map.of("message", "Logged out successfully"));
    }
}
