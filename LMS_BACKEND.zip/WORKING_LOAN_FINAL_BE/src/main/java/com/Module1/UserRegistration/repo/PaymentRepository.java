package com.Module1.UserRegistration.repo;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.Module1.UserRegistration.model.Payment;

public interface PaymentRepository extends JpaRepository<Payment, Integer> {

    List<Payment> findByLoanId(String loanId);

    Optional<Payment> findByLoanIdAndEmiNumber(String loanId, int emiNumber);

    Optional<Payment> findByPaymentId(int paymentId);
}
