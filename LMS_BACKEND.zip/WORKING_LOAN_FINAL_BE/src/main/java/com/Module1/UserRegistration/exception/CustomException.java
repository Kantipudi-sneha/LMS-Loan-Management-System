package com.Module1.UserRegistration.exception;

public class CustomException extends RuntimeException {
    public CustomException(String message){
        super(message);
    }
}
