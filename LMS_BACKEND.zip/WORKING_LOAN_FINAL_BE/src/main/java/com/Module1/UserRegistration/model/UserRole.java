package com.Module1.UserRegistration.model;

public enum UserRole {
    USER,
    ADMIN

}
