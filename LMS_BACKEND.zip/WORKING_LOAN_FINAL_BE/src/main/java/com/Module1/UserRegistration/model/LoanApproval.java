package com.Module1.UserRegistration.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "loan_approvals")
public class LoanApproval {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long loanApplicationId;
    private String verificationStatus;
    private String approvalComments;
    private String approvedBy;
    private LocalDate approvalDate;
    private Integer riskScore;
}
