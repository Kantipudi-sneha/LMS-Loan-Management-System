package com.Module1.UserRegistration.service;

import com.Module1.UserRegistration.DTO.LoanApplicationDTO;
import com.Module1.UserRegistration.exception.CustomException;
import com.Module1.UserRegistration.model.LoanApplication;
import com.Module1.UserRegistration.model.LoanApproval;
import com.Module1.UserRegistration.repo.LoanApplicationRepository;
import com.Module1.UserRegistration.repo.LoanApprovalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class LoanApplicationService {

    @Autowired
    private LoanApplicationRepository loanApplicationRepository;

    @Autowired
    private LoanApprovalRepository loanApprovalRepository;

 
    public LoanApplicationDTO applyLoan(LoanApplicationDTO dto) {
        if (dto == null) {
            throw new CustomException("Loan application data cannot be null");
        }
        LoanApplication loanApplication = toEntity(dto);
        loanApplication.setStatus("PENDING");
        LoanApplication saved = loanApplicationRepository.save(loanApplication);
        return toDTO(saved);
    }

    
    public List<LoanApplicationDTO> getAllLoans() {
        List<LoanApplication> loans = loanApplicationRepository.findAll();
        if (loans.isEmpty()) {
            throw new CustomException("No loan applications found");
        }
        return loans.stream().map(this::toDTO).collect(Collectors.toList());
    }

  
    public Optional<LoanApplicationDTO> getLoanById(Long id) {
        return loanApplicationRepository.findById(id)
                .map(this::toDTO);
    }


    
    public LoanApplicationDTO updateLoanStatus(Long id, String status) {
        return updateLoanStatus(id, status, null);
    }

    public LoanApplicationDTO updateLoanStatus(Long id, String status, Map<String, Object> approvalData) {
        LoanApplication loan = loanApplicationRepository.findById(id)
                .orElseThrow(() -> new CustomException("Cannot update status. Loan application not found with ID: " + id));

        if (status == null || status.isBlank()) {
            throw new CustomException("Loan status cannot be null or empty");
        }

        loan.setStatus(status);
        LoanApplication savedLoan = loanApplicationRepository.save(loan);

        
        if ("APPROVED".equalsIgnoreCase(status) && approvalData != null) {
            LoanApproval approval = new LoanApproval();
            approval.setLoanApplicationId(id);
            approval.setVerificationStatus("APPROVED");
            approval.setApprovalComments("Loan approved via admin panel");
            approval.setApprovedBy(
                    approvalData.get("adminId") != null
                            ? "admin_" + approvalData.get("adminId")
                            : "admin"
            );
            approval.setApprovalDate(LocalDate.now());
            approval.setRiskScore(75); 

            loanApprovalRepository.save(approval);
        }

        return toDTO(savedLoan);
    }

  
    public boolean deleteLoan(Long id) {
        if (!loanApplicationRepository.existsById(id)) {
            throw new CustomException("Cannot delete. Loan application not found with ID: " + id);
        }
        loanApplicationRepository.deleteById(id);
        return true;
    }



    private LoanApplicationDTO toDTO(LoanApplication loan) {
        if (loan == null) {
            throw new CustomException("Loan entity cannot be null");
        }
        return LoanApplicationDTO.builder()
                .id(loan.getId())
                .applicantName(loan.getApplicantName())
                .email(loan.getEmail())
                .loanAmount(loan.getLoanAmount())
                .loanTenure(loan.getLoanTenure())
                .loanType(loan.getLoanType())
                .purpose(loan.getPurpose())
                .status(loan.getStatus())
                .applicationDate(loan.getApplicationDate())
                .build();
    }

    private LoanApplication toEntity(LoanApplicationDTO dto) {
        if (dto == null) {
            throw new CustomException("Loan DTO cannot be null");
        }
        return LoanApplication.builder()
                .id(dto.getId())
                .applicantName(dto.getApplicantName())
                .email(dto.getEmail())
                .loanAmount(dto.getLoanAmount())
                .loanTenure(dto.getLoanTenure())
                .loanType(dto.getLoanType())
                .purpose(dto.getPurpose())
                .status(dto.getStatus())
                .applicationDate(dto.getApplicationDate())
                .build();
    }
}
