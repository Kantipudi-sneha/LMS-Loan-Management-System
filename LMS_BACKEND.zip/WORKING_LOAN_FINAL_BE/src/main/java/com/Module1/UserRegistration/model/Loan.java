package com.Module1.UserRegistration.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "loan_tracking")
@Data
@NoArgsConstructor   // generates default constructor (required by JPA)
@AllArgsConstructor  // generates all-args constructor
public class Loan {

    @Id
    @Column(name = "loan_id")
    private String loanId;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "principal_amount")
    private BigDecimal principalAmount;

    @Column(name = "interest_rate")
    private BigDecimal interestRate;

    @Column(name = "tenure")
    private int tenure;

    @Column(name = "start_date")
    private LocalDate startDate;
}
