package com.Module1.UserRegistration.service;

import java.util.List;
import java.util.Optional;

import com.Module1.UserRegistration.DTO.PaymentRequestDTO;
import com.Module1.UserRegistration.DTO.PaymentResponseDTO;

public interface PaymentService {

    PaymentResponseDTO saveOrUpdatePayment(PaymentRequestDTO request);

    PaymentResponseDTO updatePayment(int paymentId, PaymentRequestDTO request);

    List<PaymentResponseDTO> getAllPayments();

    List<PaymentResponseDTO> getPaymentsByLoanId(String loanId);

    Optional<PaymentResponseDTO> getPaymentByLoanIdAndEmiNumber(String loanId, int emiNumber);
}
