package com.Module1.UserRegistration.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class UpdateEmiStatusRequestDTO{

    @NotBlank(message = "Loan ID cannot be blank")
    private String loanId;

    @NotNull(message = "EMI Number cannot be null")
    @Positive(message = "EMI Number must be positive")
    private Integer emiNumber;

    @NotBlank(message = "Status cannot be blank")
    private String status;

    public UpdateEmiStatusRequestDTO() {}

    public UpdateEmiStatusRequestDTO(String loanId, Integer emiNumber, String status) {
        this.loanId = loanId;
        this.emiNumber = emiNumber;
        this.status = status;
    }

    public String getLoanId() { return loanId; }
    public void setLoanId(String loanId) { this.loanId = loanId; }

    public Integer getEmiNumber() { return emiNumber; }
    public void setEmiNumber(Integer emiNumber) { this.emiNumber = emiNumber; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return "UpdateEmiStatusRequest{" +
                "loanId='" + loanId + '\'' +
                ", emiNumber=" + emiNumber +
                ", status='" + status + '\'' +
                '}';
    }
}
