package com.Module1.UserRegistration.DTO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)   
public class LoanApplicationDTO {
    private Long id;
    private String applicantName;
    private String email;
    private BigDecimal loanAmount;    
    private Integer loanTenure;
    private String loanType;
    private String purpose;
    private String status;
    private LocalDate applicationDate;
}
