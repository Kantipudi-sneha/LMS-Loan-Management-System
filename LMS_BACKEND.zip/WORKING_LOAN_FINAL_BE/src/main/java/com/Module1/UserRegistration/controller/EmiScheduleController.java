package com.Module1.UserRegistration.controller;

import com.Module1.UserRegistration.model.EmiSchedule;
import com.Module1.UserRegistration.service.EmiScheduleService;
import com.Module1.UserRegistration.DTO.UpdateEmiStatusRequestDTO;
import com.Module1.UserRegistration.repo.EmiScheduleRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/emi-schedule")
public class EmiScheduleController {

    @Autowired
    private EmiScheduleService emiScheduleService;

    @Autowired
    private EmiScheduleRepository emiScheduleRepository;

    @GetMapping
    public List<EmiSchedule> getAllSchedules() {
        return emiScheduleService.getAllSchedule();
    }

    @PostMapping("/generate")
    public ResponseEntity<List<EmiSchedule>> generateSchedule(@RequestBody java.util.Map<String, Object> request) {
        String loanId = request.get("loanId").toString();
        double principalAmount = Double.parseDouble(request.get("principalAmount").toString());
        double interestRate = Double.parseDouble(request.get("interestRate").toString());
        int tenure = Integer.parseInt(request.get("tenure").toString());
        java.time.LocalDate startDate = java.time.LocalDate.parse(request.get("startDate").toString());

        // Generate complete EMI schedule (service will handle deletion)
        List<EmiSchedule> schedules = emiScheduleService.generateSchedule(
                loanId,
                java.math.BigDecimal.valueOf(principalAmount),
                java.math.BigDecimal.valueOf(interestRate),
                tenure,
                startDate
        );


        emiScheduleService.getScheduleByLoanId(loanId);

        return ResponseEntity.ok(schedules);
    }

    @GetMapping("/loan/{loanId}")
    public List<EmiSchedule> getScheduleByLoanId(@PathVariable String loanId) {
        return emiScheduleService.getScheduleByLoanId(loanId);
    }

    @GetMapping("/loan/{loanId}/emi/{emiNumber}")
    public List<EmiSchedule> getEmiByLoanAndEmiNumber(@PathVariable String loanId, @PathVariable Integer emiNumber) {
        return emiScheduleService.getScheduleByLoanIdAndEmiNumber(loanId, emiNumber);
    }

    @PatchMapping("/update-status")
    public ResponseEntity<EmiSchedule> updateEmiStatus(@RequestBody UpdateEmiStatusRequestDTO request) {
        EmiSchedule updatedEmi = emiScheduleService.updateEmiStatus(
                request.getLoanId(),
                request.getEmiNumber(),
                request.getStatus()
        );
        return ResponseEntity.ok(updatedEmi);
    }
}
