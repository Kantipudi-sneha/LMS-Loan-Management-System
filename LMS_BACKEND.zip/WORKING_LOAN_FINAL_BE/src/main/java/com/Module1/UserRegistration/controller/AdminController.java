package com.Module1.UserRegistration.controller;

import com.Module1.UserRegistration.DTO.AdminApprovalDTO;
import com.Module1.UserRegistration.DTO.AdminDTO;
import com.Module1.UserRegistration.DTO.UserResponseDTO;
import com.Module1.UserRegistration.model.Admin;
import com.Module1.UserRegistration.model.User;
import com.Module1.UserRegistration.service.AdminService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import com.Module1.UserRegistration.DTO.LoginDTO;
import com.Module1.UserRegistration.service.JwtService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import java.util.Map;
import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtService jwtService;

    @PostMapping("/register")
    public ResponseEntity<?> registerAdmin(@Valid @RequestBody AdminDTO adminDTO) {

        return adminService.registerAdmin(adminDTO);
    }


    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/users/{id}")
    public ResponseEntity<UserResponseDTO> getUserById(@RequestHeader("Authorization") String authHeader, @PathVariable Long id) {
        return adminService.getUserById(authHeader,id);
    }
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/users/{id}/activate")
    public ResponseEntity<?> activateUser(@RequestHeader("Authorization") String authHeader,@PathVariable Long id) {
        return adminService.activateUser(authHeader,id);
    }

    @PreAuthorize(" hasRole('ADMIN')")
    @PutMapping("/users/{id}/deactivate")
    public ResponseEntity<?> deactivateUser(@RequestHeader("Authorization") String authHeader,@PathVariable Long id) {
        return adminService.deactivateUser(authHeader,id);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/users")
    public ResponseEntity<List<UserResponseDTO>> getAllUsers(@RequestHeader("Authorization") String authHeader) {

        return adminService.getAllUsers(authHeader);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/users/{id}")
    public ResponseEntity<?> deleteUser(@RequestHeader("Authorization") String authHeader,
                                        @PathVariable Long id) {
        return adminService.deleteUserIfInactive(authHeader, id);
    }
    
 // Add this method to your AdminController
    @PostMapping("/login")
    public ResponseEntity<?> adminLogin(@RequestBody LoginDTO loginDTO) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginDTO.getUsername(), loginDTO.getPassword())
            );

            if (authentication.isAuthenticated()) {
                UserDetails userDetails = (UserDetails) authentication.getPrincipal();
                String token = jwtService.generateToken(userDetails);

                return ResponseEntity.ok()
                        .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                        .body(Map.of(
                                "token", token,
                                "username", userDetails.getUsername(),
                                "roles", userDetails.getAuthorities()
                        ));
            }
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Login Failed");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }


}