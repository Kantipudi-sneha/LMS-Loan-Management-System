package com.Module1.UserRegistration.service;

import com.Module1.UserRegistration.exception.CustomException;
import com.Module1.UserRegistration.model.LoanDisbursement;
import com.Module1.UserRegistration.repo.LoanDisbursementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LoanDisbursementService {

    @Autowired
    private LoanDisbursementRepository loanDisbursementRepository;

    // Create new disbursement
    public LoanDisbursement initiateDisbursement(LoanDisbursement disbursement) {
        disbursement.setStatus("PENDING");
        return loanDisbursementRepository.save(disbursement);
    }

    // Get all disbursements
    public List<LoanDisbursement> getAllDisbursements() {



            List<LoanDisbursement> disbursements = loanDisbursementRepository.findAll();
            if(disbursements.isEmpty())
            {
                throw new CustomException("No disbursements found ");
            }
            return disbursements;

    }

    // Get a single disbursement by ID
    public Optional<LoanDisbursement> getDisbursementById(Long id) {
        Optional<LoanDisbursement> loan=loanDisbursementRepository.findById(id);
        if(loan.isEmpty()){
            throw new CustomException("no Disbursement found by id "+id);
        }
        return  loan;
    }

    // Update disbursement
    public LoanDisbursement updateDisbursement(Long id, LoanDisbursement updatedDisbursement) {
        Optional<LoanDisbursement> existingOpt = getDisbursementById(id);
        if (existingOpt.isPresent()) {
            LoanDisbursement existing = existingOpt.get();
            existing.setAmount(updatedDisbursement.getAmount());
            existing.setLoanId(updatedDisbursement.getLoanId());
            existing.setCustomerAccountNumber(updatedDisbursement.getCustomerAccountNumber());
            existing.setReferenceId(updatedDisbursement.getReferenceId());
            existing.setUtrNumber(updatedDisbursement.getUtrNumber());
            existing.setDisbursementMethod(updatedDisbursement.getDisbursementMethod());
            existing.setStatus(updatedDisbursement.getStatus());
            return loanDisbursementRepository.save(existing);
        }
        throw new CustomException("Disbursement not found with id: " + id);
    }

    // Update UTR and mark as DISBURSED
    public LoanDisbursement updateUTR(Long id, String utrNumber) {
        Optional<LoanDisbursement> disbursementOpt = loanDisbursementRepository.findById(id);
        if (disbursementOpt.isPresent()) {
            LoanDisbursement disbursement = disbursementOpt.get();
            disbursement.setUtrNumber(utrNumber);
            disbursement.setStatus("DISBURSED");
            return loanDisbursementRepository.save(disbursement);
        }
        throw new CustomException("Disbursement not found with id: " + id);
    }

    //  Approve disbursement
    public LoanDisbursement approveDisbursement(Long id) {
        Optional<LoanDisbursement> disbursementOpt = loanDisbursementRepository.findById(id);
        if (disbursementOpt.isPresent()) {
            LoanDisbursement disbursement = disbursementOpt.get();
            disbursement.setStatus("APPROVED");
            return loanDisbursementRepository.save(disbursement);
        }
        throw new RuntimeException("Disbursement not found with id: " + id);
    }

    //  Reject disbursement
    public LoanDisbursement rejectDisbursement(Long id) {
        Optional<LoanDisbursement> disbursementOpt = loanDisbursementRepository.findById(id);
        if (disbursementOpt.isPresent()) {
            LoanDisbursement disbursement = disbursementOpt.get();
            disbursement.setStatus("REJECTED");
            return loanDisbursementRepository.save(disbursement);
        }
        throw new CustomException("Disbursement not found with id: " + id);
    }

    // Mark disbursement as failed
    public LoanDisbursement markDisbursementFailed(Long id) {
        Optional<LoanDisbursement> disbursementOpt = loanDisbursementRepository.findById(id);
        if (disbursementOpt.isPresent()) {
            LoanDisbursement disbursement = disbursementOpt.get();
            disbursement.setStatus("FAILED");
            return loanDisbursementRepository.save(disbursement);
        }
        throw new CustomException("Disbursement not found with id: " + id);
    }

    // Cancel a disbursement
    public boolean cancelDisbursement(Long id) {
        Optional<LoanDisbursement> disbursementOpt = loanDisbursementRepository.findById(id);
        if (disbursementOpt.isPresent()) {
            LoanDisbursement disbursement = disbursementOpt.get();
            disbursement.setStatus("CANCELLED");
            loanDisbursementRepository.save(disbursement);
            return true;
        }
        return false;
    }

    // Get disbursements by loan ID
    public List<LoanDisbursement> getDisbursementsByLoanId(Long loanId) {
        return loanDisbursementRepository.findByLoanId(loanId);
    }

    // Get disbursements by status
    public List<LoanDisbursement> getDisbursementsByStatus(String status) {
        return loanDisbursementRepository.findByStatus(status);
    }
}