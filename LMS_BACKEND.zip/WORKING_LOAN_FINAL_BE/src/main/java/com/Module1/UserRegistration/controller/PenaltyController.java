package com.Module1.UserRegistration.controller;

import com.Module1.UserRegistration.DTO.PenaltyRequestDTO;
import com.Module1.UserRegistration.exception.CustomException;
import com.Module1.UserRegistration.model.Penalty;
import com.Module1.UserRegistration.service.PenaltyService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/penalties")
public class PenaltyController {

    @Autowired
    private PenaltyService penaltyService;

    @PostMapping("/add")
    public ResponseEntity<Penalty> addPenalty(@RequestBody PenaltyRequestDTO dto) {
        Penalty penalty = new Penalty();
        penalty.setLoanId(dto.getLoanId());
        penalty.setEmiNumber(dto.getEmiNumber());
        penalty.setReason(dto.getReason());
        penalty.setPenaltyAmount(BigDecimal.ZERO);
        penalty.setCreatedDate(LocalDateTime.now());

        Penalty saved = penaltyService.addPenalty(penalty);
        if (saved == null) {
            throw new CustomException("Failed to add penalty for Loan ID " + dto.getLoanId());
        }
        return ResponseEntity.ok(saved);
    }

    @GetMapping
    public List<Penalty> getAllPenalties() {
        return penaltyService.getAllPenalties();
    }

    @DeleteMapping("/cleanup")
    public ResponseEntity<String> cleanupInvalidPenalties() {
        int deletedCount = penaltyService.cleanupInvalidPenalties();
        return ResponseEntity.ok("Deleted " + deletedCount + " penalties with invalid loan IDs");
    }

    @GetMapping("/loan/{loanId}/emi/{emiNumber}")
    public List<Penalty> getPenaltiesByLoanAndEmiNumber(@PathVariable String loanId, @PathVariable int emiNumber) {
        List<Penalty> penalties = penaltyService.getPenaltiesByLoanAndEmiNumber(loanId, emiNumber);
        if (penalties == null || penalties.isEmpty()) {
            throw new CustomException("No penalties found for Loan ID " + loanId + " and EMI " + emiNumber);
        }
        return penalties;
    }

    @PostMapping("/calculate-add")
    public ResponseEntity<Penalty> calculateAndAddPenalty(@RequestBody PenaltyRequestDTO request) {
        Penalty penalty = penaltyService.calculateAndAddPenalty(request);
        if (penalty == null) {
            throw new CustomException("Failed to calculate and add penalty for Loan ID " + request.getLoanId());
        }
        return ResponseEntity.ok(penalty);
    }
}
