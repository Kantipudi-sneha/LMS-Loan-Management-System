package com.Module1.UserRegistration.service;

import com.Module1.UserRegistration.exception.CustomException;
import com.Module1.UserRegistration.model.LoanApproval;
import com.Module1.UserRegistration.repo.LoanApprovalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class LoanApprovalService {

    @Autowired
    private LoanApprovalRepository loanApprovalRepository;

    // Save approval
    public LoanApproval saveApproval(LoanApproval approval) {
        System.out.println("Attempting to save loan approval for loan ID: " + approval.getLoanApplicationId());
        if (approval.getApprovalDate() == null) {
            approval.setApprovalDate(LocalDate.now());
        }
        LoanApproval saved = loanApprovalRepository.save(approval);
        System.out.println("Loan approval saved with ID: " + saved.getId());
        return saved;
    }

    // Get all approvals
    public List<LoanApproval> getAllApprovals() {
        return loanApprovalRepository.findAll();
    }

    // Get approval by ID
    public Optional<LoanApproval> getApprovalById(Long id) {
        return loanApprovalRepository.findById(id);
    }

    // Delete approval by ID
    public boolean deleteApproval(Long id) {
        if (!loanApprovalRepository.existsById(id)) {
            throw new CustomException("approval not found with id "+id);
        }
        loanApprovalRepository.deleteById(id);
        return true;

    }
}
