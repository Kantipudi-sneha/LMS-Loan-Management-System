package com.Module1.UserRegistration.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.Module1.UserRegistration.DTO.AdminDTO;
import com.Module1.UserRegistration.DTO.UserResponseDTO;
import com.Module1.UserRegistration.exception.CustomException;
import com.Module1.UserRegistration.model.Admin;
import com.Module1.UserRegistration.model.User;
import com.Module1.UserRegistration.model.UserRole;
import com.Module1.UserRegistration.repo.AdminRepository;
import com.Module1.UserRegistration.repo.UserRepository;

@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtService jwtService;
    private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);
//Admin Registration
    public ResponseEntity<?> registerAdmin(AdminDTO adminDTO) {
        if (!adminDTO.getPassword().equals(adminDTO.getConfirmPassword())) {
            throw new IllegalArgumentException("Passwords do not match");
        }

        if (adminRepository.existsByEmail(adminDTO.getEmail())) {
            throw new CustomException("Email already registered");
        }
        if (adminRepository.existsByMobileNumber(adminDTO.getMobileNumber())) {
            throw new CustomException("Mobile number already registered");
        }

        Admin admin = Admin.builder()
                .username(adminDTO.getUsername())
                .email(adminDTO.getEmail())
                .mobileNumber(adminDTO.getMobileNumber())
                .address(adminDTO.getAddress())
                .password(encoder.encode(adminDTO.getPassword()))
                .active(true)
                .role(UserRole.ADMIN)
                .build();

        adminRepository.save(admin);

        return ResponseEntity.ok(Map.of(
                "message", "Admin registered successfully. Waiting for approval from SUPER_ADMIN.",
                "adminId", admin.getId()
        ));
    }
//Get all Users
    public ResponseEntity<List<UserResponseDTO>> getAllUsers(String authHeader) {
        // Extract admin email from JWT token
        String token = authHeader.substring(7);
        String username = jwtService.extractUserName(token);

        // Verify admin is active
        Optional<Admin> optionalAdmin = adminRepository.findByUsername(username);
        if (optionalAdmin.isEmpty()) {
            throw new CustomException("Admin not found");
        }
        Admin admin = optionalAdmin.get();

        if (!admin.isActive()) {
            throw new CustomException("Admin account is not active");
        }


        List<UserResponseDTO> users = userRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());

        return ResponseEntity.ok(users);
    }
//Response for getting Users Data
    private UserResponseDTO convertToDTO(User user) {
        UserResponseDTO dto = new UserResponseDTO();
        dto.setId(user.getId());
        dto.setUsername(user.getUsername());
        dto.setEmail(user.getEmail());
        dto.setMobileNumber(user.getMobileNumber());
        dto.setDateOfBirth(user.getDateOfBirth());
        dto.setAadharNumber(user.getAadharNumber());
        dto.setPanNumber(user.getPanNumber());
        dto.setAddress(user.getAddress());

        return dto;
    }
//Get User Data By Id
    public ResponseEntity<UserResponseDTO> getUserById(String authHeader,Long id) {
        String token = authHeader.substring(7);
        String username = jwtService.extractUserName(token);

        // Verify admin is active
        Optional<Admin> optionalAdmin = adminRepository.findByUsername(username);
        if (optionalAdmin.isEmpty()) {
            throw new CustomException("Admin not found");
        }
        Admin admin = optionalAdmin.get();

        if (!admin.isActive()) {
            throw new CustomException("Admin account is not active");
        }
        User user = userRepository.findById(id)
                .orElseThrow(() -> new CustomException("User not found"));
        UserResponseDTO userResponseDTO=convertToDTO(user);
        return ResponseEntity.ok(userResponseDTO);
    }

    public ResponseEntity<?> activateUser(String authHeader,Long id) {
        String token = authHeader.substring(7);
        String username = jwtService.extractUserName(token);

        // Verify admin is active
        Optional<Admin> optionalAdmin = adminRepository.findByUsername(username);
        if (optionalAdmin.isEmpty()) {
            throw new CustomException("Admin not found");
        }
        Admin admin = optionalAdmin.get();

        if (!admin.isActive()) {
            throw new CustomException("Admin account is not active");
        }
        User user = userRepository.findById(id)
                .orElseThrow(() -> new CustomException("User not found"));
        user.setActive(true);
        userRepository.save(user);
        return ResponseEntity.ok(Map.of("message", "User activated successfully"));
    }

    public ResponseEntity<?> deactivateUser(String authHeader,Long id) {
        String token = authHeader.substring(7);
        String username = jwtService.extractUserName(token);

        // Verify admin is active
        Optional<Admin> optionalAdmin = adminRepository.findByUsername(username);
        if (optionalAdmin.isEmpty()) {
            throw new CustomException("Admin not found");
        }
        Admin admin = optionalAdmin.get();

        if (!admin.isActive()) {
            throw new CustomException("Admin account is not active");
        }
        User user = userRepository.findById(id)
                .orElseThrow(() -> new CustomException("User not found"));
        user.setActive(false);
        userRepository.save(user);
        return ResponseEntity.ok(Map.of("message", "User deactivated successfully"));
    }

    public ResponseEntity<?> deleteUserIfInactive(String authHeader, Long id) {
        String token = authHeader.substring(7);
        String username = jwtService.extractUserName(token);

        // Verify admin is active
        Optional<Admin> optionalAdmin = adminRepository.findByUsername(username);
        if (optionalAdmin.isEmpty()) {
            throw new CustomException("Admin not found");
        }
        Admin admin = optionalAdmin.get();
        if (!admin.isActive()) {
            throw new CustomException("Admin account is not active");
        }

        User user = userRepository.findById(id)
                .orElseThrow(() -> new CustomException("User not found"));

        if (user.isActive()) {
            return ResponseEntity.badRequest().body(
                    Map.of("message", "Cannot delete an active user. Deactivate first.")
            );
        }

        userRepository.delete(user);
        return ResponseEntity.ok(Map.of("message", "Inactive user deleted successfully"));
    }

}
