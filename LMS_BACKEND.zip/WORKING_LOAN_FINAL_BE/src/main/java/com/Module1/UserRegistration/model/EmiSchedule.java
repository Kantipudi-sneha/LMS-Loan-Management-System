package com.Module1.UserRegistration.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "emi_tracking")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmiSchedule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "emi_id")
    private int emiId;

    @Column(name = "loan_id", nullable = false)
    private String loanId;

    @Column(name = "emi_number", nullable = false)
    private int emiNumber;

    @Column(name = "due_date", nullable = false)
    private LocalDate dueDate;

    @Column(name = "principal", nullable = false)
    private BigDecimal principal;

    @Column(name = "interest", nullable = false)
    private BigDecimal interest;

    @Column(name = "emi_amount", nullable = false)
    private BigDecimal emiAmount;

    @Column(name = "status", nullable = false)
    private String status;

    @Column(name = "created_date", updatable = false)
    private LocalDateTime createdDate;

    @Column(name = "last_modified")
    private LocalDateTime lastModified;

    // convenience constructor (custom, not replaced by Lombok)
    public EmiSchedule(String loanId, int emiNumber, LocalDate dueDate, BigDecimal principal,
                       BigDecimal interest, BigDecimal emiAmount, String status) {
        this.loanId = loanId;
        this.emiNumber = emiNumber;
        this.dueDate = dueDate;
        this.principal = principal;
        this.interest = interest;
        this.emiAmount = emiAmount;
        this.status = status;
        this.createdDate = LocalDateTime.now();
        this.lastModified = LocalDateTime.now();
    }
}
