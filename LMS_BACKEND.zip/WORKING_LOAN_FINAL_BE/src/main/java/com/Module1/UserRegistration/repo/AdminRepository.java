package com.Module1.UserRegistration.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Module1.UserRegistration.model.Admin;

public interface AdminRepository extends JpaRepository<Admin,Long> {
    boolean existsByEmail(String email);

    boolean existsByMobileNumber(String mobileNumber);

    Optional<Admin> findByEmail(String email);
    List<Admin> findByActiveFalse();

    Optional<Admin> findByUsername(String username);

    boolean existsByUsername(String superadmin1);
}
