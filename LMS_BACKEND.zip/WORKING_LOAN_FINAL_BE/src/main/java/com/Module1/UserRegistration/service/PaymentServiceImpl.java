package com.Module1.UserRegistration.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.Module1.UserRegistration.DTO.PaymentResponseDTO;
import com.Module1.UserRegistration.exception.CustomException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Module1.UserRegistration.DTO.PaymentRequestDTO;
import com.Module1.UserRegistration.model.EmiSchedule;
import com.Module1.UserRegistration.model.Payment;
import com.Module1.UserRegistration.model.Penalty;
import com.Module1.UserRegistration.repo.EmiScheduleRepository;
import com.Module1.UserRegistration.repo.LoanRepository;
import com.Module1.UserRegistration.repo.PaymentRepository;

import jakarta.transaction.Transactional;

@Service
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;
    @Autowired
    private LoanRepository loanRepository;
    @Autowired
    private EmiScheduleRepository emiScheduleRepository;
    @Autowired
    private PenaltyService penaltyService;

    private static final BigDecimal PENALTY_RATE = BigDecimal.valueOf(50); // ₹50/day

    @Override
    @Transactional
    public PaymentResponseDTO saveOrUpdatePayment(PaymentRequestDTO request) {

        EmiSchedule emi = emiScheduleRepository
                .findByLoanIdAndEmiNumber(request.getLoanId(), request.getEmiNumber())
                .orElseThrow(() -> new CustomException(
                        "EMI not found for Loan ID: " + request.getLoanId() +
                                ", EMI Number: " + request.getEmiNumber()));

        int daysOverdue = calculateDaysOverdue(emi.getDueDate(), request.getPaymentDate());
        BigDecimal penaltyAmount = daysOverdue > 0
                ? PENALTY_RATE.multiply(BigDecimal.valueOf(daysOverdue))
                : BigDecimal.ZERO;

        BigDecimal emiAmount = emi.getEmiAmount();
        BigDecimal totalDue = emiAmount.add(penaltyAmount);

        Payment payment = new Payment();
        payment.setLoanId(request.getLoanId());
        payment.setEmiNumber(request.getEmiNumber());
        payment.setPaymentDate(request.getPaymentDate());
        payment.setPaymentAmount(totalDue);   // includes penalty
        payment.setPaymentMethod(request.getPaymentMethod());
        payment.setTransactionId(request.getTransactionId());
        payment.setDaysOverdue(daysOverdue);
        payment.setTotalDue(totalDue);

        if (emiAmount != null && emiAmount.compareTo(BigDecimal.ZERO) > 0) {
            payment.setPaymentStatus("SUCCESS");
            payment.setFailureReason(null);
        } else {
            payment.setPaymentStatus("FAILED");
            payment.setFailureReason("Invalid EMI amount in schedule.");
        }

        Payment saved = paymentRepository.save(payment);

        // Mark EMI as paid
        if ("SUCCESS".equals(saved.getPaymentStatus())) {
            updateEmiStatus(request.getLoanId(), request.getEmiNumber());
        }

        // Save penalty record if overdue
        if (daysOverdue > 0 && penaltyAmount.compareTo(BigDecimal.ZERO) > 0) {
            boolean exists = !penaltyService
                    .getPenaltiesByLoanAndEmiNumber(request.getLoanId(), request.getEmiNumber())
                    .isEmpty();

            if (!exists) {
                Penalty penalty = new Penalty();
                penalty.setLoanId(request.getLoanId());
                penalty.setEmiNumber(request.getEmiNumber());
                penalty.setPenaltyAmount(penaltyAmount);
                penalty.setReason("Late EMI payment");
                penalty.setCreatedDate(LocalDateTime.now());

                penaltyService.addPenalty(penalty);
            }
        }

        return mapToResponseDTO(saved, penaltyAmount);
    }

    @Override
    public PaymentResponseDTO updatePayment(int paymentId, PaymentRequestDTO request) {
        Payment existing = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new CustomException(
                        "Payment not found with ID: " + paymentId));

        EmiSchedule emi = emiScheduleRepository
                .findByLoanIdAndEmiNumber(request.getLoanId(), request.getEmiNumber())
                .orElseThrow(() -> new CustomException(
                        "EMI not found for Loan ID: " + request.getLoanId() +
                                ", EMI Number: " + request.getEmiNumber()));

        int daysOverdue = calculateDaysOverdue(emi.getDueDate(), request.getPaymentDate());
        BigDecimal penaltyAmount = daysOverdue > 0
                ? PENALTY_RATE.multiply(BigDecimal.valueOf(daysOverdue))
                : BigDecimal.ZERO;
        BigDecimal totalDue = emi.getEmiAmount().add(penaltyAmount);

        existing.setLoanId(request.getLoanId());
        existing.setEmiNumber(request.getEmiNumber());
        existing.setPaymentDate(request.getPaymentDate());
        existing.setPaymentMethod(request.getPaymentMethod());
        existing.setTransactionId(request.getTransactionId());
        existing.setDaysOverdue(daysOverdue);
        existing.setTotalDue(totalDue);

        if (emi.getEmiAmount().compareTo(BigDecimal.ZERO) > 0) {
            existing.setPaymentStatus("SUCCESS");
            existing.setFailureReason(null);
        } else {
            existing.setPaymentStatus("FAILED");
            existing.setFailureReason("Invalid EMI amount in schedule.");
        }

        Payment updated = paymentRepository.save(existing);
        return mapToResponseDTO(updated, penaltyAmount);
    }

    @Override
    public List<PaymentResponseDTO> getAllPayments() {
        return paymentRepository.findAll()
                .stream()
                .map(p -> mapToResponseDTO(p, calculatePenalty(p)))
                .collect(Collectors.toList());
    }

    @Override
    public List<PaymentResponseDTO> getPaymentsByLoanId(String loanId) {
        return paymentRepository.findByLoanId(loanId)
                .stream()
                .map(p -> mapToResponseDTO(p, calculatePenalty(p)))
                .collect(Collectors.toList());
    }

    @Override
    public Optional<PaymentResponseDTO> getPaymentByLoanIdAndEmiNumber(String loanId, int emiNumber) {
        return paymentRepository.findByLoanIdAndEmiNumber(loanId, emiNumber)
                .map(p -> mapToResponseDTO(p, calculatePenalty(p)));
    }

    // ===== helpers =====
    private int calculateDaysOverdue(LocalDate dueDate, LocalDate paymentDate) {
        long days = ChronoUnit.DAYS.between(dueDate, paymentDate);
        return (int) Math.max(days, 0);
    }

    private void updateEmiStatus(String loanId, Integer emiNumber) {
        emiScheduleRepository.findByLoanIdAndEmiNumber(loanId, emiNumber)
                .ifPresentOrElse(
                        emi -> {
                            emi.setStatus("PAID");
                            emi.setLastModified(LocalDateTime.now());
                            emiScheduleRepository.save(emi);
                        },
                        () -> { throw new CustomException("EMI not found for update."); }
                );
    }

    private BigDecimal calculatePenalty(Payment p) {
        return (p.getDaysOverdue() > 0)
                ? PENALTY_RATE.multiply(BigDecimal.valueOf(p.getDaysOverdue()))
                : BigDecimal.ZERO;
    }

    private PaymentResponseDTO mapToResponseDTO(Payment p, BigDecimal penalty) {
        return PaymentResponseDTO.builder()
                .paymentId(p.getPaymentId())
                .emiNumber(p.getEmiNumber())
                .paymentDate(p.getPaymentDate())
                .paymentAmount(p.getPaymentAmount())
                .paymentMethod(p.getPaymentMethod())
                .transactionId(p.getTransactionId())
                .daysOverdue(p.getDaysOverdue())
                .totalDue(p.getTotalDue())
                .paymentStatus(p.getPaymentStatus())
                .failureReason(p.getFailureReason())
                .loanId(p.getLoanId())
                .penaltyAmount(penalty)
                .build();
    }
}
