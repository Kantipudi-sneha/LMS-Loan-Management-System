package com.Module1.UserRegistration.repo;

import com.Module1.UserRegistration.model.LoanDisbursement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LoanDisbursementRepository extends JpaRepository<LoanDisbursement, Long> {
    
    List<LoanDisbursement> findByLoanId(Long loanId);
    
    List<LoanDisbursement> findByStatus(String status);
    
    List<LoanDisbursement> findByLoanIdAndStatus(Long loanId, String status);
}