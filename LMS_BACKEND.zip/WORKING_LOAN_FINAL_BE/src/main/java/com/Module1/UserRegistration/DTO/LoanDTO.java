package com.Module1.UserRegistration.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoanDTO {
    private String loanId;
    private String customerName;
    private BigDecimal principalAmount;
    private BigDecimal interestRate;
    private int tenure;              // ✅ add this
    private LocalDate startDate;     // ✅ add this
}

