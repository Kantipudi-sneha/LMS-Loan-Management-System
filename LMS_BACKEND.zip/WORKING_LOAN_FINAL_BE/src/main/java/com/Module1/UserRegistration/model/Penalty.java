package com.Module1.UserRegistration.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "penalties")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Penalty {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "penalty_id")
    private Integer penaltyId;

    @Column(name = "loan_id", nullable = false)
    private String loanId;

    @Column(name = "emi_number", nullable = false)
    private int emiNumber;

    @Column(name = "penalty_amount", nullable = false)
    private BigDecimal penaltyAmount;

    @Column(name = "reason", nullable = false)
    private String reason;

    @Column(name = "created_date")
    private LocalDateTime createdDate;
}
