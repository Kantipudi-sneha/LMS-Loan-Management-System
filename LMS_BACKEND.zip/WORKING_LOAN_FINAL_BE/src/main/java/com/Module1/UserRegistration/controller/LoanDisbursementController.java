package com.Module1.UserRegistration.controller;

import com.Module1.UserRegistration.DTO.LoanDisbursementDTO;
import com.Module1.UserRegistration.exception.CustomException;
import com.Module1.UserRegistration.model.LoanDisbursement;
import com.Module1.UserRegistration.service.LoanDisbursementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/disbursements")
@CrossOrigin(origins = "http://localhost:4200")
public class LoanDisbursementController {

    @Autowired
    private LoanDisbursementService loanDisbursementService;

    private LoanDisbursementDTO toDTO(LoanDisbursement disbursement) {
        if (disbursement == null) return null;
        LoanDisbursementDTO dto = new LoanDisbursementDTO();
        dto.setId(disbursement.getId());
        dto.setLoanId(disbursement.getLoanId());
        dto.setAmount(disbursement.getAmount());
        dto.setStatus(disbursement.getStatus());
        dto.setUtrNumber(disbursement.getUtrNumber());
        dto.setCustomerAccountNumber(disbursement.getCustomerAccountNumber());
        dto.setReferenceId(disbursement.getReferenceId());
        dto.setDisbursementMethod(disbursement.getDisbursementMethod());
        dto.setCreatedAt(disbursement.getCreatedAt());
        dto.setUpdatedAt(disbursement.getUpdatedAt());
        return dto;
    }

    private LoanDisbursement toEntity(LoanDisbursementDTO dto) {
        if (dto == null) return null;
        LoanDisbursement disbursement = new LoanDisbursement();
        disbursement.setId(dto.getId());
        disbursement.setLoanId(dto.getLoanId());
        disbursement.setAmount(dto.getAmount());
        disbursement.setStatus(dto.getStatus());
        disbursement.setUtrNumber(dto.getUtrNumber());
        disbursement.setCustomerAccountNumber(dto.getCustomerAccountNumber());
        disbursement.setReferenceId(dto.getReferenceId());
        disbursement.setDisbursementMethod(dto.getDisbursementMethod());
        disbursement.setCreatedAt(dto.getCreatedAt());
        disbursement.setUpdatedAt(dto.getUpdatedAt());
        return disbursement;
    }

    @PostMapping
    public ResponseEntity<LoanDisbursementDTO> initiateDisbursement(@RequestBody LoanDisbursementDTO disbursementDTO) {
        LoanDisbursement created = loanDisbursementService.initiateDisbursement(toEntity(disbursementDTO));
        return ResponseEntity.ok(toDTO(created));
    }

    @GetMapping
    public ResponseEntity<List<LoanDisbursementDTO>> getAllDisbursements() {
        List<LoanDisbursementDTO> disbursements = loanDisbursementService.getAllDisbursements()
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(disbursements);
    }

    @GetMapping("/{id}")
    public ResponseEntity<LoanDisbursementDTO> getDisbursementById(@PathVariable Long id) {
        LoanDisbursement disbursement = loanDisbursementService.getDisbursementById(id)
                .orElseThrow(() -> new CustomException("Disbursement not found with ID " + id));
        return ResponseEntity.ok(toDTO(disbursement));
    }

    @PutMapping("/{id}")
    public ResponseEntity<LoanDisbursementDTO> updateDisbursement(@PathVariable Long id, @RequestBody LoanDisbursementDTO disbursementDTO) {
        LoanDisbursement updated = loanDisbursementService.updateDisbursement(id, toEntity(disbursementDTO));
        if (updated == null) throw new CustomException("Disbursement not found with ID " + id);
        return ResponseEntity.ok(toDTO(updated));
    }

    @PutMapping("/{id}/utr")
    public ResponseEntity<LoanDisbursementDTO> updateUTR(@PathVariable Long id, @RequestParam String utrNumber) {
        LoanDisbursement updated = loanDisbursementService.updateUTR(id, utrNumber);
        if (updated == null) throw new CustomException("Disbursement not found with ID " + id);
        return ResponseEntity.ok(toDTO(updated));
    }

    @PutMapping("/{id}/approve")
    public ResponseEntity<LoanDisbursementDTO> approveDisbursement(@PathVariable Long id) {
        LoanDisbursement approved = loanDisbursementService.approveDisbursement(id);
        if (approved == null) throw new CustomException("Disbursement not found with ID " + id);
        return ResponseEntity.ok(toDTO(approved));
    }

    @PutMapping("/{id}/reject")
    public ResponseEntity<LoanDisbursementDTO> rejectDisbursement(@PathVariable Long id) {
        LoanDisbursement rejected = loanDisbursementService.rejectDisbursement(id);
        if (rejected == null) throw new CustomException("Disbursement not found with ID " + id);
        return ResponseEntity.ok(toDTO(rejected));
    }

    @PutMapping("/{id}/fail")
    public ResponseEntity<LoanDisbursementDTO> markDisbursementFailed(@PathVariable Long id) {
        LoanDisbursement failed = loanDisbursementService.markDisbursementFailed(id);
        if (failed == null) throw new CustomException("Disbursement not found with ID " + id);
        return ResponseEntity.ok(toDTO(failed));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Boolean> cancelDisbursement(@PathVariable Long id) {
        boolean cancelled = loanDisbursementService.cancelDisbursement(id);
        if (!cancelled) throw new CustomException("Disbursement not found with ID " + id);
        return ResponseEntity.ok(cancelled);
    }

    @GetMapping("/loan/{loanId}")
    public ResponseEntity<List<LoanDisbursementDTO>> getDisbursementsByLoanId(@PathVariable Long loanId) {
        List<LoanDisbursementDTO> disbursements = loanDisbursementService.getDisbursementsByLoanId(loanId)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(disbursements);
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<LoanDisbursementDTO>> getDisbursementsByStatus(@PathVariable String status) {
        List<LoanDisbursementDTO> disbursements = loanDisbursementService.getDisbursementsByStatus(status)
                .stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(disbursements);
    }
}
