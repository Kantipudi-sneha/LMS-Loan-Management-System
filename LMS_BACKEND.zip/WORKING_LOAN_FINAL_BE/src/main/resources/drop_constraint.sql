-- Drop foreign key constraint from payments table
ALTER TABLE payments DROP FOREIGN KEY FKgfgkjdqpp1oaegm53mctnns1b;

-- Optional: Add new foreign key constraint to loan_applications table
-- ALTER TABLE payments ADD CONSTRAINT FK_payments_loan_applications 
-- FOREIGN KEY (loan_id) REFERENCES loan_applications(id);
